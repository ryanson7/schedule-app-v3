// QR ?�틸리티 
export const generateQR = () =
