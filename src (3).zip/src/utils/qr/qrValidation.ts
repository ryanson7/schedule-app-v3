// QR 검�??�틸리티 
export const validateQR = () =
