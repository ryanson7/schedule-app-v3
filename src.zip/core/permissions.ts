import { UserRole, ScheduleType } from './types';

export const hasAccess = (role: UserRole, area: ScheduleType): boolean => {
  const accessMap = {
    academy: ['system_admin', 'schedule_admin', 'academy_manager', 'manager'],
    studio: ['system_admin', 'schedule_admin', 'studio_manager', 'manager']
  };
  return accessMap[area].includes(role);
};

export const safeUserRole = (roleString: string): UserRole => {
  const validRoles: UserRole[] = [
    'system_admin', 'schedule_admin', 'academy_manager', 
    'studio_manager', 'manager', 'staff'
  ];
  return validRoles.includes(roleString as UserRole) ? roleString as UserRole : 'staff';
};

export const getUserPermissions = (role: UserRole) => {
  return {
    canApprove: ['system_admin', 'schedule_admin'].includes(role),
    canDelete: ['system_admin', 'schedule_admin'].includes(role),
    canEdit: ['system_admin', 'schedule_admin', 'academy_manager', 'studio_manager', 'manager'].includes(role),
    canCreate: ['system_admin', 'schedule_admin', 'academy_manager', 'studio_manager', 'manager'].includes(role)
  };
};
