"use client";
import React, { createContext, useContext, useState } from 'react';

interface WeekContextType {
  currentWeek: Date;
  navigateWeek: (direction: number) => void;
}

const WeekContext = createContext<WeekContextType | undefined>(undefined);

export function WeekProvider({ children }: { children: React.ReactNode }) {
  const [currentWeek, setCurrentWeek] = useState(new Date());

  const navigateWeek = (direction: number) => {
    const newWeek = new Date(currentWeek);
    newWeek.setDate(currentWeek.getDate() + (direction * 7));
    setCurrentWeek(newWeek);
  };

  return (
    <WeekContext.Provider value={{ currentWeek, navigateWeek }}>
      {children}
    </WeekContext.Provider>
  );
}

export function useWeek() {
  const context = useContext(WeekContext);
  if (!context) {
    throw new Error('useWeek must be used within WeekProvider');
  }
  return context;
}
