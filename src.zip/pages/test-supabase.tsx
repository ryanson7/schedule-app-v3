"use client";
import { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";

export default function TestSchedules() {
  const [schedules, setSchedules] = useState([]);
  const [newSchedule, setNewSchedule] = useState({
    shoot_date: "",
    start_time: "",
    end_time: "",
    professor_name: "",
    course_name: "",
    schedule_type: "academy",
    shooting_type: "",
    sub_location_id: 1,
    team_id: 1,
    notes: ""
  });
  const [editId, setEditId] = useState<number | null>(null);
  const [editSchedule, setEditSchedule] = useState<any>({});

  // [조회]
  useEffect(() => {
    fetchSchedules();
  }, []);

  const fetchSchedules = async () => {
    const { data, error } = await supabase.from('schedules').select('*').order('shoot_date', { ascending: true }).order('start_time', { ascending: true });
    if (error) alert('조회 오류: ' + error.message);
    else setSchedules(data || []);
  };

  // [등록]
  const addSchedule = async () => {
    if (!newSchedule.shoot_date || !newSchedule.start_time || !newSchedule.end_time) {
      alert("날짜와 시간을 모두 입력하세요.");
      return;
    }
    if (isTimeOverlap(newSchedule.shoot_date, newSchedule.start_time, newSchedule.end_time, newSchedule.sub_location_id)) {
      alert("동일 장소/시간대에 이미 일정이 있습니다!");
      return;
    }
    const { error } = await supabase.from('schedules').insert([newSchedule]);
    if (error) alert('등록 오류: ' + error.message);
    else {
      setNewSchedule({ ...newSchedule, shoot_date: "", start_time: "", end_time: "", professor_name: "", course_name: "", shooting_type: "", notes: "" });
      fetchSchedules();
    }
  };

  // [수정]
  const startEdit = (s: any) => {
    setEditId(s.id);
    setEditSchedule({ ...s });
  };
  const saveEdit = async () => {
    if (!editSchedule.shoot_date || !editSchedule.start_time || !editSchedule.end_time) {
      alert("날짜와 시간을 모두 입력하세요.");
      return;
    }
    if (isTimeOverlap(editSchedule.shoot_date, editSchedule.start_time, editSchedule.end_time, editSchedule.sub_location_id, editSchedule.id)) {
      alert("동일 장소/시간대에 이미 일정이 있습니다!");
      return;
    }
    const { error } = await supabase.from('schedules').update(editSchedule).eq('id', editId!);
    if (error) alert('수정 오류: ' + error.message);
    else {
      setEditId(null);
      setEditSchedule({});
      fetchSchedules();
    }
  };

  // [삭제]
  const deleteSchedule = async (id: number) => {
    if (!window.confirm("정말 삭제하시겠습니까?")) return;
    const { error } = await supabase.from('schedules').delete().eq('id', id);
    if (error) alert('삭제 오류: ' + error.message);
    else fetchSchedules();
  };

  // [승인/취소]
  const changeStatus = async (id: number, status: string) => {
    const { error } = await supabase.from('schedules').update({ approval_status: status }).eq('id', id);
    if (error) alert('상태 변경 오류: ' + error.message);
    else fetchSchedules();
  };

  // [중복 체크]
  const isTimeOverlap = (date: string, start: string, end: string, sub_location_id: number, exceptId?: number) => {
    return schedules.some((s: any) =>
      s.shoot_date === date &&
      s.sub_location_id === sub_location_id &&
      s.id !== exceptId &&
      (
        (start >= s.start_time && start < s.end_time) ||
        (end > s.start_time && end <= s.end_time) ||
        (start <= s.start_time && end >= s.end_time)
      )
    );
  };

  return (
    <div style={{ maxWidth: 600, margin: "0 auto" }}>
      <h1>스케줄 관리</h1>
      <h2>새 일정 등록</h2>
      <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 16 }}>
        <input type="date" value={newSchedule.shoot_date} onChange={e => setNewSchedule({ ...newSchedule, shoot_date: e.target.value })} />
        <input type="time" value={newSchedule.start_time} onChange={e => setNewSchedule({ ...newSchedule, start_time: e.target.value })} />
        <input type="time" value={newSchedule.end_time} onChange={e => setNewSchedule({ ...newSchedule, end_time: e.target.value })} />
        <input placeholder="교수명" value={newSchedule.professor_name} onChange={e => setNewSchedule({ ...newSchedule, professor_name: e.target.value })} />
        <input placeholder="강의명" value={newSchedule.course_name} onChange={e => setNewSchedule({ ...newSchedule, course_name: e.target.value })} />
        <input placeholder="촬영유형" value={newSchedule.shooting_type} onChange={e => setNewSchedule({ ...newSchedule, shooting_type: e.target.value })} />
        <input placeholder="비고" value={newSchedule.notes} onChange={e => setNewSchedule({ ...newSchedule, notes: e.target.value })} />
        <button onClick={addSchedule}>등록</button>
      </div>
      <h2>일정 목록</h2>
      <ul>
        {schedules.map((s: any) => (
          <li key={s.id} style={{ border: "1px solid #ccc", margin: "8px 0", padding: 8, borderRadius: 6 }}>
            {editId === s.id ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <input type="date" value={editSchedule.shoot_date} onChange={e => setEditSchedule({ ...editSchedule, shoot_date: e.target.value })} />
                <input type="time" value={editSchedule.start_time} onChange={e => setEditSchedule({ ...editSchedule, start_time: e.target.value })} />
                <input type="time" value={editSchedule.end_time} onChange={e => setEditSchedule({ ...editSchedule, end_time: e.target.value })} />
                <input placeholder="교수명" value={editSchedule.professor_name} onChange={e => setEditSchedule({ ...editSchedule, professor_name: e.target.value })} />
                <input placeholder="강의명" value={editSchedule.course_name} onChange={e => setEditSchedule({ ...editSchedule, course_name: e.target.value })} />
                <input placeholder="촬영유형" value={editSchedule.shooting_type} onChange={e => setEditSchedule({ ...editSchedule, shooting_type: e.target.value })} />
                <input placeholder="비고" value={editSchedule.notes} onChange={e => setEditSchedule({ ...editSchedule, notes: e.target.value })} />
                <button onClick={saveEdit}>수정 저장</button>
                <button onClick={() => setEditId(null)}>취소</button>
              </div>
            ) : (
              <div>
                <b>{s.shoot_date} {s.start_time}~{s.end_time}</b> | {s.professor_name} | {s.course_name} | {s.shooting_type}
                <span style={{
                  color:
                    s.approval_status === "approved"
                      ? "green"
                      : s.approval_status === "pending"
                        ? "orange"
                        : "red",
                  fontWeight: "bold",
                  marginLeft: 8
                }}>
                  [{s.approval_status}]
                </span>
                <div style={{ marginTop: 4 }}>
                  <button onClick={() => startEdit(s)}>수정</button>
                  <button onClick={() => deleteSchedule(s.id)}>삭제</button>
                  <button onClick={() => changeStatus(s.id, "approved")}>승인</button>
                  <button onClick={() => changeStatus(s.id, "rejected")}>취소</button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
