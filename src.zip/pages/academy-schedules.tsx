import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Layout from '../components/Layout';
import AcademyScheduleManager from '../components/AcademyScheduleManager';
import { UserRoleType } from '../types/users';
import { checkSession } from '../utils/supabaseClient';

export default function AcademySchedulesPage() {
  const router = useRouter();
  const [userRole, setUserRole] = useState<UserRoleType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuthAndRole = async () => {
      try {
        console.log('🔍 페이지 접근 - 인증 확인 시작');

        let session = null;
        let attempts = 0;
        const maxAttempts = 5;

        while (!session && attempts < maxAttempts) {
          attempts++;
          console.log(`세션 확인 시도 ${attempts}/${maxAttempts}`);
          
          session = await checkSession();
          
          if (!session) {
            await new Promise(resolve => setTimeout(resolve, 300));
          }
        }
        
        if (!session) {
          console.warn('⚠️ 세션 없음 - 로그인 페이지로 이동');
          router.push('/login');
          return;
        }

        console.log('✅ 세션 확인 완료:', session.user?.email);

        const savedRole = localStorage.getItem('userRole') as UserRoleType;
        const savedEmail = localStorage.getItem('userEmail');
        const isAuthenticated = localStorage.getItem('isAuthenticated');

        if (!savedRole || !savedEmail || isAuthenticated !== 'true') {
          console.warn('⚠️ 로컬스토리지 정보 없음 - 로그인 필요');
          router.push('/login');
          return;
        }

        console.log('✅ 로컬스토리지 확인 완료:', { role: savedRole, email: savedEmail });

        if (session.user?.email && session.user.email !== savedEmail) {
          console.warn('⚠️ 세션과 로컬스토리지 이메일 불일치');
          localStorage.clear();
          router.push('/login');
          return;
        }

        const allowedRoles: UserRoleType[] = [
          'system_admin', 
          'schedule_admin', 
          'academy_manager',
          'manager'
        ];

        if (!allowedRoles.includes(savedRole)) {
          console.warn('⚠️ 권한 없음:', savedRole);
          alert('학원 스케줄 관리 권한이 없습니다.');
          router.push('/');
          return;
        }

        console.log('✅ 권한 확인 완료:', savedRole);
        setUserRole(savedRole);
        setLoading(false);

      } catch (error) {
        console.error('❌ 인증 확인 오류:', error);
        localStorage.clear();
        router.push('/login');
      }
    };

    checkAuthAndRole();
  }, [router]);

  if (loading) {
    return (
      <Layout>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center', 
          height: '100vh',
          flexDirection: 'column',
          gap: '16px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: '4px solid #3b82f6',
            borderTop: '4px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }} />
          <p>인증 및 권한을 확인하는 중...</p>
          <style jsx>{`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      </Layout>
    );
  }

  if (!userRole) {
    return null;
  }

  return (
    <Layout>
      <div style={{
        height: '100%',
        overflow: 'hidden',
        padding: '0',
        margin: '0',
        display: 'flex',
        flexDirection: 'column'
      }}>
        <AcademyScheduleManager currentUserRole={userRole} />
       
      </div>
    </Layout>
  );
}
