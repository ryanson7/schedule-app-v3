// Admin ?�산 관�?
export default function AdminSettlements() {} 
