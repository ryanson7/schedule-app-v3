// Admin Shooter 관�?
export default function ShooterManagement() {} 
