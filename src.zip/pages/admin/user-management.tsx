"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Layout from '../../components/Layout';
import UserManagement from '../../components/users/UserManagement';
import RoleManagement from '../../components/users/RoleManagement';
import TeamAssignment from '../../components/users/TeamAssignment';
import { SecondaryButton } from '../../components/ui/buttons';
import { UserRoleType } from '../../types/users';
import { hasPermission, safeUserRole } from '../../utils/permissions';
import { canAccessPage } from '../../utils/roleRedirection';

type TabType = 'users' | 'roles' | 'teams';

const UserManagementPage = () => {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabType>('users');
  const [currentUserRole, setCurrentUserRole] = useState<UserRoleType>('staff');
  const [currentUserAcademies, setCurrentUserAcademies] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUserPermissions();
  }, []);

  // 사용자 권한 확인
  const checkUserPermissions = async () => {
    try {
      const userRole = localStorage.getItem('userRole');
      const userAcademies = localStorage.getItem('userAcademies');
      
      if (!userRole) {
        console.warn('사용자 역할 정보가 없습니다.');
        router.push('/login');
        return;
      }

      const normalizedRole = safeUserRole(userRole);
      
      // 페이지 접근 권한 확인
      if (!canAccessPage(normalizedRole, '/admin/user-management')) {
        alert('접근 권한이 없습니다.');
        router.push('/');
        return;
      }

      setCurrentUserRole(normalizedRole);
      
      if (userAcademies) {
        try {
          const academyIds = JSON.parse(userAcademies);
          setCurrentUserAcademies(Array.isArray(academyIds) ? academyIds : []);
        } catch (parseError) {
          console.warn('학원 정보 파싱 오류:', parseError);
          setCurrentUserAcademies([]);
        }
      }
    } catch (error) {
      console.error('권한 확인 오류:', error);
      router.push('/login');
    } finally {
      setLoading(false);
    }
  };

  // 탭 변경 권한 확인
  const canAccessTab = (tab: TabType): boolean => {
    switch (tab) {
      case 'users':
        return hasPermission(currentUserRole, 'user_management', 'read');
      case 'roles':
        return currentUserRole === 'system_admin'; // 시스템 관리자만
      case 'teams':
        return hasPermission(currentUserRole, 'user_management', 'write');
      default:
        return false;
    }
  };

  // 탭 변경 핸들러
  const handleTabChange = (tab: TabType) => {
    if (canAccessTab(tab)) {
      setActiveTab(tab);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <p>권한을 확인하는 중...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="user-management-page">
        {/* 탭 네비게이션 */}
        <div className="tab-navigation">
          <div className="tab-list">
            <button
              className={`tab-button ${activeTab === 'users' ? 'active' : ''}`}
              onClick={() => handleTabChange('users')}
              disabled={!canAccessTab('users')}
            >
              <span className="tab-icon">👥</span>
              사용자 관리
            </button>
            
            <button
              className={`tab-button ${activeTab === 'roles' ? 'active' : ''}`}
              onClick={() => handleTabChange('roles')}
              disabled={!canAccessTab('roles')}
            >
              <span className="tab-icon">🔐</span>
              역할 관리
              {!canAccessTab('roles') && (
                <span className="restricted-badge">제한</span>
              )}
            </button>
            
            <button
              className={`tab-button ${activeTab === 'teams' ? 'active' : ''}`}
              onClick={() => handleTabChange('teams')}
              disabled={!canAccessTab('teams')}
            >
              <span className="tab-icon">🏢</span>
              팀 배정
              {!canAccessTab('teams') && (
                <span className="restricted-badge">제한</span>
              )}
            </button>
          </div>

          {/* 빠른 액션 버튼들 */}
          <div className="quick-actions">
            {activeTab === 'users' && hasPermission(currentUserRole, 'user_management', 'write') && (
              <SecondaryButton onClick={() => {/* 사용자 일괄 가져오기 등 */}}>
                일괄 작업
              </SecondaryButton>
            )}
          </div>
        </div>

        {/* 탭 컨텐츠 */}
        <div className="tab-content">
          {activeTab === 'users' && (
            <UserManagement
              currentUserRole={currentUserRole}
              currentUserAcademies={currentUserAcademies}
            />
          )}
          
          {activeTab === 'roles' && canAccessTab('roles') && (
            <RoleManagement
              currentUserRole={currentUserRole}
            />
          )}
          
          {activeTab === 'teams' && canAccessTab('teams') && (
            <TeamAssignment
              currentUserRole={currentUserRole}
              currentUserAcademies={currentUserAcademies}
            />
          )}
        </div>

        {/* 권한 안내 */}
        {!canAccessTab(activeTab) && (
          <div className="permission-notice">
            <h3>접근 권한이 없습니다</h3>
            <p>이 기능을 사용하려면 더 높은 권한이 필요합니다.</p>
            <p>관리자에게 문의하세요.</p>
          </div>
        )}
      </div>

      {/* 스타일 */}
      <style jsx>{`
        .user-management-page {
          background: #ffffff;
          border-radius: 8px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
          overflow: hidden;
        }

        .tab-navigation {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
          padding: 0;
        }

        .tab-list {
          display: flex;
        }

        .tab-button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 16px 24px;
          border: none;
          background: transparent;
          color: #64748b;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          position: relative;
          border-bottom: 3px solid transparent;
        }

        .tab-button:hover:not(:disabled) {
          background: #f1f5f9;
          color: #334155;
        }

        .tab-button.active {
          background: #ffffff;
          color: #3b82f6;
          font-weight: 600;
          border-bottom-color: #3b82f6;
        }

        .tab-button:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .tab-icon {
          font-size: 16px;
        }

        .restricted-badge {
          position: absolute;
          top: 8px;
          right: 8px;
          background: #dc2626;
          color: white;
          padding: 1px 4px;
          border-radius: 6px;
          font-size: 8px;
          font-weight: 600;
          text-transform: uppercase;
        }

        .quick-actions {
          display: flex;
          gap: 8px;
          padding: 16px 24px;
        }

        .tab-content {
          min-height: 600px;
        }

        .permission-notice {
          text-align: center;
          padding: 80px 40px;
          border: 2px dashed #e2e8f0;
          margin: 40px;
          border-radius: 8px;
        }

        .permission-notice h3 {
          margin: 0 0 12px 0;
          color: #dc2626;
          font-size: 20px;
          font-weight: 600;
        }

        .permission-notice p {
          margin: 0 0 8px 0;
          color: #64748b;
          font-size: 14px;
          line-height: 1.5;
        }

        .loading-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 80px;
        }

        .loading-spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #e2e8f0;
          border-top: 4px solid #3b82f6;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin-bottom: 16px;
        }

        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
          .tab-navigation {
            flex-direction: column;
            gap: 12px;
            align-items: stretch;
          }

          .tab-list {
            flex-direction: column;
          }

          .tab-button {
            justify-content: flex-start;
            border-bottom: none;
            border-left: 3px solid transparent;
          }

          .tab-button.active {
            border-bottom: none;
            border-left-color: #3b82f6;
          }

          .quick-actions {
            justify-content: center;
          }
        }
      `}</style>
    </Layout>
  );
};

export default UserManagementPage;
