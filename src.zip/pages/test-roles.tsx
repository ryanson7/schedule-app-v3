"use client";
import { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";

export default function TestRoles() {
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const [userId, setUserId] = useState<number | null>(null);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    fetchAllUsers();
    getCurrentUser();
  }, []);

  const fetchAllUsers = async () => {
    const { data } = await supabase
      .from('users')
      .select(`
        id, name, email,
        user_roles(
          roles(name)
        )
      `);
    setAllUsers(data || []);
  };

  const getCurrentUser = async () => {
    // 임시로 첫 번째 사용자를 현재 사용자로 설정 (테스트용)
    const { data } = await supabase.from('users').select('id').limit(1).single();
    if (data) {
      setUserId(data.id);
      await getUserRoles(data.id);
    }
  };

  const getUserRoles = async (userId: number) => {
    const { data } = await supabase
      .from('user_roles')
      .select('roles(name)')
      .eq('user_id', userId);
    setUserRoles(data?.map((r: any) => r.roles.name) || []);
  };

  const switchUser = async (newUserId: number) => {
    setUserId(newUserId);
    await getUserRoles(newUserId);
  };

  const isAdmin = userRoles.some(role => ['admin', 'manager'].includes(role));

  return (
    <div style={{ maxWidth: 600, margin: "0 auto" }}>
      <h1>사용자 역할 테스트</h1>
      
      <div style={{ marginBottom: 20, padding: 16, background: "#f5f5f5", borderRadius: 8 }}>
        <h3>현재 사용자 정보</h3>
        <p>사용자 ID: {userId}</p>
        <p>역할: {userRoles.join(", ") || "없음"}</p>
        <p>관리자 권한: {isAdmin ? "✅ 있음" : "❌ 없음"}</p>
      </div>

      <div style={{ marginBottom: 20 }}>
        <h3>사용자 전환 (테스트용)</h3>
        {allUsers.map(user => (
          <button 
            key={user.id}
            onClick={() => switchUser(user.id)}
            style={{ 
              margin: "4px", 
              padding: "8px 12px",
              background: userId === user.id ? "#007bff" : "#6c757d",
              color: "white",
              border: "none",
              borderRadius: 4
            }}
          >
            {user.name} ({user.user_roles?.map((ur: any) => ur.roles.name).join(", ") || "역할없음"})
          </button>
        ))}
      </div>

      <div style={{ marginBottom: 20 }}>
        <h3>권한별 버튼 테스트</h3>
        {isAdmin ? (
          <div>
            <button style={{ background: "#28a745", color: "white", padding: "8px 16px", margin: "4px", border: "none", borderRadius: 4 }}>
              ✅ 승인 (관리자만)
            </button>
            <button style={{ background: "#dc3545", color: "white", padding: "8px 16px", margin: "4px", border: "none", borderRadius: 4 }}>
              ✅ 삭제 (관리자만)
            </button>
            <button style={{ background: "#17a2b8", color: "white", padding: "8px 16px", margin: "4px", border: "none", borderRadius: 4 }}>
              ✅ 촬영자 배치 (관리자만)
            </button>
          </div>
        ) : (
          <p style={{ color: "#dc3545" }}>❌ 관리자 권한이 없어서 버튼이 숨겨집니다.</p>
        )}
      </div>

      <div>
        <h3>전체 사용자 및 역할 목록</h3>
        <ul>
          {allUsers.map(user => (
            <li key={user.id}>
              {user.name} ({user.email}) - 역할: {user.user_roles?.map((ur: any) => ur.roles.name).join(", ") || "없음"}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
