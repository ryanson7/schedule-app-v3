"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import Head from 'next/head';
import Layout from '../components/Layout';
import { UserRoleType } from '../types/users';
import { safeUserRole } from '../utils/permissions';

const StudioAdminPanel = dynamic(
  () => import('../components/StudioAdminPanel'),
  { 
    ssr: false,
    loading: () => (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '50vh',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid #3b82f6',
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }} />
        <div>스튜디오 관리 패널을 불러오는 중...</div>
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    )
  }
);

const StudioAdminPage = () => {
  const router = useRouter();
  const [currentUserRole, setCurrentUserRole] = useState<UserRoleType>('staff');
  const [loading, setLoading] = useState(true);
  const [accessDenied, setAccessDenied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const userRole = localStorage.getItem('userRole');
      const userName = localStorage.getItem('userName');
      const isAuthenticated = localStorage.getItem('isAuthenticated');
      
      if (!userRole || !userName || isAuthenticated !== 'true') {
        console.warn('⚠️ 인증 정보 없음 - 로그인 페이지로 이동');
        router.push('/login');
        return;
      }

      const normalizedRole = safeUserRole(userRole);

      console.log('🔍 스튜디오 관리 페이지 권한 확인:', {
        userRole,
        normalizedRole,
        userName,
        허용역할: ['system_admin', 'schedule_admin']
      });

      // 스튜디오 관리 권한 체크
      if (!['system_admin', 'schedule_admin'].includes(normalizedRole)) {
        console.warn('⚠️ 스튜디오 관리 권한 없음:', normalizedRole);
        setAccessDenied(true);
      } else {
        setCurrentUserRole(normalizedRole);
      }
      
      setLoading(false);
    }
  }, [router]);

  if (loading) {
    return (
      <Layout>
        <Head>
          <title>스튜디오 관리 로딩 중 - 에듀윌 스케줄 시스템</title>
        </Head>
        <div style={{ 
          padding: '40px', 
          textAlign: 'center',
          minHeight: '50vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column',
          gap: '16px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: '4px solid #3b82f6',
            borderTop: '4px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }} />
          <div>스튜디오 관리 페이지 로딩 중...</div>
          <style jsx>{`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <Head>
          <title>스튜디오 관리 오류 - 에듀윌 스케줄 시스템</title>
        </Head>
        <div style={{ 
          padding: '40px', 
          textAlign: 'center',
          minHeight: '50vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <div style={{
            backgroundColor: '#fef2f2',
            border: '1px solid #fecaca',
            borderRadius: '8px',
            padding: '32px',
            maxWidth: '500px'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚠️</div>
            <h3 style={{ color: '#dc2626', marginBottom: '16px' }}>
              오류가 발생했습니다
            </h3>
            <p style={{ marginBottom: '24px', color: '#6b7280' }}>{error}</p>
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <button 
                onClick={() => window.location.reload()}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '500'
                }}
              >
                새로고침
              </button>
              <button 
                onClick={() => router.push('/')}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#6b7280',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '500'
                }}
              >
                홈으로
              </button>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (accessDenied) {
    return (
      <Layout>
        <Head>
          <title>접근 권한 없음 - 에듀윌 스케줄 시스템</title>
        </Head>
        <div style={{ 
          padding: '40px', 
          textAlign: 'center',
          minHeight: '50vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <div style={{
            backgroundColor: '#fef2f2',
            border: '1px solid #fecaca',
            borderRadius: '8px',
            padding: '32px',
            maxWidth: '500px'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>🚫</div>
            <h3 style={{ color: '#dc2626', marginBottom: '16px' }}>
              접근 권한이 없습니다
            </h3>
            <p style={{ marginBottom: '24px', color: '#6b7280', lineHeight: '1.5' }}>
              스튜디오 관리는 시스템 관리자와 스케줄 관리자만 접근할 수 있습니다.
              <br />
              권한이 필요하시면 시스템 관리자에게 문의해주세요.
            </p>
            <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
              <button 
                onClick={() => router.push('/')}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '500'
                }}
              >
                홈으로 돌아가기
              </button>
              <button 
                onClick={() => router.push('/login')}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#6b7280',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '500'
                }}
              >
                다시 로그인
              </button>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <Head>
        <title>스튜디오 관리 - 에듀윌 스케줄 시스템</title>
        <meta name="description" content="스튜디오 촬영 스케줄 관리 및 드래그 앤 드롭 기능" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      
      <div style={{
        height: '100%',
        overflow: 'hidden',
        padding: '0',
        margin: '0',
        display: 'flex',
        flexDirection: 'column'
      }}>
        <StudioAdminPanel currentUserRole={currentUserRole} />
      </div>
    </Layout>
  );
};

export default StudioAdminPage;
