"use client";
import AccessControlTest from '../components/AccessControlTest';

export default function TestAccessPage() {
  return <AccessControlTest />;
}
