// Shooter ?�태 조회 API 
export default function handler() {} 
