// Shooter 배정 API 
export default function handler() {} 
