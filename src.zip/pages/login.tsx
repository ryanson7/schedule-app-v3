import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { supabase, checkSession } from '../utils/supabaseClient';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  // 페이지 로드 시 기존 세션 확인
  useEffect(() => {
    const checkExistingSession = async () => {
      try {
        const session = await checkSession();
        
        if (session) {
          console.log('✅ 기존 세션 발견:', session.user.email);
          
          // 사용자 역할 확인
          const { data: userData } = await supabase
            .from('users')
            .select('role, name, username')
            .eq('email', session.user.email)
            .single();
          
          if (userData) {
            localStorage.setItem('userEmail', session.user.email);
            localStorage.setItem('userRole', userData.role);
            localStorage.setItem('userName', userData.name);
            localStorage.setItem('username', userData.username);
            
            // 역할별 리다이렉션
            if (userData.role === 'academy_manager' || userData.role === 'manager') {
              router.push('/academy-schedules');
            } else if (userData.role === 'studio_admin') {
              router.push('/studio-admin');
            } else if (userData.role === 'system_admin') {
              router.push('/');
            } else {
              router.push('/');
            }
            return;
          }
        }
      } catch (error) {
        console.error('기존 세션 확인 오류:', error);
      } finally {
        setChecking(false);
      }
    };

    checkExistingSession();
  }, [router]);

  // 🔥 세션 안정화된 로그인 처리
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      console.log('🔍 로그인 시도:', username);

      // 1. username으로 사용자 조회
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id, username, email, name, role, password_hash')
        .eq('username', username)
        .eq('is_active', true)
        .single();

      if (userError || !userData) {
        throw new Error('아이디 또는 비밀번호가 잘못되었습니다');
      }

      // 2. 비밀번호 확인 (임시로 평문 비교)
      if (password !== 'password123') {
        throw new Error('아이디 또는 비밀번호가 잘못되었습니다');
      }

      console.log('✅ 인증 성공:', userData.username);

      // 3. 🔥 Supabase Auth 세션 생성 (실제 이메일/비밀번호로)
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: userData.email,
        password: 'temp_password_123'  // 임시 비밀번호
      });

      if (authError) {
        console.warn('Supabase Auth 실패, 수동 세션 생성:', authError);
        
        // Auth 실패 시 수동으로 세션 데이터 생성
        const mockSession = {
          user: {
            id: userData.id,
            email: userData.email,
            user_metadata: {
              username: userData.username,
              name: userData.name,
              role: userData.role
            }
          },
          access_token: 'mock_token_' + Date.now(),
          refresh_token: 'mock_refresh_' + Date.now(),
          expires_at: Math.floor(Date.now() / 1000) + 3600 // 1시간 후 만료
        };
        
        // 로컬스토리지에 세션 정보 저장
        localStorage.setItem('supabase.auth.token', JSON.stringify(mockSession));
      }

      // 4. 세션 안정화를 위한 대기
      await new Promise(resolve => setTimeout(resolve, 500));

      // 5. 세션 확인
      const session = await checkSession();
      if (!session) {
        console.warn('세션 생성 실패, 로컬 세션으로 진행');
        // 세션이 없어도 로컬스토리지 정보로 진행
      } else {
        console.log('✅ 세션 확인 완료');
      }

      // 6. 로컬스토리지에 정보 저장
      localStorage.setItem('username', userData.username);
      localStorage.setItem('userEmail', userData.email);
      localStorage.setItem('userRole', userData.role);
      localStorage.setItem('userName', userData.name);
      localStorage.setItem('isAuthenticated', 'true');

      console.log(`로그인 성공: ${userData.name} (${userData.role})`);

      // 7. 세션 안정화를 위한 추가 대기
      await new Promise(resolve => setTimeout(resolve, 200));

      // 8. 역할별 리다이렉션
      if (userData.role === 'academy_manager' || userData.role === 'manager') {
        console.log('역할', userData.role, '→ 리다이렉션: /academy-schedules');
        router.push('/academy-schedules');
      } else if (userData.role === 'studio_admin') {
        console.log('역할', userData.role, '→ 리다이렉션: /studio-admin');
        router.push('/studio-admin');
      } else if (userData.role === 'system_admin') {
        console.log('역할', userData.role, '→ 리다이렉션: /');
        router.push('/');
      } else {
        console.log('역할', userData.role, '→ 리다이렉션: /');
        router.push('/');
      }

    } catch (error) {
      console.error('로그인 오류:', error);
      alert('로그인에 실패했습니다: ' + (error instanceof Error ? error.message : '알 수 없는 오류'));
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh'
      }}>
        기존 세션을 확인하는 중...
      </div>
    );
  }

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      backgroundColor: '#f3f4f6'
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: '2rem',
        borderRadius: '8px',
        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
        width: '100%',
        maxWidth: '400px'
      }}>
        <h1 style={{
          fontSize: '1.5rem',
          fontWeight: 'bold',
          marginBottom: '1.5rem',
          textAlign: 'center'
        }}>
          로그인
        </h1>

        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: '1rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: '500'
            }}>
              아이디
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="아이디를 입력하세요"
              required
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #d1d5db',
                borderRadius: '4px',
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              fontWeight: '500'
            }}>
              비밀번호
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="비밀번호를 입력하세요"
              required
              style={{
                width: '100%',
                padding: '0.75rem',
                border: '1px solid #d1d5db',
                borderRadius: '4px',
                fontSize: '1rem'
              }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '0.75rem',
              backgroundColor: loading ? '#9ca3af' : '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              fontSize: '1rem',
              fontWeight: '500',
              cursor: loading ? 'not-allowed' : 'pointer'
            }}
          >
            {loading ? '로그인 중...' : '로그인'}
          </button>
        </form>

        <div style={{ 
          marginTop: '1rem', 
          textAlign: 'center',
          fontSize: '0.875rem',
          color: '#6b7280'
        }}>
          <p>테스트 계정:</p>
          <p>아이디: admin001 / 비밀번호: password123</p>
          <p>아이디: manager001 / 비밀번호: password123</p>
        </div>
      </div>
    </div>
  );
}
