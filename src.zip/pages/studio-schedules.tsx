"use client";
import { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";

const generateTimeOptions = () => {
  const times = [];
  for (let hour = 9; hour < 22; hour++) {
    for (let min = 0; min < 60; min += 30) {
      const h = hour.toString().padStart(2, "0");
      const m = min.toString().padStart(2, "0");
      times.push(`${h}:${m}`);
    }
  }
  return times;
};

const timeOptions = generateTimeOptions();

interface StudioScheduleFormData {
  shoot_date: string;
  start_time: string;
  end_time: string;
  course_name: string;
  notes: string;
}

export default function StudioSchedulePage() {
  const [userInfo, setUserInfo] = useState<any>(null);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const [showMyRequests, setShowMyRequests] = useState(false);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [formData, setFormData] = useState<StudioScheduleFormData>({
    shoot_date: '',
    start_time: '',
    end_time: '',
    course_name: '',
    notes: ''
  });

  useEffect(() => {
    fetchUserInfo();
  }, []);

  useEffect(() => {
    if (userInfo && showMyRequests) {
      fetchMyRequests();
    }
  }, [userInfo, showMyRequests]);

  // 사용자 정보 조회
  const fetchUserInfo = async () => {
    const userRole = localStorage.getItem('userRole');
    const userEmail = localStorage.getItem('userEmail');
    
    if (userRole && userEmail) {
      setUserRoles([userRole]);
      
      const mockUserInfo = {
        id: 201,
        name: '김교수',
        email: userEmail,
        preferred_shooting_type: 'PPT',
        department: '컴퓨터공학과'
      };
      
      setUserInfo(mockUserInfo);
    }
  };

  // 내 촬영 요청 목록 조회
  const fetchMyRequests = async () => {
    const { data } = await supabase
      .from('schedules')
      .select(`
        *,
        sub_locations(name, main_locations(name))
      `)
      .eq('schedule_type', 'studio')
      .eq('professor_name', userInfo.name)
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    
    setMyRequests(data || []);
  };

  // 🔥 정규화된 테이블을 사용한 스튜디오 ID 조회
  const getValidStudioIdSafe = async (shootingType: string) => {
    try {
      // 1. 주요 촬영형식으로 매칭
      const { data: primaryMatch } = await supabase
        .from('sub_location_shooting_types')
        .select(`
          sub_location_id,
          sub_locations!inner(id, name, is_active),
          shooting_types!inner(name)
        `)
        .eq('shooting_types.name', shootingType)
        .eq('is_primary', true)
        .eq('sub_locations.is_active', true)
        .limit(1);

      if (primaryMatch && primaryMatch.length > 0) {
        console.log(`정규화된 매칭: ${shootingType} → 스튜디오 ID ${primaryMatch[0].sub_location_id}`);
        return primaryMatch[0].sub_location_id;
      }

      // 2. 보조 촬영형식으로 재시도
      const { data: secondaryMatch } = await supabase
        .from('sub_location_shooting_types')
        .select(`
          sub_location_id,
          sub_locations!inner(id, name, is_active),
          shooting_types!inner(name)
        `)
        .eq('shooting_types.name', shootingType)
        .eq('is_primary', false)
        .eq('sub_locations.is_active', true)
        .limit(1);

      if (secondaryMatch && secondaryMatch.length > 0) {
        console.log(`보조 매칭: ${shootingType} → 스튜디오 ID ${secondaryMatch[0].sub_location_id}`);
        return secondaryMatch[0].sub_location_id;
      }

      throw new Error('매칭되는 스튜디오를 찾을 수 없습니다.');
    } catch (error) {
      console.error('정규화된 스튜디오 조회 오류:', error);
      // 기본 스튜디오 반환
      const { data: fallback } = await supabase
        .from('sub_locations')
        .select('id')
        .ilike('name', '%스튜디오%')
        .eq('is_active', true)
        .limit(1);
      
      return fallback?.[0]?.id || 1;
    }
  };

  // 촬영 요청 제출
  const submitShootingRequest = async () => {
    if (!formData.shoot_date || !formData.start_time || !formData.end_time) {
      alert('필수 항목을 모두 입력해주세요.');
      return;
    }

    // 🔥 정규화된 테이블을 사용한 스튜디오 자동 배정
    const validStudioId = await getValidStudioIdSafe(userInfo?.preferred_shooting_type || 'PPT');

    const requestData = {
      ...formData,
      professor_name: userInfo.name,
      shooting_type: userInfo.preferred_shooting_type,
      schedule_type: 'studio',
      approval_status: 'pending',
      team_id: 1,
      sub_location_id: validStudioId,
      is_active: true,
      created_at: new Date().toISOString()
    };

    const { error } = await supabase.from('schedules').insert([requestData]);
    
    if (error) {
      console.error('상세 오류:', error);
      alert('촬영 요청 오류: ' + error.message);
    } else {
      alert('촬영 요청이 제출되었습니다.');
      resetForm();
      if (showMyRequests) {
        fetchMyRequests();
      }
    }
  };

  const resetForm = () => {
    setFormData({
      shoot_date: '',
      start_time: '',
      end_time: '',
      course_name: '',
      notes: ''
    });
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'approved':
        return { bg: '#e8f5e8', color: '#155724', text: '촬영확정', icon: '✓' };
      case 'pending':
        return { bg: '#fff3cd', color: '#856404', text: '검토중', icon: '⏳' };
      case 'cancelled':
        return { bg: '#f8d7da', color: '#721c24', text: '취소됨', icon: '✗' };
      default:
        return { bg: '#f0f0f0', color: '#666', text: '기타', icon: '?' };
    }
  };

  const isProfessor = userRoles.includes('professor') || userRoles.includes('professor');

  if (!isProfessor) {
    return (
      <div style={{ 
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}>
        <div style={{ 
          background: 'white',
          borderRadius: '20px',
          padding: '40px',
          textAlign: 'center',
          boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
          maxWidth: '400px',
          width: '100%'
        }}>
          <h2 style={{ color: '#2c3e50', marginBottom: '20px' }}>스튜디오 촬영 시스템</h2>
          <p style={{ color: '#666', marginBottom: '30px' }}>교수님만 접근 가능한 시스템입니다.</p>
          <button 
            onClick={() => {
              localStorage.setItem('userRole', 'professor');
              localStorage.setItem('userEmail', 'test@professor.com');
              window.location.reload();
            }}
            style={{ 
              padding: '12px 24px',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '25px',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: 'bold',
              boxShadow: '0 8px 16px rgba(102, 126, 234, 0.3)'
            }}
          >
            테스트용 교수 로그인
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
      padding: '10px'
    }}>
      <div style={{ 
        maxWidth: '600px', 
        margin: '0 auto', 
        padding: '0 10px'
      }}>
        {/* 통합된 인사 및 촬영 요청 구간 */}
        <div style={{ 
          background: 'white',
          borderRadius: '20px',
          padding: 'clamp(20px, 5vw, 40px)',
          marginBottom: '20px',
          boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
        }}>
          {/* 로고 및 인사말 구간 */}
          <div style={{ 
            textAlign: 'center',
            marginBottom: 'clamp(20px, 5vw, 30px)',
            paddingBottom: 'clamp(15px, 4vw, 25px)',
            borderBottom: '1px solid #ecf0f1'
          }}>
            <div style={{ 
              width: 'clamp(60px, 15vw, 80px)',
              height: 'clamp(60px, 15vw, 80px)',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              margin: '0 auto 15px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 'clamp(24px, 6vw, 32px)',
              color: 'white'
            }}>
              📹
            </div>
            <h1 style={{ 
              color: '#2c3e50', 
              fontSize: 'clamp(20px, 5vw, 28px)', 
              marginBottom: '8px',
              fontWeight: '700',
              lineHeight: '1.2'
            }}>
              안녕하세요. {userInfo?.name} 교수님
            </h1>
            <p style={{ 
              color: '#7f8c8d', 
              fontSize: 'clamp(14px, 3.5vw, 16px)',
              margin: '0 0 15px 0'
            }}>
              에듀윌 영상개발실입니다.
            </p>
            <p style={{ 
              color: '#95a5a6',
              fontSize: 'clamp(12px, 3vw, 14px)',
              margin: 0
            }}>
              촬영이 필요한 날짜와 시간을 선택해 주세요.
            </p>
          </div>
          
          {/* 촬영 요청 폼 */}
          <div style={{ display: 'grid', gap: 'clamp(15px, 4vw, 25px)' }}>
            {/* 날짜 선택 */}
            <div>
              <label style={{ 
                display: 'block', 
                marginBottom: '8px', 
                fontWeight: '600', 
                color: '#34495e',
                fontSize: 'clamp(14px, 3.5vw, 16px)'
              }}>
                촬영 날짜 *
              </label>
              <input 
                type="date" 
                value={formData.shoot_date} 
                onChange={(e) => setFormData({...formData, shoot_date: e.target.value})} 
                style={{ 
                  width: '100%', 
                  padding: 'clamp(12px, 3vw, 16px)', 
                  border: '2px solid #dee2e6', 
                  borderRadius: '12px',
                  fontSize: 'clamp(14px, 3.5vw, 16px)',
                  transition: 'all 0.3s ease',
                  outline: 'none',
                  boxSizing: 'border-box'
                }} 
                onFocus={(e) => e.target.style.borderColor = '#667eea'}
                onBlur={(e) => e.target.style.borderColor = '#dee2e6'}
                required 
              />
            </div>

            {/* 시간 설정 */}
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: window.innerWidth < 480 ? '1fr' : '1fr 1fr',
              gap: 'clamp(10px, 3vw, 20px)'
            }}>
              <div>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '8px', 
                  fontWeight: '600', 
                  color: '#34495e',
                  fontSize: 'clamp(14px, 3.5vw, 16px)'
                }}>
                  시작 시간 *
                </label>
                <select 
                  value={formData.start_time} 
                  onChange={(e) => setFormData({...formData, start_time: e.target.value})} 
                  style={{ 
                    width: '100%', 
                    padding: 'clamp(12px, 3vw, 16px)', 
                    border: '2px solid #dee2e6', 
                    borderRadius: '12px',
                    fontSize: 'clamp(14px, 3.5vw, 16px)',
                    background: 'white',
                    transition: 'all 0.3s ease',
                    outline: 'none',
                    boxSizing: 'border-box'
                  }} 
                  onFocus={(e) => e.target.style.borderColor = '#667eea'}
                  onBlur={(e) => e.target.style.borderColor = '#dee2e6'}
                  required
                >
                  <option value="">시작 시간 선택</option>
                  {timeOptions.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ 
                  display: 'block', 
                  marginBottom: '8px', 
                  fontWeight: '600', 
                  color: '#34495e',
                  fontSize: 'clamp(14px, 3.5vw, 16px)'
                }}>
                  종료 시간 *
                </label>
                <select 
                  value={formData.end_time} 
                  onChange={(e) => setFormData({...formData, end_time: e.target.value})} 
                  style={{ 
                    width: '100%', 
                    padding: 'clamp(12px, 3vw, 16px)', 
                    border: '2px solid #dee2e6', 
                    borderRadius: '12px',
                    fontSize: 'clamp(14px, 3.5vw, 16px)',
                    background: 'white',
                    transition: 'all 0.3s ease',
                    outline: 'none',
                    boxSizing: 'border-box'
                  }} 
                  onFocus={(e) => e.target.style.borderColor = '#667eea'}
                  onBlur={(e) => e.target.style.borderColor = '#dee2e6'}
                  required
                >
                  <option value="">종료 시간 선택</option>
                  {timeOptions.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* 강좌명 */}
            <div>
              <label style={{ 
                display: 'block', 
                marginBottom: '8px', 
                fontWeight: '600', 
                color: '#34495e',
                fontSize: 'clamp(14px, 3.5vw, 16px)'
              }}>
                강좌명
              </label>
              <input 
                type="text" 
                value={formData.course_name} 
                onChange={(e) => setFormData({...formData, course_name: e.target.value})} 
                placeholder="예: 데이터베이스 설계"
                style={{ 
                  width: '100%', 
                  padding: 'clamp(12px, 3vw, 16px)', 
                  border: '2px solid #dee2e6', 
                  borderRadius: '12px',
                  fontSize: 'clamp(14px, 3.5vw, 16px)',
                  transition: 'all 0.3s ease',
                  outline: 'none',
                  boxSizing: 'border-box'
                }} 
                onFocus={(e) => e.target.style.borderColor = '#667eea'}
                onBlur={(e) => e.target.style.borderColor = '#dee2e6'}
              />
            </div>

            {/* 전달사항 */}
            <div>
              <label style={{ 
                display: 'block', 
                marginBottom: '8px', 
                fontWeight: '600', 
                color: '#34495e',
                fontSize: 'clamp(14px, 3.5vw, 16px)'
              }}>
                전달사항
              </label>
              <textarea 
                value={formData.notes} 
                onChange={(e) => setFormData({...formData, notes: e.target.value})} 
                placeholder="촬영 시 특별히 요청하실 사항이 있으시면 입력해주세요."
                style={{ 
                  width: '100%', 
                  padding: 'clamp(12px, 3vw, 16px)', 
                  border: '2px solid #dee2e6', 
                  borderRadius: '12px', 
                  minHeight: 'clamp(80px, 20vw, 100px)',
                  fontSize: 'clamp(14px, 3.5vw, 16px)',
                  resize: 'vertical',
                  transition: 'all 0.3s ease',
                  outline: 'none',
                  fontFamily: 'inherit',
                  boxSizing: 'border-box'
                }} 
                onFocus={(e) => e.target.style.borderColor = '#667eea'}
                onBlur={(e) => e.target.style.borderColor = '#dee2e6'}
              />
            </div>

            {/* 촬영 요청 버튼 */}
            <div style={{ marginTop: 'clamp(10px, 3vw, 20px)' }}>
              <button 
                onClick={submitShootingRequest}
                style={{ 
                  width: '100%',
                  padding: 'clamp(14px, 4vw, 18px)', 
                  background: 'linear-gradient(135deg, #667eea, #764ba2)', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: '12px', 
                  cursor: 'pointer', 
                  fontSize: 'clamp(16px, 4vw, 18px)',
                  fontWeight: 'bold',
                  boxShadow: '0 8px 16px rgba(102, 126, 234, 0.3)',
                  transition: 'all 0.3s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 12px 24px rgba(102, 126, 234, 0.4)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 8px 16px rgba(102, 126, 234, 0.3)';
                }}
              >
                촬영 요청
              </button>
            </div>
          </div>
        </div>

        {/* 내 요청 목록 토글 버튼 */}
        <div style={{ 
          position: 'sticky',
          top: '10px',
          zIndex: 100,
          textAlign: 'center', 
          marginBottom: '20px' 
        }}>
          <button 
            onClick={() => setShowMyRequests(!showMyRequests)}
            style={{ 
              padding: 'clamp(10px, 3vw, 12px) clamp(20px, 5vw, 30px)',
              background: showMyRequests ? '#e74c3c' : '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '25px',
              cursor: 'pointer',
              fontSize: 'clamp(14px, 3.5vw, 16px)',
              fontWeight: 'bold',
              boxShadow: '0 6px 12px rgba(0,0,0,0.1)',
              transition: 'all 0.3s ease'
            }}
          >
            {showMyRequests ? '내 요청 목록 숨기기' : '내 요청 목록 보기'}
          </button>
        </div>

        {/* 내 촬영 요청 목록 */}
        {showMyRequests && (
          <div style={{ 
            background: 'white',
            borderRadius: '20px',
            padding: 'clamp(20px, 5vw, 40px)',
            boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
            animation: 'fadeIn 0.3s ease'
          }}>
            <h2 style={{ 
              margin: '0 0 clamp(20px, 5vw, 30px) 0', 
              color: '#2c3e50', 
              fontSize: 'clamp(20px, 5vw, 24px)',
              fontWeight: '600',
              textAlign: 'center'
            }}>
              내 촬영 요청 목록 ({myRequests.length}건)
            </h2>
            
            {myRequests.length === 0 ? (
              <div style={{ 
                textAlign: 'center', 
                padding: 'clamp(40px, 10vw, 60px)', 
                color: '#7f8c8d',
                fontSize: 'clamp(16px, 4vw, 18px)'
              }}>
                <div style={{ fontSize: 'clamp(36px, 10vw, 48px)', marginBottom: '20px' }}>📝</div>
                아직 등록된 촬영 요청이 없습니다.
              </div>
            ) : (
              <div style={{ display: 'grid', gap: 'clamp(15px, 4vw, 20px)' }}>
                {myRequests.map((request, index) => {
                  const statusInfo = getStatusInfo(request.approval_status);
                  
                  return (
                    <div 
                      key={request.id} 
                      style={{ 
                        padding: 'clamp(15px, 4vw, 25px)', 
                        border: '2px solid #ecf0f1', 
                        borderRadius: '15px',
                        background: '#fafbfc',
                        transition: 'all 0.3s ease',
                        position: 'relative',
                        overflow: 'hidden'
                      }}
                    >
                      <div style={{ 
                        position: 'absolute',
                        top: 0,
                        right: 0,
                        width: '4px',
                        height: '100%',
                        background: statusInfo.color
                      }} />
                      
                      <div style={{ 
                        display: 'flex', 
                        flexDirection: window.innerWidth < 480 ? 'column' : 'row',
                        justifyContent: 'space-between', 
                        alignItems: window.innerWidth < 480 ? 'flex-start' : 'flex-start', 
                        marginBottom: '15px',
                        gap: '10px'
                      }}>
                        <div style={{ flex: 1 }}>
                          <h3 style={{ 
                            margin: '0 0 8px 0', 
                            color: '#2c3e50', 
                            fontSize: 'clamp(16px, 4vw, 20px)',
                            fontWeight: '600'
                          }}>
                            {request.course_name || '강좌명 미입력'}
                          </h3>
                          <div style={{ 
                            color: '#7f8c8d', 
                            fontSize: 'clamp(14px, 3.5vw, 16px)',
                            fontWeight: '500'
                          }}>
                            {request.shoot_date} | {request.start_time?.substring(0, 5)}~{request.end_time?.substring(0, 5)}
                          </div>
                        </div>
                        <div style={{
                          padding: '8px 16px',
                          borderRadius: '20px',
                          fontSize: 'clamp(12px, 3vw, 14px)',
                          fontWeight: 'bold',
                          background: statusInfo.bg,
                          color: statusInfo.color,
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          whiteSpace: 'nowrap'
                        }}>
                          <span>{statusInfo.icon}</span>
                          {statusInfo.text}
                        </div>
                      </div>
                      
                      {/* 배정 스튜디오 */}
                      <div style={{ 
                        padding: '12px',
                        background: 'white',
                        borderRadius: '8px',
                        border: '1px solid #ecf0f1',
                        marginBottom: '15px'
                      }}>
                        <strong style={{ 
                          color: '#34495e',
                          fontSize: 'clamp(12px, 3vw, 14px)'
                        }}>배정 스튜디오</strong><br />
                        <span style={{ 
                          color: '#2c3e50',
                          fontSize: 'clamp(14px, 3.5vw, 16px)'
                        }}>
                          {request.sub_locations?.name || '0번 스튜디오'}
                        </span>
                      </div>
                      
                      <div style={{ 
                        fontSize: 'clamp(10px, 2.5vw, 12px)', 
                        color: '#95a5a6',
                        textAlign: 'right'
                      }}>
                        요청일시: {new Date(request.created_at).toLocaleString('ko-KR')}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
