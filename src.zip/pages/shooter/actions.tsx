// Shooter ?�션 ?�이지 
export default function ShooterActions() {} 
