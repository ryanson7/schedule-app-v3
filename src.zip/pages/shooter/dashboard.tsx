"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import ShooterDashboard from '../../components/shooter/ShooterDashboard';
import ActionButtons from '../../components/shooter/ActionButtons';
import NotificationCenter from '../../components/notifications/NotificationCenter';
import { Schedule, Shooter } from '../../types/shooter';
import { supabase } from '../../utils/supabaseClient';

export default function ShooterDashboardPage() {
  const router = useRouter();
  const [shooterInfo, setShooterInfo] = useState<Shooter | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'actions' | 'notifications'>('dashboard');
  const [todaySchedule, setTodaySchedule] = useState<Schedule | null>(null);

  useEffect(() => {
    checkShooterAuth();
  }, []);

  const checkShooterAuth = async () => {
    try {
      // 현재 로그인한 shooter 정보 확인 (실제로는 인증 시스템에서)
      const shooterId = localStorage.getItem('shooterId');
      const userRole = localStorage.getItem('userRole');

      if (!shooterId || userRole !== 'shooter') {
        router.push('/login');
        return;
      }

      // Shooter 정보 조회
      const { data: shooter, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', shooterId)
        .eq('role', 'shooter')
        .eq('deleted_at', null)
        .single();

      if (error || !shooter) {
        console.error('Shooter 정보 조회 오류:', error);
        router.push('/login');
        return;
      }

      setShooterInfo(shooter);

      // 오늘 스케줄 조회
      await loadTodaySchedule(parseInt(shooterId));

    } catch (error) {
      console.error('인증 확인 오류:', error);
      router.push('/login');
    } finally {
      setIsLoading(false);
    }
  };

  const loadTodaySchedule = async (shooterId: number) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const { data: schedule, error } = await supabase
        .from('schedules')
        .select(`
          *,
          sub_locations(name, main_location_id, main_locations(name))
        `)
        .eq('assigned_shooter_id', shooterId)
        .eq('shoot_date', today)
        .eq('is_active', true)
        .single();

      if (!error && schedule) {
        const scheduleWithLocation = {
          ...schedule,
          location_name: schedule.sub_locations?.name,
          main_location_name: schedule.sub_locations?.main_locations?.name,
          main_location_id: schedule.sub_locations?.main_location_id
        };
        setTodaySchedule(scheduleWithLocation);
      }
    } catch (error) {
      console.error('오늘 스케줄 조회 오류:', error);
    }
  };

  const handleActionComplete = (actionType: string) => {
    // 액션 완료 후 데이터 새로고침
    if (shooterInfo) {
      loadTodaySchedule(shooterInfo.id);
    }
    
    // 완료 메시지 표시
    const actionNames = {
      'schedule_check': '스케줄 확인',
      'departure': '출발',
      'arrival': '도착',
      'start': '촬영 시작',
      'end': '촬영 종료',
      'completion': '업무 완료'
    };
    
    const actionName = actionNames[actionType as keyof typeof actionNames] || actionType;
    
    // 간단한 성공 메시지 (실제로는 토스트 알림 등 사용)
    setTimeout(() => {
      alert(`${actionName}이 완료되었습니다!`);
    }, 100);
  };

  if (isLoading) {
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        background: '#f8fafc',
        gap: '16px'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid #3b82f6',
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }} />
        <div style={{
          fontSize: '18px',
          color: '#64748b',
          fontWeight: '500'
        }}>
          Shooter 대시보드를 준비하는 중...
        </div>
        
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  if (!shooterInfo) {
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        background: '#f8fafc',
        gap: '20px'
      }}>
        <div style={{
          fontSize: '24px',
          color: '#ef4444',
          fontWeight: '600'
        }}>
          접근 권한이 없습니다
        </div>
        <div style={{
          fontSize: '16px',
          color: '#64748b',
          textAlign: 'center',
          lineHeight: 1.5
        }}>
          Shooter 권한이 필요합니다.<br/>
          로그인 후 다시 시도해주세요.
        </div>
        <button
          onClick={() => router.push('/login')}
          style={{
            padding: '12px 24px',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            fontSize: '16px',
            fontWeight: '500',
            cursor: 'pointer'
          }}
        >
          로그인 페이지로 이동
        </button>
      </div>
    );
  }

  return (
    <div style={{
      background: '#f8fafc',
      minHeight: '100vh',
      fontFamily: 'inherit'
    }}>
      {/* 모바일 헤더 */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        padding: '16px 20px',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '12px'
        }}>
          <div>
            <h1 style={{
              margin: '0 0 4px 0',
              fontSize: '20px',
              fontWeight: '600'
            }}>
              Shooter 대시보드
            </h1>
            <p style={{
              margin: 0,
              fontSize: '14px',
              opacity: 0.9
            }}>
              안녕하세요, {shooterInfo.name}님!
            </p>
          </div>
          
          <div style={{
            background: 'rgba(255, 255, 255, 0.2)',
            padding: '8px 12px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: '500'
          }}>
            {new Date().toLocaleDateString('ko-KR', {
              month: 'short',
              day: 'numeric',
              weekday: 'short'
            })}
          </div>
        </div>

        {/* 탭 네비게이션 */}
        <div style={{
          display: 'flex',
          gap: '4px',
          background: 'rgba(255, 255, 255, 0.1)',
          padding: '4px',
          borderRadius: '8px'
        }}>
          {[
            { key: 'dashboard', label: '대시보드', icon: '📊' },
            { key: 'actions', label: '액션', icon: '🎬' },
            { key: 'notifications', label: '알림', icon: '🔔' }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              style={{
                flex: 1,
                padding: '8px 12px',
                background: activeTab === tab.key ? 'white' : 'transparent',
                color: activeTab === tab.key ? '#667eea' : 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px'
              }}
            >
              <span>{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 메인 콘텐츠 */}
      <div style={{ padding: '20px' }}>
        {/* 오늘 스케줄 요약 (모든 탭에서 표시) */}
        {todaySchedule && (
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '16px',
            marginBottom: '20px',
            border: '1px solid #e2e8f0',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '8px'
            }}>
              <h3 style={{
                margin: 0,
                fontSize: '16px',
                fontWeight: '600',
                color: '#1e293b'
              }}>
                오늘의 촬영
              </h3>
              <div style={{
                background: getStatusColor(todaySchedule.tracking_status),
                color: 'white',
                padding: '4px 8px',
                borderRadius: '12px',
                fontSize: '11px',
                fontWeight: '600'
              }}>
                {getStatusText(todaySchedule.tracking_status)}
              </div>
            </div>
            
            <div style={{
              fontSize: '18px',
              fontWeight: '600',
              color: '#1e293b',
              marginBottom: '4px'
            }}>
              {todaySchedule.course_name}
            </div>
            
            <div style={{
              fontSize: '14px',
              color: '#64748b',
              marginBottom: '2px'
            }}>
              교수: {todaySchedule.professor_name}
            </div>
            
            <div style={{
              fontSize: '14px',
              color: '#64748b',
              marginBottom: '8px'
            }}>
              시간: {todaySchedule.start_time.substring(0, 5)} - {todaySchedule.end_time.substring(0, 5)}
            </div>
            
            <div style={{
              fontSize: '13px',
              color: '#64748b'
            }}>
              위치: {todaySchedule.main_location_name} - {todaySchedule.location_name}
            </div>
          </div>
        )}

        {/* 탭별 콘텐츠 */}
        {activeTab === 'dashboard' && (
          <ShooterDashboard />
        )}

        {activeTab === 'actions' && (
          <div>
            <h2 style={{
              fontSize: '18px',
              fontWeight: '600',
              color: '#1e293b',
              marginBottom: '16px'
            }}>
              액션 수행
            </h2>
            <ActionButtons
              schedule={todaySchedule}
              onActionComplete={handleActionComplete}
            />
          </div>
        )}

        {activeTab === 'notifications' && (
          <div>
            <h2 style={{
              fontSize: '18px',
              fontWeight: '600',
              color: '#1e293b',
              marginBottom: '16px'
            }}>
              알림 센터
            </h2>
            <NotificationCenter
              userId={shooterInfo.id}
              userRole={shooterInfo.role}
              maxNotifications={30}
              autoMarkRead={true}
            />
          </div>
        )}
      </div>

      {/* 하단 고정 액션 버튼 (액션 탭이 아닐 때만 표시) */}
      {activeTab !== 'actions' && todaySchedule && (
        <div style={{
          position: 'fixed',
          bottom: '20px',
          right: '20px',
          zIndex: 50
        }}>
          <button
            onClick={() => setActiveTab('actions')}
            style={{
              width: '60px',
              height: '60px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: 'white',
              border: 'none',
              fontSize: '24px',
              cursor: 'pointer',
              boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)',
              transition: 'all 0.2s'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'scale(1.1)';
              e.currentTarget.style.boxShadow = '0 6px 16px rgba(102, 126, 234, 0.5)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'scale(1)';
              e.currentTarget.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)';
            }}
          >
            🎬
          </button>
        </div>
      )}
    </div>
  );
}

// 유틸리티 함수들
function getStatusColor(status: string): string {
  const colors = {
    'scheduled': '#64748b',
    'schedule_check': '#3b82f6',
    'departure': '#f59e0b',
    'arrival': '#10b981',
    'start': '#8b5cf6',
    'end': '#ef4444',
    'completion': '#059669'
  };
  return colors[status as keyof typeof colors] || '#64748b';
}

function getStatusText(status: string): string {
  const statusTexts = {
    'scheduled': '대기중',
    'schedule_check': '스케줄확인완료',
    'departure': '이동중',
    'arrival': '도착완료',
    'start': '촬영중',
    'end': '촬영완료',
    'completion': '업무완료'
  };
  return statusTexts[status as keyof typeof statusTexts] || '미정';
}

// Next.js 정적 생성 설정
export async function getStaticProps() {
  return {
    props: {
      title: 'Shooter 대시보드',
      description: 'Shooter 전용 대시보드 - 스케줄 확인 및 액션 수행'
    }
  };
}
