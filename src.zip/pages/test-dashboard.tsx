// src/pages/test-dashboard.tsx
import { useState, useEffect } from 'react';
import { supabase } from '../utils/supabaseClient';

export default function TestDashboard() {
  const [shooters, setShooters] = useState([]);
  const [schedules, setSchedules] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    // Shooter 목록 조회
    const { data: shooterData } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('role', 'shooter');

    // 배정된 스케줄 조회
    const { data: scheduleData } = await supabase
      .from('schedules')
      .select(`
        *,
        user_profiles(name, shooter_type)
      `)
      .not('assigned_shooter_id', 'is', null);

    setShooters(shooterData || []);
    setSchedules(scheduleData || []);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>🎬 Shooter 트랙킹 시스템 테스트</h1>
      
      <div style={{ marginBottom: '20px' }}>
        <h2>📷 등록된 Shooter ({shooters.length}명)</h2>
        {shooters.map((shooter: any) => (
          <div key={shooter.id} style={{ 
            padding: '10px', 
            border: '1px solid #ccc', 
            margin: '5px 0' 
          }}>
            {shooter.name} ({shooter.shooter_type})
          </div>
        ))}
      </div>

      <div>
        <h2>📅 배정된 스케줄 ({schedules.length}건)</h2>
        {schedules.map((schedule: any) => (
          <div key={schedule.id} style={{ 
            padding: '10px', 
            border: '1px solid #ccc', 
            margin: '5px 0' 
          }}>
            {schedule.course_name} - {schedule.user_profiles?.name}
            <br />
            <small>{schedule.shoot_date} {schedule.start_time}</small>
          </div>
        ))}
      </div>
    </div>
  );
}
