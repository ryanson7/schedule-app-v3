"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../utils/supabaseClient';

export default function HomePage() {
  const router = useRouter();
  const [userRole, setUserRole] = useState<string | null>(null);
  const [userName, setUserName] = useState<string | null>(null);
  const [todaySchedules, setTodaySchedules] = useState<any[]>([]);
  const [weeklyStats, setWeeklyStats] = useState({
    studio: 0,
    academy: 0,
    internal: 0,
    total: 0
  });

  useEffect(() => {
    checkUserInfo();
    fetchTodaySchedules();
    fetchWeeklyStats();
  }, []);

  const checkUserInfo = () => {
    const role = localStorage.getItem('userRole');
    const email = localStorage.getItem('userEmail');
    setUserRole(role);
    setUserName(email);
  };

  const fetchTodaySchedules = async () => {
    const today = new Date().toISOString().split('T')[0];
    
    const { data } = await supabase
      .from('schedules')
      .select('*, sub_locations(name, main_locations(name))')
      .eq('shoot_date', today)
      .eq('is_active', true)
      .order('start_time')
      .limit(5);
    
    setTodaySchedules(data || []);
  };

  const fetchWeeklyStats = async () => {
    const startOfWeek = new Date();
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    const startDate = startOfWeek.toISOString().split('T')[0];
    const endDate = endOfWeek.toISOString().split('T')[0];

    const { data } = await supabase
      .from('schedules')
      .select('schedule_type')
      .gte('shoot_date', startDate)
      .lte('shoot_date', endDate)
      .eq('is_active', true);

    if (data) {
      const stats = {
        studio: data.filter(s => s.schedule_type === 'studio').length,
        academy: data.filter(s => s.schedule_type === 'academy').length,
        internal: 0,
        total: data.length
      };
      setWeeklyStats(stats);
    }
  };

  const menuCards = [
    {
      title: '통합 스케줄',
      description: '모든 스케줄을 한눈에',
      path: '/all-schedules',
      color: 'var(--accent-color)',
      bgColor: '#e3f2fd'
    },
    {
      title: '학원 스케줄',
      description: '학원 촬영 관리',
      path: '/academy-schedules',
      color: '#2e7d32',
      bgColor: '#f1f8e9'
    },
    {
      title: '스튜디오 스케줄',
      description: '스튜디오 촬영 관리',
      path: '/studio-schedules',
      color: '#1565c0',
      bgColor: '#e3f2fd'
    },
    {
      title: '내부업무',
      description: '내부 업무 스케줄',
      path: '/internal-schedules',
      color: '#e65100',
      bgColor: '#fff8e1'
    },
    {
      title: '스튜디오 관리',
      description: '관리자 전용',
      path: '/studio-admin',
      color: '#7b1fa2',
      bgColor: '#f3e5f5',
      adminOnly: true
    }
  ];

  return (
    <div style={{
      width: '100%',
      minHeight: '100vh',
      background: 'var(--bg-primary)',
      padding: '20px'
    }}>
      {/* 헤더 */}
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        marginBottom: '40px'
      }}>
        <h1 style={{
          fontSize: '32px',
          fontWeight: 'bold',
          color: 'var(--text-primary)',
          marginBottom: '8px'
        }}>
          스케줄 관리 시스템
        </h1>
        <p style={{
          fontSize: '16px',
          color: 'var(--text-secondary)',
          marginBottom: '20px'
        }}>
          안녕하세요, {userName || '사용자'}님! ({userRole || '게스트'})
        </p>

        {/* 주간 통계 */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '16px',
          marginBottom: '40px'
        }}>
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '20px',
            borderRadius: '12px',
            border: '1px solid var(--border-color)',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: 'var(--accent-color)' }}>
              {weeklyStats.total}
            </div>
            <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              이번 주 전체 스케줄
            </div>
          </div>
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '20px',
            borderRadius: '12px',
            border: '1px solid var(--border-color)',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#2e7d32' }}>
              {weeklyStats.academy}
            </div>
            <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              학원 스케줄
            </div>
          </div>
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '20px',
            borderRadius: '12px',
            border: '1px solid var(--border-color)',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#1565c0' }}>
              {weeklyStats.studio}
            </div>
            <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              스튜디오 스케줄
            </div>
          </div>
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '20px',
            borderRadius: '12px',
            border: '1px solid var(--border-color)',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#e65100' }}>
              {todaySchedules.length}
            </div>
            <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              오늘 스케줄
            </div>
          </div>
        </div>
      </div>

      {/* 메인 메뉴 카드 (아이콘 제거) */}
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <h2 style={{
          fontSize: '24px',
          fontWeight: '600',
          color: 'var(--text-primary)',
          marginBottom: '24px'
        }}>
          메뉴
        </h2>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '20px',
          marginBottom: '40px'
        }}>
          {menuCards
            .filter(card => !card.adminOnly || userRole === 'admin')
            .map((card, index) => (
            <div
              key={index}
              onClick={() => router.push(card.path)}
              style={{
                background: 'var(--bg-secondary)',
                padding: '24px',
                borderRadius: '12px',
                border: '1px solid var(--border-color)',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
              }}
            >
              <h3 style={{
                fontSize: '20px',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: '8px',
                textAlign: 'center'
              }}>
                {card.title}
              </h3>
              <p style={{
                fontSize: '14px',
                color: 'var(--text-secondary)',
                textAlign: 'center',
                margin: 0
              }}>
                {card.description}
              </p>
            </div>
          ))}
        </div>

        {/* 오늘의 스케줄 */}
        {todaySchedules.length > 0 && (
          <div>
            <h2 style={{
              fontSize: '24px',
              fontWeight: '600',
              color: 'var(--text-primary)',
              marginBottom: '24px'
            }}>
              오늘의 스케줄
            </h2>
            <div style={{
              background: 'var(--bg-secondary)',
              borderRadius: '12px',
              border: '1px solid var(--border-color)',
              overflow: 'hidden'
            }}>
              {todaySchedules.map((schedule, index) => (
                <div
                  key={schedule.id}
                  style={{
                    padding: '16px 20px',
                    borderBottom: index === todaySchedules.length - 1 ? 'none' : '1px solid var(--border-color)',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div>
                    <div style={{
                      fontSize: '16px',
                      fontWeight: '600',
                      color: 'var(--text-primary)',
                      marginBottom: '4px'
                    }}>
                      {schedule.course_name} - {schedule.professor_name}
                    </div>
                    <div style={{
                      fontSize: '14px',
                      color: 'var(--text-secondary)'
                    }}>
                      {schedule.sub_locations?.main_locations?.name} - {schedule.sub_locations?.name}
                    </div>
                  </div>
                  <div style={{
                    fontSize: '14px',
                    fontWeight: '600',
                    color: 'var(--accent-color)'
                  }}>
                    {schedule.start_time?.substring(0, 5)} - {schedule.end_time?.substring(0, 5)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
