import { AppProps } from 'next/app';
import { useEffect, useState } from 'react';
import { Session } from '@supabase/supabase-js';
import { AuthProvider } from '../contexts/AuthContext';
import { WeekProvider } from '../contexts/WeekContext';
import { ThemeProvider } from '../contexts/ThemeContext';
import { supabase } from '../utils/supabaseClient';
import '../styles/globals.css';




function MyApp({ Component, pageProps }: AppProps) {
  const [initialSession, setInitialSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 앱 시작 시 세션 확인
    const getInitialSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('앱 초기 세션 조회 오류:', error);
        } else {
          setInitialSession(session);
          console.log('✅ 앱 초기 세션 설정:', session?.user?.email || '없음');
        }
      } catch (error) {
        console.error('앱 초기 세션 조회 예외:', error);
      } finally {
        setLoading(false);
      }
    };

    getInitialSession();
  }, []);

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid #3b82f6',
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }} />
        <p>앱을 초기화하는 중...</p>
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <ThemeProvider>
      <AuthProvider initialSession={initialSession}>
        <WeekProvider>
          <Component {...pageProps} />
        </WeekProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default MyApp;
