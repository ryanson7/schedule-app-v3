"use client";
import { useState, useEffect } from 'react';

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 임시 로딩 시뮬레이션
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  if (loading) {
    return (
      <div style={{
        padding: '20px',
        background: 'var(--bg-primary)',
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid var(--accent-color)',
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }} />
        
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{
      padding: '20px',
      background: 'var(--bg-primary)',
      minHeight: '100vh'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <h1 style={{
          fontSize: '24px',
          fontWeight: '600',
          color: 'var(--text-primary)',
          marginBottom: '20px'
        }}>
          알림 센터
        </h1>
        
        <div style={{
          background: 'var(--bg-secondary)',
          padding: '40px',
          borderRadius: '12px',
          border: '1px solid var(--border-color)',
          textAlign: 'center'
        }}>
          <div style={{
            fontSize: '48px',
            marginBottom: '16px'
          }}>
            🔔
          </div>
          <h2 style={{
            fontSize: '20px',
            fontWeight: '600',
            color: 'var(--text-primary)',
            marginBottom: '12px'
          }}>
            알림 센터
          </h2>
          <p style={{ 
            color: 'var(--text-secondary)',
            fontSize: '16px',
            marginBottom: '24px'
          }}>
            현재 새로운 알림이 없습니다.
          </p>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '16px',
            marginTop: '32px'
          }}>
            <div style={{
              background: 'var(--bg-primary)',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid var(--border-color)'
            }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: '8px'
              }}>
                시스템 알림
              </h3>
              <p style={{
                fontSize: '14px',
                color: 'var(--text-secondary)'
              }}>
                시스템 관련 알림이 여기에 표시됩니다.
              </p>
            </div>
            
            <div style={{
              background: 'var(--bg-primary)',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid var(--border-color)'
            }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: '8px'
              }}>
                스케줄 알림
              </h3>
              <p style={{
                fontSize: '14px',
                color: 'var(--text-secondary)'
              }}>
                스케줄 변경 및 업데이트 알림이 표시됩니다.
              </p>
            </div>
            
            <div style={{
              background: 'var(--bg-primary)',
              padding: '20px',
              borderRadius: '8px',
              border: '1px solid var(--border-color)'
            }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: '600',
                color: 'var(--text-primary)',
                marginBottom: '8px'
              }}>
              사용자 알림
              </h3>
              <p style={{
                fontSize: '14px',
                color: 'var(--text-secondary)'
              }}>
                개인 설정 및 계정 관련 알림이 표시됩니다.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
