"use client";
import { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";
import { isHoliday } from "../utils/holidays";

const getDayOfWeek = (date: Date) => {
  const days = ['월', '화', '수', '목', '금', '토', '일'];
  return days[date.getDay() === 0 ? 6 : date.getDay() - 1];
};

// 개선된 색상 시스템 (더 진한 색상으로 변경)
const getMainLocationColor = (mainLocationId: number) => {
  const colorPalette = [
    { primary: '#3b82f6', secondary: '#2563eb', light: '#dbeafe', text: '#1e40af', cellBg: '#eff6ff' }, // 진한 파란색
    { primary: '#10b981', secondary: '#059669', light: '#d1fae5', text: '#065f46', cellBg: '#ecfdf5' }, // 진한 초록색
    { primary: '#f59e0b', secondary: '#d97706', light: '#fef3c7', text: '#92400e', cellBg: '#fffbeb' }, // 진한 노란색
    { primary: '#ec4899', secondary: '#db2777', light: '#fce7f3', text: '#be185d', cellBg: '#fdf2f8' }, // 진한 분홍색
    { primary: '#8b5cf6', secondary: '#7c3aed', light: '#ede9fe', text: '#6b21a8', cellBg: '#f5f3ff' }, // 진한 보라색
    { primary: '#ef4444', secondary: '#dc2626', light: '#fee2e2', text: '#991b1b', cellBg: '#fef2f2' }, // 진한 빨간색
    { primary: '#06b6d4', secondary: '#0891b2', light: '#cffafe', text: '#164e63', cellBg: '#ecfeff' }, // 진한 청록색
    { primary: '#f97316', secondary: '#ea580c', light: '#fed7aa', text: '#9a3412', cellBg: '#fff7ed' }  // 진한 주황색
  ];
  
  const colorIndex = (mainLocationId - 1) % colorPalette.length;
  return colorPalette[colorIndex];
};

// 텍스트 색상 자동 계산 함수 추가
const getContrastColor = (hexColor: string | null) => {
  if (!hexColor || hexColor === 'transparent' || hexColor === 'null') {
    return 'var(--text-primary)';
  }
  
  const hex = hexColor.replace('#', '');
  if (hex.length !== 6) return 'var(--text-primary)';
  
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 140 ? '#1F2937' : '#FFFFFF';
};


// 스튜디오 색상 (회색 계열)
const getStudioColor = () => ({
  primary: '#6b7280',
  secondary: '#4b5563',
  light: '#f3f4f6',
  text: '#374151',
  cellBg: '#f9fafb'
});

// 내부업무 색상 (오렌지 계열)
const getInternalColor = () => ({
  primary: '#f97316',
  secondary: '#ea580c',
  light: '#fed7aa',
  text: '#9a3412',
  cellBg: '#fff7ed'
});

// 내부업무 타입별 색상 (파스텔)
const getInternalLocationColor = (locationType: string) => {
  const internalTypeColors = {
    'Helper': { bg: '#f0fdf4', border: '#86efac', text: '#166534' },
    '행사': { bg: '#fef3c7', border: '#fbbf24', text: '#92400e' },
    '기타': { bg: '#f5f3ff', border: '#a78bfa', text: '#6b21a8' },
    '장비/스튜디오대여': { bg: '#f0f9ff', border: '#93c5fd', text: '#1e40af' },
    '당직': { bg: '#fef2f2', border: '#fb7185', text: '#be123c' },
    '근무': { bg: '#ecfdf5', border: '#34d399', text: '#047857' },
    '고정휴무': { bg: '#f8fafc', border: '#94a3b8', text: '#334155' },
    '개인휴무': { bg: '#fdf2f8', border: '#f472b6', text: '#be185d' }
  };
  
  return internalTypeColors[locationType] || internalTypeColors['기타'];
};

// 내부업무 타입 배열
const internalLocationTypes = [
  'Helper',
  '행사',
  '기타',
  '장비/스튜디오대여',
  '당직',
  '근무',
  '고정휴무',
  '개인휴무'
];

// 촬영자 배치 모달 컴포넌트
function ShooterAssignmentModal({ 
  open, 
  onClose, 
  schedule, 
  shooters, 
  onAssign 
}: {
  open: boolean;
  onClose: () => void;
  schedule: any;
  shooters: any[];
  onAssign: (scheduleId: number, shooterId: number | null) => void;
}) {
  const [selectedShooter, setSelectedShooter] = useState<number | null>(null);

  useEffect(() => {
    if (schedule) {
      setSelectedShooter(schedule.assigned_shooter_id || null);
    }
  }, [schedule]);

  if (!open || !schedule) return null;

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
      <div style={{ 
        background: 'var(--bg-secondary)', 
        borderRadius: 12, 
        padding: 30, 
        maxWidth: 500, 
        width: '90%',
        border: '1px solid var(--border-color)'
      }}>
        <h3 style={{ margin: '0 0 20px 0', color: 'var(--text-primary)' }}>
          촬영자 배치
        </h3>
        
        {/* 스케줄 정보 */}
        <div style={{ 
          background: 'var(--bg-primary)', 
          padding: 16, 
          borderRadius: 8, 
          marginBottom: 20,
          border: '1px solid var(--border-color)'
        }}>
          <div style={{ fontSize: 14, color: 'var(--text-primary)', marginBottom: 8 }}>
            <strong>{schedule.course_name}</strong> / {schedule.professor_name}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            {schedule.shoot_date} {schedule.start_time} - {schedule.end_time}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            {schedule.sub_locations?.main_locations?.name} - {schedule.sub_locations?.name}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            촬영형식: {schedule.shooting_type}
          </div>
        </div>

        {/* 촬영자 선택 */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ 
            display: 'block', 
            marginBottom: 12, 
            fontSize: 14, 
            fontWeight: 600,
            color: 'var(--text-primary)'
          }}>
            촬영자 선택
          </label>
          
          {/* 배치 해제 옵션 */}
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <input
                type="radio"
                name="shooter"
                checked={selectedShooter === null}
                onChange={() => setSelectedShooter(null)}
              />
              <span style={{ color: 'var(--text-secondary)' }}>배치 해제</span>
            </label>
          </div>

          {/* 촬영자 목록 */}
          {shooters.map(shooter => (
            <div key={shooter.id} style={{ marginBottom: 12 }}>
              <label style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: 12, 
                cursor: 'pointer',
                padding: 12,
                background: selectedShooter === shooter.id ? 'var(--accent-color)20' : 'var(--bg-primary)',
                borderRadius: 8,
                border: `1px solid ${selectedShooter === shooter.id ? 'var(--accent-color)' : 'var(--border-color)'}`,
                transition: 'all 0.2s'
              }}>
                <input
                  type="radio"
                  name="shooter"
                  checked={selectedShooter === shooter.id}
                  onChange={() => setSelectedShooter(shooter.id)}
                />
                <div>
                  <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>
                    {shooter.name}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                    {shooter.shooter_type} | 경력: {shooter.experience_years || 0}년
                  </div>
                  {shooter.specialties && (
                    <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 4 }}>
                      전문분야: {shooter.specialties}
                    </div>
                  )}
                </div>
              </label>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <button 
            onClick={onClose}
            style={{ 
              padding: '10px 20px', 
              background: 'var(--text-secondary)', 
              color: 'white', 
              border: 'none', 
              borderRadius: 6, 
              cursor: 'pointer' 
            }}
          >
            취소
          </button>
          <button 
            onClick={() => {
              onAssign(schedule.id, selectedShooter);
              onClose();
            }}
            style={{ 
              padding: '10px 20px', 
              background: 'var(--accent-color)', 
              color: 'white', 
              border: 'none', 
              borderRadius: 6, 
              cursor: 'pointer' 
            }}
          >
            배치 확정
          </button>
        </div>
      </div>
    </div>
  );
}

// 메인 컴포넌트
export default function AllSchedulesPage() {
  const [schedules, setSchedules] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [shooters, setShooters] = useState<any[]>([]);
  const [internalSchedules, setInternalSchedules] = useState<any[]>([]);
  const [mainLocations, setMainLocations] = useState<any[]>([]);
  const [studioEquipments, setStudioEquipments] = useState<any[]>([]); // 🔥 추가: 스튜디오 촬영 타입 상태
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [showScheduleDetail, setShowScheduleDetail] = useState(false);
  const [selectedScheduleDetail, setSelectedScheduleDetail] = useState<any>(null);
  const [showShooterModal, setShowShooterModal] = useState(false);
  const [selectedScheduleForAssignment, setSelectedScheduleForAssignment] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // 필터 상태
  const [filters, setFilters] = useState({
    mainLocationId: 'all', // all, studio, 1, 2, 3, 4, 5, 6, 7, 8, internal
    shooterStatus: 'all', // all, assigned, unassigned
    scheduleStatus: 'all' // all, approved, scheduled, in_progress, completed
  });

  useEffect(() => {
    fetchData();
  }, [currentWeek]);

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([
      fetchSchedules(), 
      fetchLocations(), 
      fetchShooters(),
      fetchInternalSchedules(),
      fetchMainLocations(),
      fetchStudioEquipments() // 🔥 추가: 스튜디오 촬영 타입 조회
    ]);
    setLoading(false);
  };

  // main_location 조회 함수
  const fetchMainLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('main_locations')
        .select('id, name, location_type')
        .eq('is_active', true)
        .order('id');

      if (error) {
        console.error('main_location 조회 오류:', error);
        setMainLocations([]);
      } else {
        setMainLocations(data || []);
      }
    } catch (error) {
      console.error('main_location 조회 중 오류:', error);
      setMainLocations([]);
    }
  };

  // 🔥 새로 추가: 스튜디오 촬영 타입 조회 함수 (shooting_types 테이블 조인)
  const fetchStudioEquipments = async () => {
    try {
      // 1. sub_location_shooting_types와 shooting_types 조인
      const { data: shootingTypeData, error: shootingError } = await supabase
        .from('sub_location_shooting_types')
        .select(`
          sub_location_id,
          shooting_type_id,
          shooting_types!inner(
            id,
            name,
            description
          )
        `);

      if (shootingError) {
        console.error('촬영 타입 조회 오류:', shootingError);
        setStudioEquipments([]);
        return;
      }

      // 2. sub_locations 정보 조회 (스튜디오만)
      const { data: locationData, error: locationError } = await supabase
        .from('sub_locations')
        .select(`
          id,
          name,
          main_location_id,
          main_locations!inner(
            id,
            name,
            location_type
          )
        `)
        .eq('is_active', true)
        .eq('main_locations.location_type', 'studio')
        .eq('main_locations.is_active', true);

      if (locationError) {
        console.error('스튜디오 위치 조회 오류:', locationError);
        setStudioEquipments([]);
        return;
      }

      // 3. 데이터 병합
      const mergedData = locationData?.map(location => {
        const shootingTypes = shootingTypeData
          ?.filter(st => st.sub_location_id === location.id)
          ?.map(st => st.shooting_types?.name)
          ?.filter(Boolean) || [];
        
        return {
          ...location,
          shooting_types: shootingTypes
        };
      }) || [];

      console.log('스튜디오 촬영 타입 데이터:', mergedData);
      setStudioEquipments(mergedData);

    } catch (error) {
      console.error('스튜디오 촬영 타입 조회 중 오류:', error);
      setStudioEquipments([]);
    }
  };

  // 🔥 새로 추가: 스튜디오 촬영 타입 표시 함수
  const getStudioShootingTypes = (locationId: number) => {
    const location = studioEquipments.find(eq => eq.id === locationId);
    const shootingTypes = location?.shooting_types || [];
    
    if (shootingTypes.length === 0) return 'PPT';
    if (shootingTypes.length === 1) return shootingTypes[0];
    if (shootingTypes.length === 2) return shootingTypes.join(', ');
    
    // 3개 이상인 경우 처음 2개만 표시하고 ...
    return `${shootingTypes.slice(0, 2).join(', ')}...`;
  };

  // 실제 학원 이름 가져오기 함수
  const getMainLocationName = (mainLocationId: number) => {
    const mainLocation = mainLocations.find(ml => ml.id === mainLocationId);
    return mainLocation?.name || `학원${mainLocationId}`;
  };

  // 촬영자 목록 조회
  const fetchShooters = async () => {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('id, name, shooter_type, experience_years, specialties, is_active')
        .eq('is_active', true)
        .in('shooter_type', ['photographer', 'videographer', 'both'])
        .order('name');

      if (error) {
        console.error('촬영자 조회 오류:', error);
        setShooters([]);
      } else {
        setShooters(data || []);
      }
    } catch (error) {
      console.error('촬영자 데이터 조회 중 오류:', error);
      setShooters([]);
    }
  };

  // 내부업무 전체 조회 (shadow_color 포함)
    const fetchInternalSchedules = async () => {
    try {
        const weekDates = generateWeekDates();
        const startDate = weekDates[0].date;
        const endDate = weekDates[6].date;

        const { data, error } = await supabase
        .from('internal_schedules')
        .select('id, schedule_date, schedule_type, content, shadow_color, created_at') // 🔥 shadow_color 추가
        .eq('is_active', true)
        .gte('schedule_date', startDate)
        .lte('schedule_date', endDate)
        .order('schedule_date')
        .order('created_at');

        if (error) {
        console.error('내부업무 조회 오류:', error);
        setInternalSchedules([]);
        } else {
        setInternalSchedules(data || []);
        }
    } catch (error) {
        console.error('내부업무 조회 중 오류:', error);
        setInternalSchedules([]);
    }
    };


  // 촬영자 배치 함수
  const handleShooterAssignment = async (scheduleId: number, shooterId: number | null) => {
    try {
      const { error } = await supabase
        .from('schedules')
        .update({ 
          assigned_shooter_id: shooterId,
          tracking_status: shooterId ? 'scheduled' : 'approved',
          updated_at: new Date().toISOString()
        })
        .eq('id', scheduleId);

      if (error) {
        alert('촬영자 배치 오류: ' + error.message);
      } else {
        const shooterName = shooterId ? shooters.find(s => s.id === shooterId)?.name : '없음';
        alert(`촬영자 배치가 완료되었습니다.\n배치된 촬영자: ${shooterName}`);
        fetchSchedules();
      }
    } catch (error) {
      console.error('촬영자 배치 처리 오류:', error);
      alert('촬영자 배치 중 오류가 발생했습니다.');
    }
  };

  // 스케줄 카드 클릭 핸들러
  const handleScheduleCardClick = (schedule: any, event: React.MouseEvent) => {
    if (event.button === 2 || event.ctrlKey) {
      event.preventDefault();
      setSelectedScheduleForAssignment(schedule);
      setShowShooterModal(true);
    } else {
      setSelectedScheduleDetail(schedule);
      setShowScheduleDetail(true);
    }
  };

  const fetchSchedules = async () => {
    try {
      const weekDates = generateWeekDates();
      const startDate = weekDates[0].date;
      const endDate = weekDates[6].date;

      const { data: scheduleData, error: scheduleError } = await supabase
        .from('schedules')
        .select('*')
        .in('schedule_type', ['studio', 'academy'])
        .eq('is_active', true)
        .gte('shoot_date', startDate)
        .lte('shoot_date', endDate)
        .order('shoot_date')
        .order('start_time');

      if (scheduleError) {
        console.error('스케줄 조회 오류:', scheduleError);
        return;
      }

      if (!scheduleData || scheduleData.length === 0) {
        setSchedules([]);
        return;
      }

      const shooterIds = scheduleData
        .filter(s => s.assigned_shooter_id)
        .map(s => s.assigned_shooter_id);

      let userData = [];
      if (shooterIds.length > 0) {
        const { data: userProfiles } = await supabase
          .from('user_profiles')
          .select('id, name, shooter_type')
          .in('id', shooterIds);
        userData = userProfiles || [];
      }

      const locationIds = [...new Set(scheduleData.map(s => s.sub_location_id))];
      const { data: locationData } = await supabase
        .from('sub_locations')
        .select(`
          id,
          name,
          main_location_id,
          main_locations(id, name, location_type)
        `)
        .in('id', locationIds);

      const enrichedSchedules = scheduleData.map(schedule => {
        const userProfile = userData.find(u => u.id === schedule.assigned_shooter_id);
        const location = locationData?.find(l => l.id === schedule.sub_location_id);
        
        return {
          ...schedule,
          user_profiles: userProfile,
          sub_locations: location
        };
      });

      setSchedules(enrichedSchedules);
    } catch (error) {
      console.error('데이터 조회 중 오류:', error);
      setSchedules([]);
    }
  };

  const fetchLocations = async () => {
    try {
      const { data: locationData, error } = await supabase
        .from('sub_locations')
        .select(`
          id,
          name,
          main_location_id,
          is_active,
          main_locations(id, name, location_type, is_active)
        `)
        .eq('is_active', true)
        .eq('main_locations.is_active', true);

      if (error) {
        console.error('위치 조회 오류:', error);
        return;
      }

      const filteredLocations = locationData?.filter(location => 
        location.main_locations?.location_type === 'studio' || 
        location.main_locations?.location_type === 'academy'
      ) || [];

      setLocations(filteredLocations);
    } catch (error) {
      console.error('위치 조회 중 오류:', error);
      setLocations([]);
    }
  };

  const generateWeekDates = () => {
    const startOfWeek = new Date(currentWeek);
    const dayOfWeek = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    startOfWeek.setDate(diff);
    
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);
      const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
      dates.push({
        date: dateStr,
        day: date.getDate(),
        dayOfWeek: getDayOfWeek(date),
        isHoliday: isHoliday(dateStr, date)
      });
    }
    return dates;
  };

  const getLocationColor = (mainLocationId: number, locationType: string) => {
    if (locationType === 'studio') {
      return getStudioColor();
    } else {
      return getMainLocationColor(mainLocationId);
    }
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'approved':
        return { bg: '#fbbf24', color: '#ffffff', text: '승인완료' }; // 진한 노란색 배경, 흰색 텍스트
      case 'scheduled':
        return { bg: '#3b82f6', color: '#ffffff', text: '촬영자배치' }; // 진한 파란색 배경, 흰색 텍스트
      case 'in_progress':
        return { bg: '#10b981', color: '#ffffff', text: '촬영중' }; // 진한 초록색 배경, 흰색 텍스트
      case 'completed':
        return { bg: '#8b5cf6', color: '#ffffff', text: '촬영완료' }; // 진한 보라색 배경, 흰색 텍스트
      default:
        return { bg: '#6b7280', color: '#ffffff', text: status }; // 진한 회색 배경, 흰색 텍스트
    }
  };

  // 필터링된 위치 목록
  const getFilteredLocations = () => {
    if (filters.mainLocationId === 'all') return locations;
    if (filters.mainLocationId === 'studio') {
      return locations.filter(location => 
        location.main_locations?.location_type === 'studio'
      );
    }
    return locations.filter(location => 
      location.main_locations?.id === parseInt(filters.mainLocationId)
    );
  };

  // 필터링된 스케줄 목록
  const getFilteredScheduleForCell = (date: string, locationId: number) => {
    let daySchedules = schedules.filter(s => s.shoot_date === date && s.sub_location_id === locationId);
    
    // 촬영자 배치 상태 필터
    if (filters.shooterStatus === 'assigned') {
      daySchedules = daySchedules.filter(s => s.assigned_shooter_id);
    } else if (filters.shooterStatus === 'unassigned') {
      daySchedules = daySchedules.filter(s => !s.assigned_shooter_id);
    }
    
    // 진행 상태 필터
    if (filters.scheduleStatus !== 'all') {
      daySchedules = daySchedules.filter(s => 
        (s.tracking_status || s.approval_status) === filters.scheduleStatus
      );
    }
    
    return daySchedules;
  };

  // 필터링된 내부업무 스케줄 (전체 표시)
  const getFilteredInternalScheduleForCell = (date: string, locationType: string) => {
    if (filters.mainLocationId !== 'all' && filters.mainLocationId !== 'internal') {
      return [];
    }
    return internalSchedules.filter(s => 
      s.schedule_date === date && s.schedule_type === locationType
    );
  };

  // 스튜디오와 학원 경계 구분을 위한 함수
  const isLastStudio = (locations: any[], currentIndex: number) => {
    const current = locations[currentIndex];
    const next = locations[currentIndex + 1];
    
    return current?.main_locations?.location_type === 'studio' && 
           next?.main_locations?.location_type === 'academy';
  };

  const navigateWeek = (direction: number) => {
    const newWeek = new Date(currentWeek);
    newWeek.setDate(currentWeek.getDate() + (direction * 7));
    setCurrentWeek(newWeek);
  };

  const getWeekRange = () => {
    const dates = generateWeekDates();
    const start = dates[0];
    const end = dates[6];
    return `${start.date} ~ ${end.date}`;
  };

  const dates = generateWeekDates();
  const filteredLocations = getFilteredLocations();

  // 위치별 정렬 (스튜디오 먼저)
  const sortedLocations = filteredLocations.sort((a, b) => {
    const aType = a.main_locations?.location_type;
    const bType = b.main_locations?.location_type;
    
    // 스튜디오 먼저, 그 다음 학원
    if (aType === 'studio' && bType === 'academy') return -1;
    if (aType === 'academy' && bType === 'studio') return 1;
    
    return (a.main_locations?.id || 0) - (b.main_locations?.id || 0);
  });

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        background: 'var(--bg-primary)'
      }}>
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px'
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: '4px solid var(--accent-color)',
            borderTop: '4px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
          }} />
          <div style={{
            fontSize: '18px',
            color: 'var(--text-secondary)',
            fontWeight: '500'
          }}>
            통합 스케줄을 불러오는 중...
          </div>
        </div>
        
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{ 
      width: '100%', 
      overflow: 'hidden', 
      padding: '20px', 
      background: 'var(--bg-primary)', 
      minHeight: '100vh' 
    }}>
      {/* 메인 헤더 */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        marginBottom: 20 
      }}>
        <div>
          <h2 style={{ 
            margin: 0, 
            color: 'var(--text-primary)', 
            fontSize: 24 
          }}>
            통합 스케줄 관리 (학원별 색상 구분)
          </h2>
          <div style={{ 
            fontSize: 14, 
            color: 'var(--text-secondary)', 
            marginTop: 4 
          }}>
            우클릭 또는 Ctrl+클릭으로 촬영자 배치 | 촬영자 {shooters.length}명 대기중
          </div>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <button 
            onClick={() => navigateWeek(-1)} 
            style={{ 
              padding: '10px 16px', 
              border: '1px solid var(--border-color)', 
              borderRadius: 6, 
              background: 'var(--bg-secondary)', 
              color: 'var(--text-primary)', 
              cursor: 'pointer' 
            }}
          >
            이전 주
          </button>
          <span style={{ 
            padding: '10px 20px', 
            fontWeight: 600, 
            color: 'var(--text-primary)', 
            background: 'var(--bg-secondary)', 
            borderRadius: 6 
          }}>
            {getWeekRange()}
          </span>
          <button 
            onClick={() => navigateWeek(1)} 
            style={{ 
              padding: '10px 16px', 
              border: '1px solid var(--border-color)', 
              borderRadius: 6, 
              background: 'var(--bg-secondary)', 
              color: 'var(--text-primary)', 
              cursor: 'pointer' 
            }}
          >
            다음 주
          </button>
        </div>
      </div>

      {/* 필터 UI (스튜디오 먼저) */}
      <div style={{ 
        display: 'flex', 
        gap: 16, 
        marginBottom: 20,
        padding: 16,
        background: 'var(--bg-secondary)',
        borderRadius: 8,
        border: '1px solid var(--border-color)',
        flexWrap: 'wrap'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <label style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>
            장소별 필터:
          </label>
          <select
            value={filters.mainLocationId}
            onChange={(e) => setFilters({...filters, mainLocationId: e.target.value})}
            style={{
              padding: '6px 12px',
              border: '1px solid var(--border-color)',
              borderRadius: 4,
              background: 'var(--bg-primary)',
              color: 'var(--text-primary)',
              fontSize: 14
            }}
          >
            <option value="all">전체</option>
            <option value="studio">스튜디오</option>
            {mainLocations
              .filter(ml => ml.location_type === 'academy')
              .map(ml => (
                <option key={ml.id} value={ml.id.toString()}>
                  {ml.name}
                </option>
              ))
            }
            <option value="internal">내부업무</option>
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <label style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>
            촬영자 배치:
          </label>
          <select
            value={filters.shooterStatus}
            onChange={(e) => setFilters({...filters, shooterStatus: e.target.value})}
            style={{
              padding: '6px 12px',
              border: '1px solid var(--border-color)',
              borderRadius: 4,
              background: 'var(--bg-primary)',
              color: 'var(--text-primary)',
              fontSize: 14
            }}
          >
            <option value="all">전체</option>
            <option value="assigned">배치완료</option>
            <option value="unassigned">미배치</option>
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <label style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>
            진행 상태:
          </label>
          <select
            value={filters.scheduleStatus}
            onChange={(e) => setFilters({...filters, scheduleStatus: e.target.value})}
            style={{
              padding: '6px 12px',
              border: '1px solid var(--border-color)',
              borderRadius: 4,
              background: 'var(--bg-primary)',
              color: 'var(--text-primary)',
              fontSize: 14
            }}
          >
            <option value="all">전체</option>
            <option value="approved">승인완료</option>
            <option value="scheduled">촬영자배치</option>
            <option value="in_progress">촬영중</option>
            <option value="completed">촬영완료</option>
          </select>
        </div>

        <button
          onClick={() => setFilters({
            mainLocationId: 'all',
            shooterStatus: 'all', 
            scheduleStatus: 'all'
          })}
          style={{
            padding: '6px 12px',
            background: 'var(--text-secondary)',
            color: 'white',
            border: 'none',
            borderRadius: 4,
            cursor: 'pointer',
            fontSize: 14
          }}
        >
          필터 초기화
        </button>
      </div>

      {/* 스튜디오 + 학원 섹션 */}
      <div style={{ marginBottom: 40 }}>
        <h3 style={{ margin: '0 0 16px 0', color: 'var(--text-primary)', fontSize: 20 }}>
          스튜디오 & 학원 스케줄 (학원별 색상 구분)
        </h3>

        {/* 스케줄 그리드 */}
        <div style={{ 
          display: 'grid',
          gridTemplateColumns: `220px repeat(7, 1fr)`,
          border: '2px solid var(--border-color)',
          borderRadius: 12,
          overflow: 'hidden',
          background: 'var(--bg-secondary)'
        }}>
          <div style={{ 
            background: 'var(--accent-color)', 
            color: 'white', 
            padding: 16, 
            fontWeight: 700, 
            fontSize: 16, 
            borderRight: '2px solid var(--border-color)', 
            borderBottom: '2px solid var(--border-color)' 
          }}>
            장소
          </div>
          {dates.map((dateInfo, index) => (
            <div key={`header-${dateInfo.date}-${index}`} style={{ 
              background: 'var(--accent-color)', 
              color: 'white', 
              padding: 12, 
              fontSize: 15, 
              textAlign: 'center', 
              fontWeight: 700, 
              borderRight: index === dates.length - 1 ? 'none' : '2px solid var(--border-color)', 
              borderBottom: '2px solid var(--border-color)' 
            }}>
              <span style={{ color: dateInfo.isHoliday ? '#ff6b6b' : 'white' }}>
                {dateInfo.day}일 ({dateInfo.dayOfWeek})
              </span>
            </div>
          ))}

          {sortedLocations.map((location, locationIndex) => {
            const displayName = location.main_locations?.name ? `${location.main_locations.name} - ${location.name}` : location.name;
            const locationType = location.main_locations?.location_type || 'academy';
            const mainLocationId = location.main_locations?.id || 1;
            const locationColor = getLocationColor(mainLocationId, locationType);
            const isLastStudioLocation = isLastStudio(sortedLocations, locationIndex);
            
            return [
              // 🔥 수정: 장소명 셀 (스튜디오는 실제 촬영 타입 표시)
              <div key={`location-${location.id}-${locationIndex}`} style={{ 
                background: locationColor.cellBg,
                color: locationColor.text,
                padding: 14, 
                fontWeight: 600, 
                fontSize: 14, 
                borderRight: '2px solid var(--border-color)', 
                borderBottom: isLastStudioLocation ? '3px solid #e5e7eb' : (locationIndex === sortedLocations.length - 1 ? 'none' : '1px solid var(--border-color)'),
                border: `1px solid ${locationColor.primary}30`
              }}>
                {displayName}
                {/* 🔥 수정: 스튜디오는 실제 촬영 타입 표시 (PPT, 전자칠판 등) */}
                {locationType === 'studio' && (
                  <div style={{ fontSize: 11, opacity: 0.8, marginTop: 2, color: locationColor.text }}>
                    {getStudioShootingTypes(location.id)}
                  </div>
                )}
              </div>,
              
              // 스케줄 셀들
              ...dates.map((dateInfo, dateIndex) => {
                const daySchedules = getFilteredScheduleForCell(dateInfo.date, location.id);
                
                return (
                  <div 
                    key={`cell-${location.id}-${dateInfo.date}-${locationIndex}-${dateIndex}`}
                    style={{ 
                      background: daySchedules.length > 0 ? locationColor.light : 'var(--bg-secondary)',
                      padding: 8,
                      minHeight: daySchedules.length > 0 ? 100 : 50,
                      fontSize: 12,
                      borderRight: dateIndex === dates.length - 1 ? 'none' : '1px solid var(--border-color)',
                      borderBottom: isLastStudioLocation ? '3px solid #e5e7eb' : (locationIndex === sortedLocations.length - 1 ? 'none' : '1px solid var(--border-color)'),
                      position: 'relative',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: daySchedules.length > 0 ? 'flex-start' : 'center',
                      gap: 6
                    }}
                  >
                    {daySchedules.map((schedule, index) => {
                      const statusInfo = getStatusInfo(schedule.tracking_status || schedule.approval_status);
                      
                      return (
                        <div 
                          key={`schedule-${location.id}-${dateInfo.date}-${schedule.id}-${index}`}
                          onMouseDown={(e) => handleScheduleCardClick(schedule, e)}
                          onContextMenu={(e) => {
                            e.preventDefault();
                            setSelectedScheduleForAssignment(schedule);
                            setShowShooterModal(true);
                          }}
                          style={{ 
                            padding: 8,
                            background: 'var(--bg-secondary)', 
                            borderRadius: 6, 
                            border: `2px solid ${locationColor.primary}`,
                            cursor: 'pointer',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                            transition: 'all 0.2s ease',
                            position: 'relative'
                          }}
                        >
                          <div style={{ fontWeight: 700, color: locationColor.text, fontSize: 14, marginBottom: 4 }}>
                            {schedule.start_time?.substring(0, 5)}~{schedule.end_time?.substring(0, 5)}
                          </div>
                          
                          <div style={{ fontSize: 12, marginBottom: 4, color: 'var(--text-primary)', fontWeight: 600 }}>
                            {schedule.professor_name} / {schedule.course_name}
                          </div>
                          
                          <div style={{ 
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            marginBottom: 4
                          }}>
                            <div style={{ 
                              background: locationColor.primary + '20',
                              color: locationColor.text,
                              padding: '2px 8px',
                              borderRadius: 12,
                              fontSize: 10,
                              fontWeight: 600,
                              border: `1px solid ${locationColor.primary}60`
                            }}>
                              {schedule.shooting_type}
                            </div>
                            
                            <span style={{
                              fontSize: 9,
                              padding: '2px 6px',
                              borderRadius: 8,
                              background: statusInfo.bg,
                              color: statusInfo.color,
                              fontWeight: 600
                            }}>
                              {statusInfo.text}
                            </span>
                          </div>

                          {/* 촬영자 정보 표시 (진한 색상) */}
                          {schedule.assigned_shooter_id && schedule.user_profiles ? (
                            <div style={{ 
                              fontSize: 10, 
                              color: 'white', 
                              background: '#059669',
                              padding: 5,
                              borderRadius: 4,
                              fontWeight: 'bold',
                              textAlign: 'center'
                            }}>
                              촬영자: {schedule.user_profiles.name}
                            </div>
                          ) : (
                            <div style={{ 
                              fontSize: 10, 
                              color: 'white', 
                              background: '#dc2626',
                              padding: 5,
                              borderRadius: 4,
                              fontWeight: 'bold',
                              textAlign: 'center'
                            }}>
                              촬영자 미배치
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })
            ];
          }).flat()}
        </div>
      </div>

      {/* 내부업무 섹션 (텍스트에만 음영) */}
        {(filters.mainLocationId === 'all' || filters.mainLocationId === 'internal') && (
        <div style={{ marginBottom: 40 }}>
            <h3 style={{ margin: '0 0 16px 0', color: 'var(--text-primary)', fontSize: 20 }}>
            내부업무 스케줄 (텍스트 음영)
            </h3>
            
            <div style={{ 
            display: 'grid',
            gridTemplateColumns: `200px repeat(7, 1fr)`,
            border: '2px solid var(--border-color)',
            borderRadius: 12,
            overflow: 'hidden',
            background: 'var(--bg-secondary)'
            }}>
            {/* 헤더 */}
            <div style={{ 
                background: 'var(--accent-color)',
                color: 'white',
                padding: 16,
                fontWeight: 700,
                fontSize: 16,
                borderRight: '2px solid var(--border-color)',
                borderBottom: '2px solid var(--border-color)'
            }}>
                업무 구분
            </div>
            
            {dates.map((dateInfo, index) => (
                <div key={`internal-header-${dateInfo.date}`} style={{ 
                background: 'var(--accent-color)',
                color: 'white',
                padding: 12,
                fontSize: 15,
                textAlign: 'center',
                fontWeight: 700,
                borderRight: index === dates.length - 1 ? 'none' : '2px solid var(--border-color)',
                borderBottom: '2px solid var(--border-color)'
                }}>
                <span style={{ color: dateInfo.isHoliday ? '#ff6b6b' : 'white' }}>
                    {dateInfo.day}일 ({dateInfo.dayOfWeek})
                </span>
                </div>
            ))}

            {/* 내부업무 텍스트에만 음영 적용 */}
            {internalLocationTypes.map((locationType, locationIndex) => {
                const colors = getInternalLocationColor(locationType);
                
                return [
                // 업무 구분 셀
                <div key={`internal-location-${locationType}`} style={{ 
                    background: 'var(--bg-primary)',
                    color: 'var(--text-primary)',
                    display: 'flex',
                    alignItems: 'center',
                    paddingLeft: 14,
                    fontWeight: 600,
                    fontSize: 14,
                    minHeight: 60,
                    borderRight: '2px solid var(--border-color)',
                    borderBottom: locationIndex === internalLocationTypes.length - 1 ? 'none' : '1px solid var(--border-color)',
                    borderLeft: `4px solid ${colors.border}`
                }}>
                    {locationType}
                </div>,
                
                // 각 날짜별 내부업무 셀들 (텍스트에만 음영)
                    ...dates.map((dateInfo, dateIndex) => {
                    const dayInternalSchedules = getFilteredInternalScheduleForCell(dateInfo.date, locationType);
                    return (
                        <div key={`internal-cell-${locationType}-${dateInfo.date}`} style={{ 
                        background: 'var(--bg-secondary)', // 셀 자체는 기본 배경
                        padding: 12,
                        minHeight: 60,
                        fontSize: 12,
                        borderRight: dateIndex === dates.length - 1 ? 'none' : '1px solid var(--border-color)',
                        borderBottom: locationIndex === internalLocationTypes.length - 1 ? 'none' : '1px solid var(--border-color)',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        alignItems: 'center',
                        gap: 4
                        }}>
                        {dayInternalSchedules.length > 0 ? (
                            dayInternalSchedules.map((schedule, scheduleIndex) => (
                            <span key={`internal-schedule-${schedule.id}`} style={{ 
                                // 🔥 텍스트에만 음영 적용
                                background: schedule.shadow_color || 'transparent',
                                color: getContrastColor(schedule.shadow_color),
                                padding: schedule.shadow_color ? '4px 8px' : '0',
                                borderRadius: schedule.shadow_color ? '4px' : '0',
                                fontSize: 12,
                                fontWeight: 500,
                                lineHeight: 1.4,
                                textAlign: 'center',
                                wordBreak: 'break-word',
                                whiteSpace: 'pre-wrap',
                                display: 'inline-block',
                                marginBottom: scheduleIndex < dayInternalSchedules.length - 1 ? '4px' : '0'
                            }}>
                                {schedule.content || '업무'}
                            </span>
                            ))
                        ) : (
                            <span style={{ 
                            color: 'var(--text-secondary)', 
                            fontSize: 11,
                            textAlign: 'center',
                            fontStyle: 'italic'
                            }}>
                            -
                            </span>
                        )}
                        </div>
                    );
                    })

                ];
            }).flat()}
            </div>

            {/* 내부업무 관리 링크 */}
            <div style={{ 
            marginTop: 16, 
            textAlign: 'center' 
            }}>
            <a 
                href="/internal-schedules"
                style={{
                padding: '10px 20px',
                background: 'var(--accent-color)',
                color: 'white',
                textDecoration: 'none',
                borderRadius: 6,
                fontSize: 14,
                fontWeight: 600
                }}
            >
                내부업무 상세 관리 →
            </a>
            </div>
        </div>
        )}


      {/* 촬영자 배치 모달 */}
      <ShooterAssignmentModal
        open={showShooterModal}
        onClose={() => setShowShooterModal(false)}
        schedule={selectedScheduleForAssignment}
        shooters={shooters}
        onAssign={handleShooterAssignment}
      />

      {/* 스케줄 상세 모달 */}
      {showScheduleDetail && selectedScheduleDetail && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }}>
          <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 30, maxWidth: 600, width: '90%', maxHeight: '80vh', overflow: 'auto' }}>
            <h3 style={{ margin: '0 0 20px 0', color: 'var(--text-primary)' }}>
              스케줄 상세 정보
            </h3>
            
            <div style={{ display: 'grid', gap: 12, marginBottom: 20 }}>
              <div><strong>과목명:</strong> {selectedScheduleDetail.course_name}</div>
              <div><strong>강사명:</strong> {selectedScheduleDetail.professor_name}</div>
              <div><strong>날짜:</strong> {selectedScheduleDetail.shoot_date}</div>
              <div><strong>시간:</strong> {selectedScheduleDetail.start_time} - {selectedScheduleDetail.end_time}</div>
              <div><strong>장소:</strong> {selectedScheduleDetail.sub_locations?.main_locations?.name} - {selectedScheduleDetail.sub_locations?.name}</div>
              <div><strong>촬영 타입:</strong> {selectedScheduleDetail.shooting_type}</div>
              <div><strong>상태:</strong> {getStatusInfo(selectedScheduleDetail.tracking_status || selectedScheduleDetail.approval_status).text}</div>
              <div><strong>배정된 촬영자:</strong> {selectedScheduleDetail.user_profiles?.name || '미배치'}</div>
            </div>

            <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
              <button 
                onClick={() => {
                  setSelectedScheduleForAssignment(selectedScheduleDetail);
                  setShowScheduleDetail(false);
                  setShowShooterModal(true);
                }}
                style={{ 
                  padding: '10px 20px', 
                  background: 'var(--accent-color)', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: 6, 
                  cursor: 'pointer' 
                }}
              >
                촬영자 배치
              </button>
              <button 
                onClick={() => setShowScheduleDetail(false)}
                style={{ padding: '10px 20px', background: 'var(--text-secondary)', color: 'white', border: 'none', borderRadius: 6, cursor: 'pointer' }}
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
