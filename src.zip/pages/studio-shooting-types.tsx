// src/pages/studio-shooting-types.tsx
import { GetServerSideProps } from 'next';
import Head from 'next/head';
import dynamic from 'next/dynamic';

const StudioShootingTypesManager = dynamic(
  () => import('../components/StudioShootingTypesManager'),
  { ssr: false }
);

export default function StudioShootingTypesPage() {
  return (
    <>
      <Head>
        <title>스튜디오-촬영형식 관리</title>
        <meta name="description" content="스튜디오별 촬영형식 매핑 관리" />
      </Head>
      
      <StudioShootingTypesManager />
    </>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  return {
    props: {}
  };
};
