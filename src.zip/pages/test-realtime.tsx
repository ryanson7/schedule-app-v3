"use client";
import React, { useState, useEffect } from 'react';
import { supabase } from '../utils/supabaseClient';
import toast, { Toaster } from 'react-hot-toast';

export default function RealtimeNotificationTest() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  const [testData, setTestData] = useState({
    shooterId: 1,
    scheduleId: 8,
    actionType: 'departure'
  });
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    console.log('Realtime 구독 시작...');
    
    // 브라우저 알림 권한 확인
    setNotificationPermission(Notification.permission);
    
    // Supabase Realtime 구독 설정
    const channel = supabase
      .channel('shooter_tracking_realtime')
      .on(
        'postgres_changes',
        { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'shooter_tracking' 
        },
        (payload) => {
          console.log('🎉 실시간 이벤트 수신:', payload);
          
          const newNotification = {
            id: payload.new.id,
            message: `🎬 새 액션: ${payload.new.action_type}`,
            shooterId: payload.new.shooter_id,
            scheduleId: payload.new.schedule_id,
            time: new Date().toLocaleTimeString(),
            timestamp: payload.new.action_timestamp,
            isOnTime: payload.new.is_on_time
          };

          setNotifications(prev => [newNotification, ...prev]);
          
          // 강화된 알림 시스템 호출
          sendStrongNotification(payload);
        }
      )
      .subscribe((status, err) => {
        console.log('구독 상태 변경:', status, err);
        setConnectionStatus(status === 'SUBSCRIBED' ? 'connected' : 'disconnected');
        
        if (status === 'SUBSCRIBED') {
          toast.success('실시간 알림 연결 완료!', {
            duration: 2000,
            position: 'bottom-right',
            style: {
              background: '#3b82f6',
              color: 'white'
            }
          });
        }
        
        if (err) {
          console.error('구독 오류:', err);
          toast.error('실시간 알림 연결 실패', {
            duration: 3000,
            position: 'bottom-right'
          });
        }
      });

    // 브라우저 알림 권한 요청
    requestNotificationPermission();

    return () => {
      console.log('Realtime 구독 해제');
      supabase.removeChannel(channel);
    };
  }, []);

  // 브라우저 알림 권한 요청
  const requestNotificationPermission = async () => {
    if (Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === 'granted') {
        toast.success('브라우저 알림 권한이 허용되었습니다!', {
          duration: 3000,
          position: 'bottom-center',
          icon: '🔔'
        });
      } else if (permission === 'denied') {
        toast.error('브라우저 알림이 차단되었습니다. 브라우저 설정에서 허용해주세요.', {
          duration: 5000,
          position: 'bottom-center'
        });
      }
    }
  };

  // 액션 타입 한글 변환
  const getActionTypeKorean = (actionType: string): string => {
    const actionTypes: { [key: string]: string } = {
      'schedule_check': '스케줄 확인',
      'departure': '출발',
      'arrival': '도착',
      'start': '촬영 시작',
      'end': '촬영 종료',
      'completion': '업무 완료'
    };
    return actionTypes[actionType] || actionType;
  };

  // 강화된 알림 시스템
  const sendStrongNotification = (payload: any) => {
    const actionKorean = getActionTypeKorean(payload.new.action_type);
    
    // 1. Toast 알림
    toast.success(
      `🎬 ${actionKorean} 완료!\nShooter ID: ${payload.new.shooter_id} | Schedule ID: ${payload.new.schedule_id}`,
      {
        duration: 4000,
        position: 'top-right',
        style: {
          background: '#10b981',
          color: 'white',
          fontWeight: '500'
        },
        icon: '🎬'
      }
    );

    // 2. 강화된 브라우저 알림
    if (Notification.permission === 'granted') {
      const notification = new Notification(`🚨 긴급: ${actionKorean} 완료`, {
        body: `Shooter ID: ${payload.new.shooter_id}\nSchedule ID: ${payload.new.schedule_id}\n즉시 확인이 필요합니다.`,
        icon: '/favicon.ico',
        requireInteraction: true, // 사용자가 클릭할 때까지 유지
        silent: false,
        vibrate: [200, 100, 200, 100, 200], // 긴 진동 패턴
        tag: `urgent-${payload.new.id}`,
        actions: [
          { action: 'view', title: '확인하기' },
          { action: 'dismiss', title: '나중에' }
        ]
      });

      // 알림 클릭 시 처리
      notification.onclick = () => {
        window.focus();
        notification.close();
        toast.success('알림을 확인했습니다!', {
          icon: '✅'
        });
      };

      // 10초마다 재알림 (최대 3번)
      let reminderCount = 0;
      const reminderInterval = setInterval(() => {
        if (reminderCount < 3) {
          const reminder = new Notification(`🔔 미확인 알림 (${reminderCount + 1}/3)`, {
            body: `${actionKorean} 알림을 확인해주세요.`,
            requireInteraction: true,
            tag: `reminder-${payload.new.id}-${reminderCount}`,
            vibrate: [100, 50, 100]
          });
          
          reminder.onclick = () => {
            clearInterval(reminderInterval);
            window.focus();
            reminder.close();
            notification.close();
          };
          
          reminderCount++;
        } else {
          clearInterval(reminderInterval);
        }
      }, 10000);

      // 알림이 닫히면 재알림도 중지
      notification.onclose = () => {
        clearInterval(reminderInterval);
      };
    }

    // 3. 소리 알림 (연속 3번)
    playUrgentSound();

    // 4. 화면 깜빡임 효과
    flashScreen();

    // 5. 브라우저 탭 제목 변경
    changeTabTitle(actionKorean);
  };

  // 긴급 소리 알림
  const playUrgentSound = () => {
    // 기본 알림음 (Base64 인코딩된 짧은 비프음)
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBSuE0fPTgjMGHm7A7+OZURE');
    audio.volume = 0.8;
    
    let playCount = 0;
    const playInterval = setInterval(() => {
      if (playCount < 3) {
        audio.currentTime = 0;
        audio.play().catch(() => {
          console.log('소리 재생 실패 (사용자 상호작용 필요)');
        });
        playCount++;
      } else {
        clearInterval(playInterval);
      }
    }, 1000);
  };

  // 화면 깜빡임 효과
  const flashScreen = () => {
    let blinkCount = 0;
    const originalBackground = document.body.style.background;
    
    const blinkInterval = setInterval(() => {
      if (blinkCount < 6) {
        document.body.style.background = blinkCount % 2 === 0 ? '#ff4444' : originalBackground;
        blinkCount++;
      } else {
        document.body.style.background = originalBackground;
        clearInterval(blinkInterval);
      }
    }, 300);
  };

  // 브라우저 탭 제목 변경
  const changeTabTitle = (actionType: string) => {
    const originalTitle = document.title;
    let titleBlinkCount = 0;
    
    const titleInterval = setInterval(() => {
      if (titleBlinkCount < 10) {
        document.title = titleBlinkCount % 2 === 0 ? `🚨 ${actionType} 완료!` : originalTitle;
        titleBlinkCount++;
      } else {
        document.title = originalTitle;
        clearInterval(titleInterval);
      }
    }, 1000);
  };

  // 테스트용 액션 추가 함수
  const addTestAction = async () => {
    try {
      const loadingToast = toast.loading('테스트 액션 추가 중...', {
        position: 'top-center'
      });

      const { data, error } = await supabase
        .from('shooter_tracking')
        .insert({
          schedule_id: testData.scheduleId,
          shooter_id: testData.shooterId,
          action_type: testData.actionType,
          action_timestamp: new Date().toISOString(),
          location_verified: testData.actionType === 'arrival',
          is_on_time: true,
          notes: `테스트 액션: ${testData.actionType}`
        });

      toast.dismiss(loadingToast);

      if (error) {
        console.error('테스트 액션 추가 오류:', error);
        toast.error(`테스트 액션 추가 실패: ${error.message}`, {
          duration: 4000,
          position: 'top-center'
        });
      } else {
        console.log('테스트 액션 추가 성공:', data);
        toast.success('테스트 액션이 성공적으로 추가되었습니다!', {
          duration: 2000,
          position: 'top-center',
          style: {
            background: '#059669',
            color: 'white'
          }
        });
      }
    } catch (error) {
      console.error('예외 발생:', error);
      toast.error('예상치 못한 오류가 발생했습니다.', {
        duration: 3000,
        position: 'top-center'
      });
    }
  };

  // 알림 권한 재요청
  const requestPermissionAgain = () => {
    requestNotificationPermission();
  };

  // 테스트 알림 보내기
  const sendTestNotification = () => {
    if (Notification.permission === 'granted') {
      const testNotification = new Notification('🧪 테스트 알림', {
        body: '브라우저 알림이 정상적으로 작동합니다!',
        icon: '/favicon.ico',
        requireInteraction: true,
        vibrate: [100, 50, 100]
      });

      testNotification.onclick = () => {
        testNotification.close();
        toast.success('테스트 알림 확인 완료!', { icon: '✅' });
      };
    } else {
      toast.error('브라우저 알림 권한이 필요합니다!', {
        duration: 3000
      });
    }
  };

  const clearNotifications = () => {
    setNotifications([]);
    toast.success('알림이 모두 삭제되었습니다.', {
      duration: 2000,
      position: 'bottom-center',
      style: {
        background: '#6b7280',
        color: 'white'
      }
    });
  };

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return '#10b981';
      case 'connecting': return '#f59e0b';
      case 'disconnected': return '#ef4444';
      default: return '#64748b';
    }
  };

  const getConnectionStatusText = () => {
    switch (connectionStatus) {
      case 'connected': return '연결됨';
      case 'connecting': return '연결 중...';
      case 'disconnected': return '연결 끊김';
      default: return '알 수 없음';
    }
  };

  const getPermissionStatusColor = () => {
    switch (notificationPermission) {
      case 'granted': return '#10b981';
      case 'denied': return '#ef4444';
      case 'default': return '#f59e0b';
      default: return '#64748b';
    }
  };

  const getPermissionStatusText = () => {
    switch (notificationPermission) {
      case 'granted': return '허용됨';
      case 'denied': return '차단됨';
      case 'default': return '미설정';
      default: return '알 수 없음';
    }
  };

  return (
    <div style={{
      padding: '24px',
      maxWidth: '800px',
      margin: '0 auto',
      fontFamily: 'inherit'
    }}>
      {/* Toast 컨테이너 */}
      <Toaster 
        position="top-right"
        reverseOrder={false}
        gutter={8}
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
          success: {
            duration: 3000,
            style: {
              background: '#10b981',
            },
          },
          error: {
            duration: 4000,
            style: {
              background: '#ef4444',
            },
          },
        }}
      />

      {/* 헤더 */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        color: 'white',
        padding: '20px',
        borderRadius: '12px',
        marginBottom: '24px'
      }}>
        <h1 style={{ margin: '0 0 8px 0', fontSize: '24px' }}>
          🚨 강화된 브라우저 알림 테스트
        </h1>
        <p style={{ margin: 0, opacity: 0.9 }}>
          소리, 진동, 깜빡임, 재알림 등 모든 강화 기능이 포함된 테스트
        </p>
      </div>

      {/* 상태 표시 */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '12px',
        marginBottom: '20px'
      }}>
        {/* 연결 상태 */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px',
          background: 'white',
          border: '1px solid #e2e8f0',
          borderRadius: '8px'
        }}>
          <div style={{
            width: '12px',
            height: '12px',
            borderRadius: '50%',
            background: getConnectionStatusColor(),
            animation: connectionStatus === 'connecting' ? 'pulse 2s infinite' : 'none'
          }} />
          <span style={{ fontWeight: '600', fontSize: '14px' }}>
            Realtime: {getConnectionStatusText()}
          </span>
        </div>

        {/* 알림 권한 상태 */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '12px',
          background: 'white',
          border: '1px solid #e2e8f0',
          borderRadius: '8px'
        }}>
          <div style={{
            width: '12px',
            height: '12px',
            borderRadius: '50%',
            background: getPermissionStatusColor()
          }} />
          <span style={{ fontWeight: '600', fontSize: '14px' }}>
            알림 권한: {getPermissionStatusText()}
          </span>
        </div>
      </div>

      {/* 알림 권한 관리 */}
      {notificationPermission !== 'granted' && (
        <div style={{
          background: '#fef3c7',
          border: '1px solid #f59e0b',
          borderRadius: '8px',
          padding: '16px',
          marginBottom: '20px'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div>
              <div style={{ fontWeight: '600', color: '#92400e', marginBottom: '4px' }}>
                ⚠️ 브라우저 알림 권한이 필요합니다
              </div>
              <div style={{ fontSize: '14px', color: '#92400e' }}>
                강화된 알림 기능을 사용하려면 브라우저 알림을 허용해주세요.
              </div>
            </div>
            <button
              onClick={requestPermissionAgain}
              style={{
                padding: '8px 16px',
                background: '#f59e0b',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontWeight: '500'
              }}
            >
              권한 요청
            </button>
          </div>
        </div>
      )}

      {/* 테스트 컨트롤 */}
      <div style={{
        background: 'white',
        padding: '20px',
        border: '1px solid #e2e8f0',
        borderRadius: '8px',
        marginBottom: '20px'
      }}>
        <h3 style={{ margin: '0 0 16px 0' }}>강화된 알림 테스트</h3>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
          gap: '12px',
          marginBottom: '16px'
        }}>
          <div>
            <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px' }}>
              Shooter ID
            </label>
            <input
              type="number"
              value={testData.shooterId}
              onChange={(e) => setTestData(prev => ({ ...prev, shooterId: parseInt(e.target.value) }))}
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #d1d5db',
                borderRadius: '6px',
                boxSizing: 'border-box'
              }}
            />
          </div>
          
          <div>
            <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px' }}>
              Schedule ID
            </label>
            <input
              type="number"
              value={testData.scheduleId}
              onChange={(e) => setTestData(prev => ({ ...prev, scheduleId: parseInt(e.target.value) }))}
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #d1d5db',
                borderRadius: '6px',
                boxSizing: 'border-box'
              }}
            />
          </div>
          
          <div>
            <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px' }}>
              액션 타입
            </label>
            <select
              value={testData.actionType}
              onChange={(e) => setTestData(prev => ({ ...prev, actionType: e.target.value }))}
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #d1d5db',
                borderRadius: '6px'
              }}
            >
              <option value="schedule_check">스케줄 확인</option>
              <option value="departure">출발</option>
              <option value="arrival">도착</option>
              <option value="start">촬영 시작</option>
              <option value="end">촬영 종료</option>
              <option value="completion">업무 완료</option>
            </select>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <button
            onClick={addTestAction}
            style={{
              padding: '10px 20px',
              background: '#ef4444',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontWeight: '600'
            }}
          >
            🚨 강화된 알림 테스트
          </button>
          
          <button
            onClick={sendTestNotification}
            disabled={notificationPermission !== 'granted'}
            style={{
              padding: '10px 20px',
              background: notificationPermission === 'granted' ? '#3b82f6' : '#9ca3af',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: notificationPermission === 'granted' ? 'pointer' : 'not-allowed',
              fontWeight: '500'
            }}
          >
            🧪 단순 알림 테스트
          </button>
          
          <button
            onClick={clearNotifications}
            style={{
              padding: '10px 20px',
              background: '#f3f4f6',
              color: '#374151',
              border: '1px solid #d1d5db',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            🗑️ 알림 지우기
          </button>
        </div>
      </div>

      {/* 실시간 알림 목록 */}
      <div style={{
        background: 'white',
        border: '1px solid #e2e8f0',
        borderRadius: '8px',
        overflow: 'hidden'
      }}>
        <div style={{
          padding: '16px',
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h3 style={{ margin: 0 }}>
            강화된 실시간 알림 ({notifications.length})
          </h3>
          <div style={{
            fontSize: '12px',
            color: '#64748b'
          }}>
            소리 + 진동 + 깜빡임 + 재알림
          </div>
        </div>

        <div style={{
          maxHeight: '400px',
          overflowY: 'auto'
        }}>
          {notifications.length === 0 ? (
            <div style={{
              padding: '40px',
              textAlign: 'center',
              color: '#64748b'
            }}>
              아직 알림이 없습니다. "강화된 알림 테스트" 버튼을 클릭해보세요.
              <br />
              <small style={{ color: '#9ca3af' }}>
                소리, 진동, 화면 깜빡임, 탭 제목 변경, 재알림 등 모든 기능이 작동합니다.
              </small>
            </div>
          ) : (
            notifications.map((notification, index) => (
              <div
                key={index}
                style={{
                  padding: '16px',
                  borderBottom: index === notifications.length - 1 ? 'none' : '1px solid #f1f5f9',
                  background: index === 0 ? '#fef2f2' : 'white',
                  animation: index === 0 ? 'slideIn 0.3s ease-out' : 'none'
                }}
              >
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginBottom: '8px'
                }}>
                  <div style={{
                    fontSize: '16px',
                    fontWeight: '600',
                    color: '#1e293b'
                  }}>
                    {notification.message}
                  </div>
                  <div style={{
                    fontSize: '12px',
                    color: '#64748b'
                  }}>
                    {notification.time}
                  </div>
                </div>
                
                <div style={{
                  fontSize: '14px',
                  color: '#64748b',
                  marginBottom: '8px'
                }}>
                  Shooter ID: {notification.shooterId} | Schedule ID: {notification.scheduleId}
                </div>

                <div style={{
                  display: 'flex',
                  gap: '6px',
                  flexWrap: 'wrap'
                }}>
                  <span style={{
                    background: '#ef4444',
                    color: 'white',
                    padding: '2px 6px',
                    borderRadius: '4px',
                    fontSize: '11px'
                  }}>
                    강화된 알림
                  </span>
                  <span style={{
                    background: '#8b5cf6',
                    color: 'white',
                    padding: '2px 6px',
                    borderRadius: '4px',
                    fontSize: '11px'
                  }}>
                    소리 + 진동
                  </span>
                  <span style={{
                    background: '#f59e0b',
                    color: 'white',
                    padding: '2px 6px',
                    borderRadius: '4px',
                    fontSize: '11px'
                  }}>
                    화면 깜빡임
                  </span>
                  <span style={{
                    background: '#10b981',
                    color: 'white',
                    padding: '2px 6px',
                    borderRadius: '4px',
                    fontSize: '11px'
                  }}>
                    재알림 3회
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* 기능 설명 */}
      <div style={{
        marginTop: '20px',
        padding: '16px',
        background: '#fef2f2',
        border: '1px solid #fecaca',
        borderRadius: '8px',
        fontSize: '14px',
        color: '#991b1b'
      }}>
        🚨 <strong>강화된 알림 기능:</strong>
        <br />• <strong>브라우저 알림</strong>: requireInteraction으로 클릭할 때까지 유지
        <br />• <strong>재알림</strong>: 10초마다 최대 3번 추가 알림
        <br />• <strong>소리 알림</strong>: 1초 간격으로 3번 연속 재생
        <br />• <strong>화면 깜빡임</strong>: 빨간색으로 6번 깜빡임
        <br />• <strong>탭 제목 변경</strong>: 10초간 제목이 깜빡임
        <br />• <strong>진동</strong>: 모바일에서 진동 패턴 실행
      </div>

      {/* CSS 애니메이션 */}
      <style jsx>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        @keyframes slideIn {
          from { transform: translateX(-100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
