// ?�산 계산 ?�틸리티 
export const calculateSettlement = () =
