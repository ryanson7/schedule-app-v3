import { UserRoleType } from '../types/users';

// 역할별 기본 리다이렉션 경로
export const ROLE_REDIRECT_PATHS: Record<UserRoleType, string> = {
  system_admin: '/',
  schedule_admin: '/',
  academy_manager: '/academy-schedules',
  online_manager: '/studio-schedules',
  professor: '/studio-schedules',
  shooter: '/shooter/dashboard',
  staff: '/'
};

// 역할별 접근 가능한 페이지 목록
export const ROLE_ACCESSIBLE_PAGES: Record<UserRoleType, string[]> = {
  system_admin: [
    '/',
    '/admin/user-management',
    '/admin/monitoring',
    '/admin/settlements',
    '/admin/notifications',
    '/admin/shooter-management',
    '/academy-schedules',
    '/studio-schedules',
    '/studio-admin',
    '/all-schedules',
    '/internal-schedules',
    '/notifications/center'
  ],
  schedule_admin: [
    '/',
    '/admin/user-management',
    '/academy-schedules',
    '/studio-schedules',
    '/all-schedules',
    '/internal-schedules'
  ],
  academy_manager: [
    '/academy-schedules'
  ],
  online_manager: [
    '/studio-schedules',
    '/studio-admin'
  ],
  professor: [
    '/studio-schedules'
  ],
  shooter: [
    '/shooter/dashboard',
    '/shooter/actions',
    '/shooter/schedule-check',
    '/shooter/schedule-register'
  ],
  staff: [
    '/'
  ]
};

// 역할별 리다이렉션 경로 반환
export const getRedirectPath = (role: UserRoleType): string => {
  return ROLE_REDIRECT_PATHS[role] || '/';
};

// 특정 페이지 접근 권한 확인
export const canAccessPage = (role: UserRoleType, path: string): boolean => {
  const accessiblePages = ROLE_ACCESSIBLE_PAGES[role] || [];
  
  // 정확한 경로 매칭 또는 하위 경로 매칭
  return accessiblePages.some(allowedPath => {
    if (allowedPath === path) return true;
    if (path.startsWith(allowedPath + '/')) return true;
    return false;
  });
};

// 역할별 메뉴 구성
export const getRoleMenus = (role: UserRoleType) => {
  switch (role) {
    case 'system_admin':
      return [
        { path: '/', label: '대시보드', icon: '🏠' },
        { path: '/admin/user-management', label: '사용자 관리', icon: '👥' },
        { path: '/academy-schedules', label: '학원 스케줄', icon: '📚' },
        { path: '/studio-schedules', label: '스튜디오 스케줄', icon: '🎬' },
        { path: '/admin/monitoring', label: '모니터링', icon: '📊' },
        { path: '/admin/settlements', label: '정산', icon: '💰' },
        { path: '/admin/notifications', label: '알림 관리', icon: '🔔' }
      ];
    
    case 'schedule_admin':
      return [
        { path: '/', label: '대시보드', icon: '🏠' },
        { path: '/admin/user-management', label: '사용자 관리', icon: '👥' },
        { path: '/academy-schedules', label: '학원 스케줄', icon: '📚' },
        { path: '/studio-schedules', label: '스튜디오 스케줄', icon: '🎬' },
        { path: '/all-schedules', label: '전체 스케줄', icon: '📅' }
      ];
    
    case 'academy_manager':
      return []; // 헤더 전용 레이아웃이므로 메뉴 없음
    
    case 'online_manager':
      return []; // 헤더 전용 레이아웃이므로 메뉴 없음
    
    case 'professor':
      return []; // 헤더 전용 레이아웃이므로 메뉴 없음
    
    case 'shooter':
      return [
        { path: '/shooter/dashboard', label: '대시보드', icon: '🏠' },
        { path: '/shooter/schedule-check', label: '스케줄 확인', icon: '📅' },
        { path: '/shooter/schedule-register', label: '스케줄 등록', icon: '📝' },
        { path: '/shooter/actions', label: '작업 관리', icon: '⚡' }
      ];
    
    default:
      return [
        { path: '/', label: '대시보드', icon: '🏠' }
      ];
  }
};

// 역할별 권한 레벨 반환
export const getRoleLevel = (role: UserRoleType): number => {
  const roleLevels: Record<UserRoleType, number> = {
    system_admin: 100,
    schedule_admin: 80,
    academy_manager: 60,
    online_manager: 60,
    professor: 40,
    shooter: 20,
    staff: 10
  };
  
  return roleLevels[role] || 0;
};

// 역할 표시명 (한국어)
export const ROLE_DISPLAY_NAMES: Record<UserRoleType, string> = {
  system_admin: '시스템 관리자',
  schedule_admin: '스케줄 관리자',
  academy_manager: '학원 관리자',
  online_manager: '온라인 관리자',
  professor: '교수',
  shooter: '촬영자',
  staff: '일반 직원'
};

// 역할별 색상 코드
export const ROLE_COLORS: Record<UserRoleType, string> = {
  system_admin: '#dc2626',    // 빨강
  schedule_admin: '#ea580c',  // 주황
  academy_manager: '#3b82f6', // 파랑
  online_manager: '#059669',  // 녹색
  professor: '#0891b2',       // 청록
  shooter: '#7c3aed',         // 보라
  staff: '#6b7280'            // 회색
};

// 역할별 레이아웃 설정
export interface LayoutConfig {
  showSidebar: boolean;
  showFullHeader: boolean;
  headerTitle: string;
  allowedMenus: Array<{path: string, label: string, icon: string}>;
  contentPadding?: string;
  maxWidth?: string;
}

export const ROLE_LAYOUT_CONFIG: Record<UserRoleType, LayoutConfig> = {
  system_admin: {
    showSidebar: true,
    showFullHeader: false,
    headerTitle: '시스템 관리',
    allowedMenus: getRoleMenus('system_admin'),
    maxWidth: '1400px'
  },
  schedule_admin: {
    showSidebar: true,
    showFullHeader: false,
    headerTitle: '스케줄 관리',
    allowedMenus: getRoleMenus('schedule_admin'),
    maxWidth: '1400px'
  },
  academy_manager: {
    showSidebar: false,
    showFullHeader: true,
    headerTitle: '학원 스케줄 관리',
    allowedMenus: [],
    maxWidth: '1200px'
  },
  online_manager: {
    showSidebar: false,
    showFullHeader: true,
    headerTitle: '온라인 스튜디오 관리',
    allowedMenus: [],
    maxWidth: '1200px'
  },
  professor: {
    showSidebar: false,
    showFullHeader: true,
    headerTitle: '스튜디오 스케줄',
    allowedMenus: [],
    maxWidth: '1200px'
  },
  shooter: {
    showSidebar: true,
    showFullHeader: false,
    headerTitle: '촬영자 대시보드',
    allowedMenus: getRoleMenus('shooter'),
    maxWidth: '1000px'
  },
  staff: {
    showSidebar: false,
    showFullHeader: true,
    headerTitle: '직원 포털',
    allowedMenus: [],
    maxWidth: '800px'
  }
};
