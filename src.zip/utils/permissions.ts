import { 
  UserRoleType, 
  PermissionScope, 
  DEFAULT_PERMISSIONS, 
  RolePermissions,
  normalizeUserRole 
} from '../types/users';

// 🔥 안전한 사용자 역할 검증 함수
export const safeUserRole = (role: string | null | undefined): UserRoleType => {
  if (!role) {
    console.warn('역할이 정의되지 않음, 기본값 "staff"로 설정');
    return 'staff';
  }

  // 역할 정규화 (admin -> system_admin 등)
  const normalizedRole = normalizeUserRole(role);
  
  // 유효한 역할인지 확인
  if (Object.keys(DEFAULT_PERMISSIONS).includes(normalizedRole)) {
    if (role !== normalizedRole) {
      console.log(`🔄 역할 변환: '${role}' → '${normalizedRole}'`);
    }
    return normalizedRole;
  }

  console.warn(`유효하지 않은 역할 '${role}', 기본값 'staff'로 설정`);
  return 'staff';
};

// 🔥 안전한 권한 검사 함수 (방어적 프로그래밍)
export const hasPermission = (
  userRole: string | UserRoleType,
  resource: keyof RolePermissions,
  requiredLevel: PermissionScope,
  userAcademyIds?: number[],
  targetAcademyId?: number
): boolean => {
  try {
    // 🔥 안전한 역할 변환
    const safeRole = safeUserRole(userRole as string);
    
    // 🔥 DEFAULT_PERMISSIONS에서 해당 역할의 권한 확인
    const rolePermissions = DEFAULT_PERMISSIONS[safeRole];
    
    // 역할이 정의되지 않은 경우 권한 없음
    if (!rolePermissions) {
      console.warn(`정의되지 않은 역할: ${safeRole}`);
      return false;
    }

    // 해당 리소스에 대한 권한 확인
    const userPermission = rolePermissions[resource];
    
    // 권한이 정의되지 않은 경우 권한 없음
    if (!userPermission) {
      console.warn(`정의되지 않은 리소스 권한: ${resource} for role ${safeRole}`);
      return false;
    }
    
    // 권한 없음
    if (userPermission === 'none') return false;
    
    // 전체 권한
    if (userPermission === 'admin') return true;
    
    // 담당 영역만 접근 가능
    if (userPermission === 'assigned_only') {
      if (!userAcademyIds || !targetAcademyId) return false;
      return userAcademyIds.includes(targetAcademyId);
    }
    
    // 권한 레벨 비교
    const permissionLevels: PermissionScope[] = ['none', 'read', 'write', 'manage', 'admin'];
    const userLevel = permissionLevels.indexOf(userPermission);
    const requiredLevelIndex = permissionLevels.indexOf(requiredLevel);
    
    return userLevel >= requiredLevelIndex;
  } catch (error) {
    console.error('권한 검사 중 오류:', error);
    return false; // 오류 시 권한 없음으로 처리
  }
};

// 학원 스케줄 권한 검사
export const canAccessAcademySchedule = (
  userRole: string | UserRoleType,
  action: 'read' | 'write' | 'approve',
  userAcademyIds?: number[],
  targetAcademyId?: number
): boolean => {
  return hasPermission(userRole, 'academy_schedules', action, userAcademyIds, targetAcademyId);
};

// 스튜디오 스케줄 권한 검사
export const canAccessStudioSchedule = (
  userRole: string | UserRoleType,
  action: 'read' | 'write' | 'approve'
): boolean => {
  return hasPermission(userRole, 'studio_schedules', action);
};

// 사용자 관리 권한 검사
export const canManageUsers = (
  userRole: string | UserRoleType,
  action: 'read' | 'write' | 'manage',
  userAcademyIds?: number[],
  targetUserAcademyId?: number
): boolean => {
  return hasPermission(userRole, 'user_management', action, userAcademyIds, targetUserAcademyId);
};

// 🔥 역할 유효성 검사
export const isValidUserRole = (role: string): role is UserRoleType => {
  const validRoles: UserRoleType[] = [
    'system_admin', 'schedule_admin', 'academy_manager', 
    'online_manager', 'shooter', 'professor', 'staff'
  ];
  return validRoles.includes(role as UserRoleType);
};

// 역할별 접근 가능한 메뉴 반환
export const getAccessibleMenus = (userRole: string | UserRoleType) => {
  const safeRole = safeUserRole(userRole as string);
  const menus = [];
  
  // 스케줄 메뉴
  if (hasPermission(safeRole, 'academy_schedules', 'read')) {
    menus.push('academy-schedules');
  }
  if (hasPermission(safeRole, 'studio_schedules', 'read')) {
    menus.push('studio-schedules');
  }
  
  // 관리 메뉴
  if (hasPermission(safeRole, 'user_management', 'read')) {
    menus.push('user-management');
  }
  if (hasPermission(safeRole, 'system_settings', 'read')) {
    menus.push('system-settings');
  }
  
  // 촬영 메뉴
  if (hasPermission(safeRole, 'shooting_tasks', 'read')) {
    menus.push('shooting-tasks');
  }
  
  return menus;
};

// 팀 관리 권한 검사
export const canManageTeams = (
  userRole: string | UserRoleType,
  action: 'read' | 'write' | 'manage'
): boolean => {
  return hasPermission(userRole, 'user_management', action);
};

// 역할 할당 권한 검사
export const canAssignRole = (
  currentUserRole: string | UserRoleType,
  targetRole: string | UserRoleType
): boolean => {
  const currentRole = safeUserRole(currentUserRole as string);
  const targetSafeRole = safeUserRole(targetRole as string);
  
  const roleHierarchy: Record<UserRoleType, number> = {
    'system_admin': 7,
    'schedule_admin': 6,
    'academy_manager': 5,
    'online_manager': 5,
    'shooter': 3,
    'professor': 3,
    'staff': 1
  };

  const currentLevel = roleHierarchy[currentRole] || 0;
  const targetLevel = roleHierarchy[targetSafeRole] || 0;

  return currentLevel > targetLevel;
};

// 권한 레벨 비교 유틸리티
export const comparePermissionLevels = (
  level1: PermissionScope,
  level2: PermissionScope
): number => {
  const levels: PermissionScope[] = ['none', 'read', 'write', 'manage', 'admin', 'assigned_only'];
  return levels.indexOf(level1) - levels.indexOf(level2);
};

// 권한 설명 텍스트 반환
export const getPermissionDescription = (permission: PermissionScope): string => {
  switch (permission) {
    case 'none': return '권한 없음';
    case 'read': return '조회만 가능';
    case 'write': return '등록/수정 가능';
    case 'manage': return '관리 권한 (승인/반려)';
    case 'admin': return '전체 권한';
    case 'assigned_only': return '담당 영역만 접근';
    default: return '알 수 없는 권한';
  }
};

// 🔥 역할 표시명 가져오기 (안전한 버전)
export const getRoleDisplayName = (role: string | UserRoleType): string => {
  const safeRole = safeUserRole(role as string);
  
  switch (safeRole) {
    case 'system_admin': return '시스템 관리자';
    case 'schedule_admin': return '스케줄 관리자';
    case 'academy_manager': return '학원 매니저';
    case 'online_manager': return '온라인 매니저';
    case 'shooter': return '촬영자';
    case 'professor': return '교수';
    case 'staff': return '일반 직원';
    default: return safeRole;
  }
};

// 🔥 디버깅용 권한 정보 출력
export const debugPermissions = (userRole: string | UserRoleType) => {
  const safeRole = safeUserRole(userRole as string);
  const permissions = DEFAULT_PERMISSIONS[safeRole];
  
  console.log('🔍 권한 디버그 정보:', {
    원본역할: userRole,
    안전역할: safeRole,
    권한정보: permissions,
    접근가능메뉴: getAccessibleMenus(safeRole)
  });
  
  return { safeRole, permissions };
};
