"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { useTheme } from '../contexts/ThemeContext';

export default function MainNavigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);
  const router = useRouter();
  const { isDark, toggleTheme } = useTheme();

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // 관리자 기준 전체 메뉴 구성
  const menuStructure = [
    {
      id: 'home',
      name: '홈',
      path: '/',
      type: 'single'
    },
    {
      id: 'schedules',
      name: '스케줄 관리',
      type: 'submenu',
      items: [
        { path: '/all-schedules', name: '통합 스케줄' },
        { path: '/academy-schedules', name: '학원 스케줄' },
        { path: '/studio-admin', name: '스튜디오 스케줄' },
        { path: '/internal-schedules', name: '내부업무 스케줄' }
      ]
    },
    {
      id: 'admin',
      name: '관리자',
      type: 'submenu',
      items: [
        { path: '/admin/monitoring', name: '모니터링 대시보드' },
        { path: '/admin/notifications', name: '알림 관리' },
        { path: '/admin/settlements', name: '정산 관리' },
        { path: '/admin/shooter-management', name: '촬영자 관리' }
      ]
    },
    {
      id: 'shooter',
      name: '촬영자',
      type: 'submenu',
      items: [
        { path: '/shooter/dashboard', name: '촬영자 대시보드' },
        { path: '/shooter/actions', name: '촬영 액션' },
        { path: '/shooter/schedule-check', name: '스케줄 확인' },
        { path: '/shooter/schedule-register', name: '스케줄 등록' }
      ]
    },
    {
      id: 'notifications',
      name: '알림',
      type: 'submenu',
      items: [
        { path: '/notifications/center', name: '알림 센터' }
      ]
    },
    {
      id: 'test',
      name: '테스트',
      type: 'submenu',
      items: [
        { path: '/test-access', name: '접근 테스트' },
        { path: '/test-dashboard', name: '대시보드 테스트' },
        { path: '/test-realtime', name: '실시간 테스트' },
        { path: '/test-roles', name: '역할 테스트' },
        { path: '/test-supabase', name: 'Supabase 테스트' }
      ]
    }
  ];

  const handleSubmenuToggle = (menuId: string) => {
    setOpenSubmenu(openSubmenu === menuId ? null : menuId);
  };

  const isCurrentPath = (path: string) => {
    return router.pathname === path;
  };

  const isSubmenuActive = (items: any[]) => {
    return items.some(item => router.pathname === item.path);
  };

  const handleLogout = () => {
    localStorage.clear();
    router.push('/login');
  };

  return (
    <nav style={{
      background: 'var(--bg-secondary)',
      borderBottom: '1px solid var(--border-color)',
      position: 'sticky',
      top: 0,
      zIndex: 1000,
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
      flexShrink: 0
    }}>
      <div style={{
        maxWidth: '1600px',
        margin: '0 auto',
        padding: '0 20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: '60px'
      }}>
        {/* 로고/브랜드 */}
        <div style={{
          fontSize: '20px',
          fontWeight: 'bold',
          color: 'var(--accent-color)',
          cursor: 'pointer'
        }}
        onClick={() => router.push('/')}>
          스케줄 관리 시스템
        </div>

        {/* 데스크탑 메뉴 */}
        <div style={{
          display: !isMobile ? 'flex' : 'none',
          gap: '0',
          alignItems: 'center'
        }}>
          {menuStructure.map(menu => (
            <div key={menu.id} style={{ position: 'relative' }}>
              {menu.type === 'single' ? (
                <button
                  onClick={() => router.push(menu.path!)}
                  style={{
                    padding: '12px 16px',
                    background: isCurrentPath(menu.path!) ? 'var(--accent-color)' : 'transparent',
                    color: isCurrentPath(menu.path!) ? 'white' : 'var(--text-primary)',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '14px',
                    fontWeight: '500'
                  }}
                >
                  {menu.name}
                </button>
              ) : (
                <div
                  onMouseEnter={() => setOpenSubmenu(menu.id)}
                  onMouseLeave={() => setOpenSubmenu(null)}
                  style={{ position: 'relative' }}
                >
                  <button
                    style={{
                      padding: '12px 16px',
                      background: isSubmenuActive(menu.items!) ? 'var(--accent-color)' : 'transparent',
                      color: isSubmenuActive(menu.items!) ? 'white' : 'var(--text-primary)',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: '500',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    {menu.name}
                    <span style={{ fontSize: '10px' }}>▼</span>
                  </button>
                  
                  {/* 서브메뉴 드롭다운 */}
                  {openSubmenu === menu.id && (
                    <div style={{
                      position: 'absolute',
                      top: '100%',
                      left: '0',
                      background: 'var(--bg-secondary)',
                      border: '1px solid var(--border-color)',
                      borderRadius: '8px',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                      minWidth: '200px',
                      zIndex: 1001
                    }}>
                      {menu.items!.map(item => (
                        <button
                          key={item.path}
                          onClick={() => router.push(item.path)}
                          style={{
                            display: 'block',
                            width: '100%',
                            padding: '12px 16px',
                            background: isCurrentPath(item.path) ? 'var(--accent-color)' : 'transparent',
                            color: isCurrentPath(item.path) ? 'white' : 'var(--text-primary)',
                            border: 'none',
                            textAlign: 'left',
                            cursor: 'pointer',
                            fontSize: '14px'
                          }}
                        >
                          {item.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
          
          {/* 다크모드 토글 */}
          <button
            onClick={toggleTheme}
            style={{
              padding: '8px 12px',
              background: 'var(--bg-primary)',
              border: '1px solid var(--border-color)',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              marginLeft: '16px'
            }}
          >
            {isDark ? '라이트' : '다크'}
          </button>

          {/* 로그아웃 버튼 */}
          <button
            onClick={handleLogout}
            style={{
              padding: '8px 12px',
              background: '#dc2626',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '14px',
              marginLeft: '8px'
            }}
          >
            로그아웃
          </button>
        </div>

        {/* 모바일 햄버거 메뉴 */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          style={{
            display: isMobile ? 'block' : 'none',
            background: 'none',
            border: 'none',
            fontSize: '24px',
            cursor: 'pointer',
            color: 'var(--text-primary)'
          }}
        >
          ☰
        </button>
      </div>

      {/* 모바일 메뉴 드롭다운 */}
      {isOpen && isMobile && (
        <div style={{
          background: 'var(--bg-secondary)',
          borderTop: '1px solid var(--border-color)',
          padding: '20px',
          maxHeight: '80vh',
          overflowY: 'auto'
        }}>
          {menuStructure.map(menu => (
            <div key={menu.id} style={{ marginBottom: '8px' }}>
              {menu.type === 'single' ? (
                <button
                  onClick={() => {
                    router.push(menu.path!);
                    setIsOpen(false);
                  }}
                  style={{
                    display: 'block',
                    width: '100%',
                    padding: '12px',
                    background: isCurrentPath(menu.path!) ? 'var(--accent-color)' : 'var(--bg-primary)',
                    color: isCurrentPath(menu.path!) ? 'white' : 'var(--text-primary)',
                    border: 'none',
                    borderRadius: '8px',
                    textAlign: 'left',
                    cursor: 'pointer',
                    fontSize: '14px'
                  }}
                >
                  {menu.name}
                </button>
              ) : (
                <div>
                  <button
                    onClick={() => handleSubmenuToggle(menu.id)}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      width: '100%',
                      padding: '12px',
                      background: isSubmenuActive(menu.items!) ? 'var(--accent-color)' : 'var(--bg-primary)',
                      color: isSubmenuActive(menu.items!) ? 'white' : 'var(--text-primary)',
                      border: 'none',
                      borderRadius: '8px',
                      textAlign: 'left',
                      cursor: 'pointer',
                      fontSize: '14px'
                    }}
                  >
                    {menu.name}
                    <span style={{ fontSize: '12px' }}>
                      {openSubmenu === menu.id ? '▲' : '▼'}
                    </span>
                  </button>
                  
                  {openSubmenu === menu.id && (
                    <div style={{ marginTop: '8px', marginLeft: '16px' }}>
                      {menu.items!.map(item => (
                        <button
                          key={item.path}
                          onClick={() => {
                            router.push(item.path);
                            setIsOpen(false);
                          }}
                          style={{
                            display: 'block',
                            width: '100%',
                            padding: '10px 12px',
                            marginBottom: '4px',
                            background: isCurrentPath(item.path) ? 'var(--accent-color)' : 'transparent',
                            color: isCurrentPath(item.path) ? 'white' : 'var(--text-secondary)',
                            border: '1px solid var(--border-color)',
                            borderRadius: '6px',
                            textAlign: 'left',
                            cursor: 'pointer',
                            fontSize: '13px'
                          }}
                        >
                          {item.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
          
          <button
            onClick={toggleTheme}
            style={{
              width: '100%',
              padding: '12px',
              background: 'var(--bg-primary)',
              border: '1px solid var(--border-color)',
              borderRadius: '8px',
              cursor: 'pointer',
              color: 'var(--text-primary)',
              marginTop: '16px'
            }}
          >
            {isDark ? '라이트 모드' : '다크 모드'}
          </button>

          <button
            onClick={handleLogout}
            style={{
              width: '100%',
              padding: '12px',
              background: '#dc2626',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              marginTop: '8px'
            }}
          >
            로그아웃
          </button>
        </div>
      )}
    </nav>
  );
}
