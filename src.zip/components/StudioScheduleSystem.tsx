"use client";
import { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";

// 촬영 형식 정의
const studioShootingTypes = ['PPT', '일반칠판', '전자칠판', '크로마키', 'PC와콤', 'PC'];

// 시간 옵션 생성 (10분 단위)
const generateTimeOptions = () => {
  const times = [];
  for (let hour = 9; hour < 22; hour++) {
    for (let min = 0; min < 60; min += 10) {
      const h = hour.toString().padStart(2, "0");
      const m = min.toString().padStart(2, "0");
      times.push(`${h}:${m}`);
    }
  }
  return times;
};

const timeOptions = generateTimeOptions();

interface ShootingRequestData {
  shoot_date: string;
  start_time: string;
  end_time: string;
  professor_name: string;
  course_name: string;
  course_code: string;
  shooting_type: string;
  notes: string;
  preferred_studio_id?: number;
}

export default function StudioScheduleSystem() {
  const [userInfo, setUserInfo] = useState<any>(null);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [studioLocations, setStudioLocations] = useState<any[]>([]);
  const [showRequestForm, setShowRequestForm] = useState(true);
  const [formData, setFormData] = useState<ShootingRequestData>({
    shoot_date: '',
    start_time: '',
    end_time: '',
    professor_name: '',
    course_name: '',
    course_code: '',
    shooting_type: '',
    notes: '',
    preferred_studio_id: undefined
  });

  useEffect(() => {
    fetchUserInfo();
    fetchStudioLocations();
  }, []);

  useEffect(() => {
    if (userInfo) {
      fetchMyRequests();
    }
  }, [userInfo]);

  // 사용자 정보 조회
  const fetchUserInfo = async () => {
    const userRole = localStorage.getItem('userRole');
    const userEmail = localStorage.getItem('userEmail');
    
    if (userRole && userEmail) {
      setUserRoles([userRole]);
      
      // 교수 정보 조회 (실제로는 DB에서 조회)
      const mockUserInfo = {
        id: 201,
        name: '김교수',
        email: userEmail,
        preferred_shooting_type: 'PPT', // 선호 촬영 형식
        department: '컴퓨터공학과'
      };
      
      setUserInfo(mockUserInfo);
      setFormData(prev => ({
        ...prev,
        professor_name: mockUserInfo.name,
        shooting_type: mockUserInfo.preferred_shooting_type
      }));
    }
  };

  // 스튜디오 장소 조회
  const fetchStudioLocations = async () => {
    const { data } = await supabase
      .from('sub_locations')
      .select('*, main_locations(name)')
      .eq('is_active', true);
    
    if (data) {
      // 스튜디오만 필터링
      const studioOnly = data.filter(location => {
        const locationName = location.name?.toLowerCase() || '';
        const mainLocationName = location.main_locations?.name?.toLowerCase() || '';
        return locationName.includes('스튜디오') || mainLocationName.includes('스튜디오');
      });
      
      setStudioLocations(studioOnly);
    }
  };

  // 내 촬영 요청 목록 조회
  const fetchMyRequests = async () => {
    const { data } = await supabase
      .from('schedules')
      .select(`
        *,
        sub_locations(name, main_locations(name))
      `)
      .eq('schedule_type', 'studio')
      .eq('professor_name', userInfo.name)
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    
    setMyRequests(data || []);
  };

  // 선호 촬영 형식에 따른 스튜디오 자동 선택
  const getPreferredStudio = (shootingType: string) => {
    // 스튜디오별 특성 매칭 (실제로는 DB에서 관리)
    const studioMapping = {
      'PPT': studioLocations.find(s => s.name?.includes('A')),
      '일반칠판': studioLocations.find(s => s.name?.includes('B')),
      '전자칠판': studioLocations.find(s => s.name?.includes('C')),
      '크로마키': studioLocations.find(s => s.name?.includes('D')),
      'PC와콤': studioLocations.find(s => s.name?.includes('E')),
      'PC': studioLocations.find(s => s.name?.includes('F'))
    };
    
    return studioMapping[shootingType as keyof typeof studioMapping];
  };

  // 촬영 형식 변경 시 자동 스튜디오 배정
  const handleShootingTypeChange = (type: string) => {
    const preferredStudio = getPreferredStudio(type);
    setFormData(prev => ({
      ...prev,
      shooting_type: type,
      preferred_studio_id: preferredStudio?.id
    }));
  };

  // 촬영 요청 제출
  const submitShootingRequest = async () => {
    if (!formData.shoot_date || !formData.start_time || !formData.end_time || !formData.shooting_type) {
      alert('필수 항목을 모두 입력해주세요.');
      return;
    }

    const requestData = {
      ...formData,
      schedule_type: 'studio',
      approval_status: 'pending',
      team_id: 1,
      sub_location_id: formData.preferred_studio_id,
      is_active: true,
      created_at: new Date().toISOString()
    };

    const { error } = await supabase.from('schedules').insert([requestData]);
    
    if (error) {
      alert('촬영 요청 오류: ' + error.message);
    } else {
      alert('촬영 요청이 제출되었습니다. 관리자 검토 후 확정됩니다.');
      resetForm();
      fetchMyRequests();
    }
  };

  const resetForm = () => {
    setFormData({
      shoot_date: '',
      start_time: '',
      end_time: '',
      professor_name: userInfo?.name || '',
      course_name: '',
      course_code: '',
      shooting_type: userInfo?.preferred_shooting_type || '',
      notes: '',
      preferred_studio_id: undefined
    });
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'approved':
        return { bg: '#e8f5e8', color: '#155724', text: '촬영확정' };
      case 'pending':
        return { bg: '#fff3cd', color: '#856404', text: '검토중' };
      case 'cancelled':
        return { bg: '#f8d7da', color: '#721c24', text: '취소됨' };
      default:
        return { bg: '#f0f0f0', color: '#666', text: '기타' };
    }
  };

  const isProfessor = userRoles.includes('professor') || userRoles.includes('professor');

  if (!isProfessor) {
    return (
      <div style={{ padding: 40, textAlign: 'center' }}>
        <h2>스튜디오 촬영 시스템</h2>
        <p>교수님만 접근 가능한 시스템입니다.</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: 20 }}>
      <div style={{ marginBottom: 30 }}>
        <h1 style={{ color: '#2c3e50', fontSize: 28, marginBottom: 10 }}>
          스튜디오 촬영 요청 시스템
        </h1>
        <p style={{ color: '#666', fontSize: 16 }}>
          안녕하세요, {userInfo?.name} 교수님. 촬영 요청을 등록해주세요.
        </p>
      </div>

      {/* 촬영 요청 등록 폼 */}
      {showRequestForm && (
        <div style={{ 
          background: 'white', 
          borderRadius: 12, 
          padding: 30, 
          marginBottom: 30,
          boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
          border: '1px solid #e9ecef'
        }}>
          <h2 style={{ margin: '0 0 25px 0', color: '#495057', fontSize: 22 }}>
            새 촬영 요청 등록
          </h2>
          
          <div style={{ display: 'grid', gap: 20 }}>
            {/* 기본 정보 */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 15 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                  촬영 날짜 *
                </label>
                <input 
                  type="date" 
                  value={formData.shoot_date} 
                  onChange={(e) => setFormData({...formData, shoot_date: e.target.value})} 
                  style={{ 
                    width: '100%', 
                    padding: 12, 
                    border: '2px solid #dee2e6', 
                    borderRadius: 8,
                    fontSize: 14
                  }} 
                  required 
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                  교수명
                </label>
                <input 
                  type="text" 
                  value={formData.professor_name} 
                  readOnly
                  style={{ 
                    width: '100%', 
                    padding: 12, 
                    border: '2px solid #e9ecef', 
                    borderRadius: 8,
                    background: '#f8f9fa',
                    fontSize: 14
                  }} 
                />
              </div>
            </div>

            {/* 시간 설정 */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 15 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                  시작 시간 *
                </label>
                <select 
                  value={formData.start_time} 
                  onChange={(e) => setFormData({...formData, start_time: e.target.value})} 
                  style={{ 
                    width: '100%', 
                    padding: 12, 
                    border: '2px solid #dee2e6', 
                    borderRadius: 8,
                    fontSize: 14
                  }} 
                  required
                >
                  <option value="">시작 시간 선택</option>
                  {timeOptions.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                  종료 시간 *
                </label>
                <select 
                  value={formData.end_time} 
                  onChange={(e) => setFormData({...formData, end_time: e.target.value})} 
                  style={{ 
                    width: '100%', 
                    padding: 12, 
                    border: '2px solid #dee2e6', 
                    borderRadius: 8,
                    fontSize: 14
                  }} 
                  required
                >
                  <option value="">종료 시간 선택</option>
                  {timeOptions.map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* 촬영 형식 선택 */}
            <div>
              <label style={{ display: 'block', marginBottom: 10, fontWeight: 'bold', color: '#495057' }}>
                촬영 형식 * (선호 형식: {userInfo?.preferred_shooting_type})
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                {studioShootingTypes.map(type => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleShootingTypeChange(type)}
                    style={{
                      padding: '12px 16px',
                      border: formData.shooting_type === type ? '3px solid #007bff' : '2px solid #dee2e6',
                      borderRadius: 8,
                      background: formData.shooting_type === type ? 
                        'linear-gradient(135deg, #007bff, #0056b3)' : 
                        'white',
                      color: formData.shooting_type === type ? 'white' : '#495057',
                      cursor: 'pointer',
                      fontWeight: formData.shooting_type === type ? 'bold' : 'normal',
                      transition: 'all 0.3s ease',
                      fontSize: 14
                    }}
                  >
                    {type}
                  </button>
                ))}
              </div>
              {formData.preferred_studio_id && (
                <div style={{ marginTop: 10, padding: 10, background: '#e3f2fd', borderRadius: 6, fontSize: 14 }}>
                  자동 배정 스튜디오: {studioLocations.find(s => s.id === formData.preferred_studio_id)?.name}
                </div>
              )}
            </div>

            {/* 강좌 정보 */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 15 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                  강좌명
                </label>
                <input 
                  type="text" 
                  value={formData.course_name} 
                  onChange={(e) => setFormData({...formData, course_name: e.target.value})} 
                  placeholder="예: 데이터베이스 설계"
                  style={{ 
                    width: '100%', 
                    padding: 12, 
                    border: '2px solid #dee2e6', 
                    borderRadius: 8,
                    fontSize: 14
                  }} 
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                  강좌코드
                </label>
                <input 
                  type="text" 
                  value={formData.course_code} 
                  onChange={(e) => setFormData({...formData, course_code: e.target.value})} 
                  placeholder="예: CS101"
                  style={{ 
                    width: '100%', 
                    padding: 12, 
                    border: '2px solid #dee2e6', 
                    borderRadius: 8,
                    fontSize: 14
                  }} 
                />
              </div>
            </div>

            {/* 전달사항 */}
            <div>
              <label style={{ display: 'block', marginBottom: 6, fontWeight: 'bold', color: '#495057' }}>
                전달사항
              </label>
              <textarea 
                value={formData.notes} 
                onChange={(e) => setFormData({...formData, notes: e.target.value})} 
                placeholder="촬영 시 특별히 요청하실 사항이 있으시면 입력해주세요."
                style={{ 
                  width: '100%', 
                  padding: 12, 
                  border: '2px solid #dee2e6', 
                  borderRadius: 8, 
                  minHeight: 80,
                  fontSize: 14,
                  resize: 'vertical'
                }} 
              />
            </div>

            {/* 제출 버튼 */}
            <div style={{ display: 'flex', gap: 12, marginTop: 20 }}>
              <button 
                onClick={submitShootingRequest}
                style={{ 
                  flex: 1, 
                  padding: 15, 
                  background: 'linear-gradient(135deg, #28a745, #20c997)', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: 8, 
                  cursor: 'pointer', 
                  fontSize: 16,
                  fontWeight: 'bold',
                  boxShadow: '0 4px 8px rgba(40, 167, 69, 0.3)'
                }}
              >
                촬영 요청 제출
              </button>
              <button 
                onClick={resetForm}
                style={{ 
                  flex: 0.3, 
                  padding: 15, 
                  background: '#6c757d', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: 8, 
                  cursor: 'pointer', 
                  fontSize: 16
                }}
              >
                초기화
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 내 촬영 요청 목록 */}
      <div style={{ 
        background: 'white', 
        borderRadius: 12, 
        padding: 30,
        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
        border: '1px solid #e9ecef'
      }}>
        <h2 style={{ margin: '0 0 25px 0', color: '#495057', fontSize: 22 }}>
          내 촬영 요청 목록 ({myRequests.length}건)
        </h2>
        
        {myRequests.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#6c757d' }}>
            아직 등록된 촬영 요청이 없습니다.
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 15 }}>
            {myRequests.map((request, index) => {
              const statusInfo = getStatusInfo(request.approval_status);
              
              return (
                <div 
                  key={request.id} 
                  style={{ 
                    padding: 20, 
                    border: '2px solid #e9ecef', 
                    borderRadius: 10,
                    background: '#f8f9fa',
                    transition: 'all 0.2s ease'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 15 }}>
                    <div>
                      <h3 style={{ margin: '0 0 8px 0', color: '#495057', fontSize: 18 }}>
                        {request.course_name || '강좌명 미입력'}
                      </h3>
                      <div style={{ color: '#6c757d', fontSize: 14 }}>
                        {request.shoot_date} | {request.start_time?.substring(0, 5)}~{request.end_time?.substring(0, 5)}
                      </div>
                    </div>
                    <span style={{
                      padding: '6px 12px',
                      borderRadius: 20,
                      fontSize: 12,
                      fontWeight: 'bold',
                      background: statusInfo.bg,
                      color: statusInfo.color
                    }}>
                      {statusInfo.text}
                    </span>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 15, fontSize: 14 }}>
                    <div>
                      <strong>촬영 형식:</strong> {request.shooting_type}
                    </div>
                    <div>
                      <strong>강좌코드:</strong> {request.course_code || '-'}
                    </div>
                    <div>
                      <strong>배정 스튜디오:</strong> {request.sub_locations?.name || '미배정'}
                    </div>
                  </div>
                  
                  {request.notes && (
                    <div style={{ marginTop: 12, padding: 12, background: 'white', borderRadius: 6, fontSize: 14 }}>
                      <strong>전달사항:</strong> {request.notes}
                    </div>
                  )}
                  
                  <div style={{ marginTop: 12, fontSize: 12, color: '#6c757d' }}>
                    요청일시: {new Date(request.created_at).toLocaleString('ko-KR')}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
