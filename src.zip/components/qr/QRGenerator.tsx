// QR 코드 ?�성�?
export default function QRGenerator() {} 
