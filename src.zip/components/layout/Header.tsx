import { UserRoleType } from '../../types/users';
import { ROLE_DISPLAY_NAMES, ROLE_COLORS } from '../../utils/roleRedirection';

interface HeaderProps {
  title: string;
  userRole: UserRoleType;
  userName: string;
  onLogout: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

const Header = ({ 
  title, 
  userRole, 
  userName, 
  onLogout, 
  isDarkMode, 
  onToggleDarkMode 
}: HeaderProps) => {
  return (
    <header className="header">
      <div className="header-content">
        <div className="header-left">
          <h1>{title}</h1>
          <span 
            className="role-badge"
            style={{ backgroundColor: ROLE_COLORS[userRole] }}
          >
            {ROLE_DISPLAY_NAMES[userRole]}
          </span>
        </div>
        
        <div className="header-right">
          <span className="user-name">{userName}</span>
          <button 
            onClick={onToggleDarkMode}
            className="theme-toggle"
            title={isDarkMode ? '라이트 모드로 전환' : '다크 모드로 전환'}
          >
            {isDarkMode ? '☀️' : '🌙'}
          </button>
          <button onClick={onLogout} className="logout-btn">
            로그아웃
          </button>
        </div>
      </div>

      <style jsx>{`
        .header {
          background: var(--bg-secondary);
          border-bottom: 1px solid var(--border-color);
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .header-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px 24px;
          max-width: 1400px;
          margin: 0 auto;
        }

        .header-left {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .header-left h1 {
          margin: 0;
          font-size: 24px;
          font-weight: 700;
          color: var(--text-primary);
        }

        .role-badge {
          padding: 4px 12px;
          border-radius: 16px;
          font-size: 12px;
          font-weight: 600;
          color: white;
        }

        .header-right {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .user-name {
          font-weight: 500;
          color: var(--text-secondary);
          font-size: 14px;
        }

        .theme-toggle {
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: 8px;
          padding: 8px;
          cursor: pointer;
          font-size: 16px;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 36px;
          height: 36px;
        }

        .theme-toggle:hover {
          background: var(--bg-hover);
        }

        .logout-btn {
          background: #dc2626;
          color: white;
          border: none;
          border-radius: 6px;
          padding: 8px 16px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.2s ease;
        }

        .logout-btn:hover {
          background: #b91c1c;
        }

        @media (max-width: 768px) {
          .header-content {
            padding: 12px 16px;
          }

          .header-left h1 {
            font-size: 20px;
          }

          .header-right {
            gap: 8px;
          }

          .user-name {
            display: none;
          }
        }
      `}</style>
    </header>
  );
};

export default Header;
