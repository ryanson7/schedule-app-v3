"use client";
import { useEffect, useState } from "react";
import { supabase } from "../utils/supabaseClient";
import { useWeek } from "../contexts/WeekContext";
import { UserRoleType } from "../types/users";
import { safeUserRole } from "../utils/permissions";
import BaseScheduleGrid from "./core/BaseScheduleGrid";
import StudioScheduleModal from "./modals/StudioScheduleModal";

interface StudioAdminPanelProps {
  currentUserRole?: UserRoleType;
}

export default function StudioAdminPanel({ currentUserRole }: StudioAdminPanelProps) {
  const [hasAccess, setHasAccess] = useState(false);
  const [accessLoading, setAccessLoading] = useState(true);
  
  const [schedules, setSchedules] = useState<any[]>([]);
  const [studioLocations, setStudioLocations] = useState<any[]>([]);
  const [selectedSchedules, setSelectedSchedules] = useState<number[]>([]);
  const [draggedSchedule, setDraggedSchedule] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isClient, setIsClient] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  
  // 단일 모달 상태 관리
  const [modalOpen, setModalOpen] = useState(false);
  const [modalData, setModalData] = useState<any>(null);

  const { currentWeek, navigateWeek } = useWeek();

  // 권한 체크
  useEffect(() => {
    checkAccess();
  }, [currentUserRole]);

  const checkAccess = () => {
    let role = currentUserRole;
    
    if (!role) {
      const userRole = localStorage.getItem('userRole');
      role = userRole ? safeUserRole(userRole) : 'staff';
    }

    console.log('StudioAdminPanel 권한 확인:', {
      propsRole: currentUserRole,
      finalRole: role,
      허용역할: ['system_admin', 'schedule_admin']
    });

    const allowedRoles: UserRoleType[] = ['system_admin', 'schedule_admin'];
    const accessGranted = allowedRoles.includes(role);
    
    setHasAccess(accessGranted);
    setAccessLoading(false);
    
    if (accessGranted) {
      setIsClient(true);
    }
  };

  // 데이터 로딩
  useEffect(() => {
    if (!isClient || !hasAccess) return;
    fetchData();
  }, [isClient, currentWeek, hasAccess]);

  const fetchData = async () => {
    if (!hasAccess) return;
    await Promise.all([fetchSchedules(), fetchStudioLocations()]);
    setIsLoading(false);
  };

  // 스케줄 데이터 로딩
  const fetchSchedules = async () => {
    if (!hasAccess) return;
    
    try {
      console.log('스튜디오 스케줄 데이터 로딩 시작');
      
      let query = supabase.from('schedules').select('*');
      
      query = query.eq('schedule_type', 'studio');
      query = query.in('approval_status', ['approved', 'confirmed']);
      
      const { data, error } = await query
        .order('shoot_date')
        .order('start_time');
      
      if (error) throw error;
      
      console.log('스튜디오 스케줄 데이터 로딩 완료:', data?.length || 0, '개');
      setSchedules(data || []);
    } catch (error) {
      console.error('스케줄 데이터 로딩 오류:', error);
    }
  };

  // 스튜디오 위치 및 촬영형식 매핑 로딩
  const fetchStudioLocations = async () => {
    if (!hasAccess) return;
    
    try {
      console.log('스튜디오 위치 데이터 로딩 시작');
      
      const { data: allLocations, error: locationError } = await supabase
        .from('sub_locations')
        .select('*, main_locations(name)')
        .eq('is_active', true);
      
      if (locationError) throw locationError;
      
      // 스튜디오만 필터링 (1~15번 스튜디오, main_location_id = 8)
      const studioLocations = allLocations?.filter(loc => {
        const isNumeric = /^\d+$/.test(loc.name || '');
        const studioNumber = parseInt(loc.name || '0');
        const isStudioLocation = loc.main_location_id === 8;
        
        return isNumeric && studioNumber >= 1 && studioNumber <= 15 && isStudioLocation;
      }) || [];

      // 숫자 순서로 정렬 (1, 2, 3, 4, 5... 순서)
      studioLocations.sort((a, b) => {
        const numA = parseInt(a.name || '0');
        const numB = parseInt(b.name || '0');
        return numA - numB;
      });

      console.log('필터링 및 정렬된 스튜디오 목록:', studioLocations.map(s => ({ id: s.id, name: s.name })));
      
      // 각 스튜디오별 촬영형식 매핑 로딩
      const studioWithShootingTypes = await Promise.all(
        studioLocations.map(async (studio) => {
          try {
            console.log(`스튜디오 ${studio.name}번 촬영형식 조회 시작`);
            
            const { data: shootingTypeData, error: shootingTypeError } = await supabase
              .from('sub_location_shooting_types')
              .select(`
                is_primary,
                shooting_types!inner(
                  id,
                  name,
                  description,
                  is_active
                )
              `)
              .eq('sub_location_id', studio.id)
              .eq('shooting_types.is_active', true)
              .order('is_primary', { ascending: false });
            
            if (shootingTypeError) {
              console.error(`스튜디오 ${studio.name}번 촬영형식 조회 오류:`, shootingTypeError);
              return {
                ...studio,
                shooting_types: [],
                primary_shooting_type: null
              };
            }
            
            const shootingTypes = shootingTypeData?.map(st => st.shooting_types.name).sort() || [];
            const primaryType = shootingTypeData?.find(st => st.is_primary)?.shooting_types.name || null;
            
            console.log(`스튜디오 ${studio.name}번 촬영형식:`, {
              types: shootingTypes,
              primary: primaryType
            });
            
            return {
              ...studio,
              shooting_types: shootingTypes,
              primary_shooting_type: primaryType
            };
            
          } catch (error) {
            console.error(`스튜디오 ${studio.name}번 촬영형식 처리 오류:`, error);
            return {
              ...studio,
              shooting_types: [],
              primary_shooting_type: null
            };
          }
        })
      );
      
      console.log('스튜디오 촬영형식 매핑 완료:', studioWithShootingTypes.map(s => ({ 
        id: s.id, 
        name: s.name, 
        types: s.shooting_types,
        primary: s.primary_shooting_type
      })));
      
      setStudioLocations(studioWithShootingTypes);
      
    } catch (error) {
      console.error('스튜디오 데이터 로딩 오류:', error);
    }
  };

  // 드래그 앤 드롭 래퍼
  const StudioGridWrapper = ({ children }: { children: React.ReactNode }) => {
    return (
      <div 
        onDragOver={(e) => {
          e.preventDefault();
          e.dataTransfer.dropEffect = 'move';
          setIsDragOver(true);
        }}
        onDragLeave={() => {
          setIsDragOver(false);
        }}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragOver(false);
          
          if (!draggedSchedule) return;
          
          const target = e.target as HTMLElement;
          let cellElement = target.closest('td');
          
          if (cellElement) {
            handleDropByTableStructure(e, cellElement);
          }
        }}
        style={{ 
          width: '100%', 
          height: '100%', 
          position: 'relative',
          backgroundColor: isDragOver ? 'rgba(139, 92, 246, 0.05)' : 'transparent',
          transition: 'all 0.2s ease'
        }}
      >
        {children}
        
        {isDragOver && draggedSchedule && (
          <div style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            background: 'rgba(139, 92, 246, 0.95)',
            color: 'white',
            padding: '16px 32px',
            borderRadius: '12px',
            fontSize: '18px',
            fontWeight: 'bold',
            pointerEvents: 'none',
            zIndex: 10000,
            boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
            border: '2px solid #ffffff'
          }}>
            스튜디오 스케줄을 이동할 위치에 드롭하세요
          </div>
        )}
      </div>
    );
  };

  // 드롭 처리 (테이블 구조 기반)
  const handleDropByTableStructure = (e: React.DragEvent, cellElement: HTMLElement) => {
    const table = cellElement.closest('table');
    if (!table) return;

    const cellIndex = Array.from(cellElement.parentElement?.children || []).indexOf(cellElement);
    const rowIndex = Array.from(table.rows).indexOf(cellElement.parentElement as HTMLTableRowElement);
    
    if (cellIndex > 0 && rowIndex > 0) {
      const dateHeaderCell = table.rows[0]?.cells[cellIndex];
      const studioHeaderCell = table.rows[rowIndex]?.cells[0];
      
      if (dateHeaderCell && studioHeaderCell) {
        extractDateAndStudio(dateHeaderCell, studioHeaderCell);
      }
    }
  };

  // 날짜와 스튜디오 정보 추출
  const extractDateAndStudio = (dateHeader: HTMLElement, studioHeader: HTMLElement) => {
    const dateText = dateHeader.textContent || '';
    const studioText = studioHeader.textContent || '';
    
    const dayMatch = dateText.match(/(\d+)\s*\(/);
    
    if (dayMatch) {
      const day = parseInt(dayMatch[1]);
      
      const currentDate = new Date(currentWeek);
      const startOfWeek = new Date(currentDate);
      const dayOfWeek = startOfWeek.getDay();
      const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
      startOfWeek.setDate(startOfWeek.getDate() + mondayOffset);
      
      const targetDate = new Date(startOfWeek);
      targetDate.setDate(startOfWeek.getDate() + (day - startOfWeek.getDate()));
      
      if (Math.abs(targetDate.getDate() - day) > 7) {
        targetDate.setFullYear(currentDate.getFullYear());
        targetDate.setMonth(currentDate.getMonth());
        targetDate.setDate(day);
      }
      
      const dateString = targetDate.toISOString().split('T')[0];
      
      const studioMatch = studioText.match(/(\d+)번/);
      if (studioMatch) {
        const studioNumber = parseInt(studioMatch[1]);
        const studio = studioLocations.find(loc => loc.name === studioNumber.toString());
        
        if (studio) {
          handleCellDrop(dateString, studio);
        }
      }
    }
  };

  // 셀 클릭 처리
  const handleCellClick = (date: string, location: any) => {
    if (!hasAccess) return;
    
    console.log('스튜디오 셀 클릭:', { date, locationId: location.id });
    setModalData({
      date,
      locationId: location.id
    });
    setModalOpen(true);
  };

  // 셀의 스케줄 조회
  const getScheduleForCell = (date: string, location: any) => {
    return schedules.filter(s => s.shoot_date === date && s.sub_location_id === location.id);
  };

  // 스케줄 카드 클릭 처리
  const handleScheduleCardClick = (schedule: any) => {
    if (!hasAccess) return;
    console.log('스튜디오 스케줄 카드 클릭:', schedule);
    setModalData({
      date: schedule.shoot_date,
      locationId: schedule.sub_location_id,
      scheduleData: schedule
    });
    setModalOpen(true);
  };

  // 셀 드롭 처리
  const handleCellDrop = (date: string, location: any) => {
    if (!draggedSchedule) return;
    
    if (draggedSchedule.sub_location_id === location.id && draggedSchedule.shoot_date === date) {
      setDraggedSchedule(null);
      return;
    }
    
    if (draggedSchedule.shoot_date !== date) {
      const confirmed = window.confirm(
        `스케줄을 다른 날짜로 이동하시겠습니까?\n\n` +
        `${draggedSchedule.shoot_date} → ${date}\n` +
        `${draggedSchedule.professor_name} / ${draggedSchedule.course_name}`
      );
      
      if (confirmed) {
        handleDateAndStudioChange(draggedSchedule.id, date, location.id);
      }
    } else {
      handleStudioReassign(draggedSchedule.id, location.id);
    }
    
    setDraggedSchedule(null);
  };

  // 스케줄 카드 렌더링
  const renderStudioScheduleCard = (schedule: any) => {
    const statusInfo = getStatusInfo(schedule.approval_status);
    const isSelected = selectedSchedules.includes(schedule.id);
    const isDragging = draggedSchedule?.id === schedule.id;
    
    return (
      <div 
        key={schedule.id}
        draggable={true}
        onDragStart={(e) => {
          if (draggedSchedule?.id === schedule.id) return;
          handleDragStart(e, schedule);
        }}
        onDragEnd={() => {
          setDraggedSchedule(null);
        }}
        onClick={(e) => {
          e.stopPropagation();
          handleScheduleCardClick(schedule);
        }}
        style={{ 
          padding: '8px',
          background: isDragging ? '#f3e8ff' : '#fafafa',
          borderRadius: '6px',
          border: '2px solid #e5e7eb',
          cursor: isDragging ? 'grabbing' : 'grab',
          marginBottom: '4px',
          position: 'relative',
          opacity: isDragging ? 0.7 : 1,
          transition: 'all 0.2s ease',
          boxShadow: isDragging 
            ? '0 8px 25px rgba(139, 92, 246, 0.3)' 
            : '0 2px 4px rgba(0,0,0,0.1)',
          pointerEvents: isDragging ? 'none' : 'auto'
        }}
      >
        <input
          type="checkbox"
          checked={isSelected}
          onChange={(e) => {
            e.stopPropagation();
            if (e.target.checked) {
              setSelectedSchedules([...selectedSchedules, schedule.id]);
            } else {
              setSelectedSchedules(selectedSchedules.filter(id => id !== schedule.id));
            }
          }}
          onClick={(e) => e.stopPropagation()}
          style={{ 
            position: 'absolute', 
            top: '4px', 
            right: '4px', 
            zIndex: 10,
            transform: 'scale(1.2)'
          }}
        />

        <div style={{
          position: 'absolute',
          top: '8px',
          right: '8px',
          width: '12px',
          height: '12px',
          borderRadius: '50%',
          background: 
            schedule.approval_status === 'approved' || schedule.approval_status === 'confirmed' ? '#22c55e' :
            schedule.approval_status === 'pending' ? '#f59e0b' : '#ef4444',
          boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
          zIndex: 5
        }} />

        <div style={{ 
          fontWeight: '700', 
          color: '#1f2937', 
          fontSize: '12px',
          marginBottom: '4px'
        }}>
          {schedule.start_time?.substring(0, 5)}~{schedule.end_time?.substring(0, 5)}
        </div>
        
        <div style={{ 
          fontSize: '10px', 
          marginBottom: '4px', 
          color: '#1f2937', 
          fontWeight: '600',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }}>
          {schedule.professor_name}
        </div>
        
        <div style={{ 
          fontSize: '9px', 
          color: '#6b7280', 
          fontWeight: '400',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          marginBottom: '4px'
        }}>
          {schedule.course_name}
        </div>
        
        <div style={{ 
          fontSize: '8px', 
          color: '#8b5cf6', 
          fontWeight: '500',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          marginBottom: '4px'
        }}>
          {schedule.shooting_type}
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
          <span style={{
            fontSize: 7, 
            padding: '1px 3px', 
            borderRadius: 2,
            background: statusInfo.bg, 
            color: statusInfo.color,
            fontWeight: 600
          }}>
            {statusInfo.text}
          </span>
        </div>
      </div>
    );
  };

  // 드래그 시작 처리
  const handleDragStart = (e: React.DragEvent, schedule: any) => {
    if (draggedSchedule) {
      e.preventDefault();
      return;
    }
    
    setDraggedSchedule(schedule);
    
    const dragData = {
      id: schedule.id,
      shoot_date: schedule.shoot_date,
      sub_location_id: schedule.sub_location_id,
      professor_name: schedule.professor_name,
      course_name: schedule.course_name,
      start_time: schedule.start_time,
      end_time: schedule.end_time,
      shooting_type: schedule.shooting_type
    };
    
    e.dataTransfer.setData('application/json', JSON.stringify(dragData));
    e.dataTransfer.effectAllowed = 'move';
  };

  // 날짜와 스튜디오 변경
  const handleDateAndStudioChange = async (scheduleId: number, newDate: string, newStudioId: number) => {
    if (!hasAccess) return;
    
    try {
      const currentSchedule = schedules.find(s => s.id === scheduleId);
      if (!currentSchedule) return;

      const { error } = await supabase
        .from('schedules')
        .update({ 
          shoot_date: newDate,
          sub_location_id: newStudioId,
          updated_at: new Date().toISOString()
        })
        .eq('id', scheduleId);
      
      if (error) {
        console.error('일정 이동 오류:', error);
        alert('일정 이동 오류: ' + error.message);
      } else {
        alert('스케줄이 성공적으로 이동되었습니다.');
        fetchSchedules();
      }
    } catch (error) {
      console.error('일정 이동 처리 오류:', error);
      alert('일정 이동 중 오류가 발생했습니다.');
    }
  };

  // 스튜디오 재배정
  const handleStudioReassign = async (scheduleId: number, newStudioId: number) => {
    if (!hasAccess) return;
    
    try {
      const currentSchedule = schedules.find(s => s.id === scheduleId);
      if (!currentSchedule) return;

      const sourceStudio = studioLocations.find(s => s.id === currentSchedule.sub_location_id);
      const targetStudio = studioLocations.find(s => s.id === newStudioId);
      
      const confirmed = window.confirm(
        `스케줄을 이동하시겠습니까?\n\n` +
        `${sourceStudio?.name}번 → ${targetStudio?.name}번\n` +
        `${currentSchedule.professor_name} / ${currentSchedule.course_name}`
      );
      
      if (!confirmed) return;

      const { error } = await supabase
        .from('schedules')
        .update({ 
          sub_location_id: newStudioId,
          updated_at: new Date().toISOString()
        })
        .eq('id', scheduleId);
      
      if (error) {
        console.error('스튜디오 재배정 오류:', error);
        alert('스튜디오 재배정 오류: ' + error.message);
      } else {
        alert(`스케줄이 ${targetStudio?.name}번 스튜디오로 이동되었습니다.`);
        fetchSchedules();
      }
    } catch (error) {
      console.error('재배정 처리 오류:', error);
      alert('스케줄 이동 중 오류가 발생했습니다.');
    }
  };

  // 위치 색상
  const getLocationColor = (locationId: number) => {
    return { bg: '#fafafa', border: '#e5e7eb', text: '#1f2937' };
  };

  // 상태 정보
  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'approved':
      case 'confirmed':
        return { bg: '#22c55e', color: '#ffffff', text: '촬영확정' };
      case 'pending':
        return { bg: '#f59e0b', color: '#ffffff', text: '검토중' };
      case 'cancelled':
        return { bg: '#ef4444', color: '#ffffff', text: '촬영취소' };
      case 'completed':
        return { bg: '#3b82f6', color: '#ffffff', text: '촬영완료' };
      default:
        return { bg: '#6b7280', color: '#ffffff', text: '기타' };
    }
  };

  // 저장 핸들러
  const handleSave = async (data: any, action: 'temp' | 'request' | 'approve') => {
    try {
      if (modalData?.scheduleData) {
        // 수정
        const { error } = await supabase
          .from('schedules')
          .update({
            ...data,
            approval_status: action === 'approve' ? 'approved' : action === 'request' ? 'pending' : 'temp',
            approved_at: action === 'approve' ? new Date().toISOString() : null,
            updated_at: new Date().toISOString()
          })
          .eq('id', modalData.scheduleData.id);
        
        if (error) throw error;
        
        const message = action === 'approve' ? '승인 완료되었습니다.' : 
                       action === 'request' ? '등록 요청되었습니다.' : '임시저장되었습니다.';
        
        setModalOpen(false);
        fetchSchedules();
        return { success: true, message };
      } else {
        // 신규 등록
        const scheduleData = {
          ...data,
          schedule_type: 'studio',
          approval_status: action === 'approve' ? 'approved' : action === 'request' ? 'pending' : 'temp',
          approved_at: action === 'approve' ? new Date().toISOString() : null,
          team_id: 1,
          is_active: true,
          created_at: new Date().toISOString()
        };

        const { error } = await supabase.from('schedules').insert([scheduleData]);
        
        if (error) throw error;
        
        const message = action === 'approve' ? '승인 완료되었습니다.' : 
                       action === 'request' ? '등록 요청되었습니다.' : '임시저장되었습니다.';
        
        setModalOpen(false);
        fetchSchedules();
        return { success: true, message };
      }
    } catch (error) {
      console.error('저장 오류:', error);
      const message = error instanceof Error ? error.message : '저장 실패';
      return { success: false, message };
    }
  };

  // 실시간 업데이트 구독
  useEffect(() => {
    if (!hasAccess) return;
    
    const subscription = supabase
      .channel('studio_schedule_changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'schedules',
          filter: 'schedule_type=eq.studio'
        }, 
        (payload) => {
          if (!modalOpen) {
            fetchSchedules();
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [hasAccess, modalOpen]);

  // 권한 체크 렌더링
  if (accessLoading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid #8b5cf6',
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }} />
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div style={{ 
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        padding: '40px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <h3 style={{ color: '#dc2626', marginBottom: '16px' }}>
            접근 권한이 없습니다
          </h3>
          <p>스튜디오 관리는 시스템 관리자만 접근할 수 있습니다.</p>
        </div>
      </div>
    );
  }

  if (!isClient || isLoading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh'
      }}>
        스튜디오 데이터를 불러오는 중...
      </div>
    );
  }

  return (
    <>
      <StudioGridWrapper>
        <BaseScheduleGrid
          title="스튜디오 관리 패널"
          leftColumnTitle="스튜디오"
          locations={studioLocations.map(loc => ({
            id: loc.id,
            name: `${loc.name}번\n${(loc.shooting_types || []).join(', ')}`,
            shootingTypes: loc.shooting_types || [],
            primaryShootingType: loc.primary_shooting_type || null
          }))}
          schedules={schedules}
          currentWeek={currentWeek}
          onWeekChange={navigateWeek}
          onCellClick={handleCellClick}
          getScheduleForCell={getScheduleForCell}
          renderScheduleCard={renderStudioScheduleCard}
          showAddButton={true}
          onCopyPreviousWeek={undefined}
          userRole="admin"
          pageType="studio"
          getLocationColor={getLocationColor}
        />
      </StudioGridWrapper>

      {/* 스튜디오 전용 모달 */}
      {modalOpen && (
        <StudioScheduleModal
          open={modalOpen}
          onClose={() => {
            setModalOpen(false);
            setModalData(null);
          }}
          initialData={modalData}
          locations={studioLocations}
          userRole="admin"
          onSave={handleSave}
        />
      )}
    </>
  );
}
