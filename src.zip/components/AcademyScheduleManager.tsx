"use client";
import { useEffect, useState, useCallback } from "react";
import { supabase, checkSession } from "../utils/supabaseClient";
import { useWeek } from "../contexts/WeekContext";
import { UserRoleType } from "../types/users";
import { safeUserRole } from "../utils/permissions";
import BaseScheduleGrid from "./core/BaseScheduleGrid";
import RegistrationModal from "./modals/RegistrationModal";
import { AcademyAPI } from "../features/academy/api";

interface AcademyScheduleManagerProps {
  currentUserRole?: UserRoleType;
}

export default function AcademyScheduleManager({ currentUserRole }: AcademyScheduleManagerProps) {
  const [hasAccess, setHasAccess] = useState(false);
  const [accessLoading, setAccessLoading] = useState(true);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [userInfo, setUserInfo] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalData, setModalData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const { currentWeek, navigateWeek } = useWeek();

  const academyColors = {
    1: { bg: '#fef3c7', border: '#f59e0b', text: '#92400e' },
    2: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af' },
    3: { bg: '#dcfce7', border: '#22c55e', text: '#166534' },
    4: { bg: '#fce7f3', border: '#ec4899', text: '#be185d' },
    5: { bg: '#f3e8ff', border: '#8b5cf6', text: '#6b21a8' },
    6: { bg: '#fed7d7', border: '#ef4444', text: '#b91c1c' },
    7: { bg: '#e0f2fe', border: '#06b6d4', text: '#0e7490' },
    default: { bg: '#f8fafc', border: '#e2e8f0', text: '#1f2937' }
  };

  // 세션 및 권한 체크
  useEffect(() => {
    const checkSessionAndAccess = async () => {
      try {
        console.log('🔍 AcademyScheduleManager - 세션 및 권한 확인 시작');

        const session = await checkSession();
        if (!session) {
          console.warn('⚠️ 세션 없음 - 로그인 페이지로 이동');
          window.location.href = '/login';
          return;
        }

        console.log('✅ 세션 확인 완료:', session.user.email);

        let role = currentUserRole;
        
        if (!role) {
          const userRole = localStorage.getItem('userRole');
          role = userRole ? safeUserRole(userRole) : 'staff';
        }

        const allowedRoles: UserRoleType[] = [
          'system_admin', 
          'schedule_admin', 
          'academy_manager',
          'manager'
        ];
        
        const accessGranted = allowedRoles.includes(role);
        
        setHasAccess(accessGranted);

        if (!accessGranted) {
          alert('학원 스케줄 관리 권한이 없습니다.');
          window.location.href = '/';
        }
      } catch (error) {
        console.error('❌ 세션/권한 체크 오류:', error);
        window.location.href = '/login';
      } finally {
        setAccessLoading(false);
      }
    };

    checkSessionAndAccess();
  }, [currentUserRole]);

  // 데이터 로딩
  const loadData = useCallback(async () => {
    if (!hasAccess) return;

    try {
      setIsLoading(true);
      setError(null);

      try {
        const userData = await AcademyAPI.getUserInfo();
        setUserInfo(userData);
        console.log('✅ 사용자 정보 로딩 완료:', userData);
      } catch (userError) {
        console.warn('⚠️ 사용자 정보 조회 실패, 기본값 사용:', userError);
        const savedRole = localStorage.getItem('userRole') || 'academy_manager';
        const savedEmail = localStorage.getItem('userEmail') || 'unknown@example.com';
        
        setUserInfo({
          id: 0,
          name: '사용자',
          email: savedEmail,
          role: savedRole,
          academies: []
        });
      }

      const locationsData = await AcademyAPI.fetchLocations([]);
      setLocations(locationsData);
      console.log('✅ 위치 정보 로딩 완료:', locationsData.length);

      const startDate = new Date(currentWeek);
      const endDate = new Date(currentWeek);
      endDate.setDate(startDate.getDate() + 6);

      const startDateStr = startDate.toISOString().split('T')[0];
      const endDateStr = endDate.toISOString().split('T')[0];

      const schedulesData = await AcademyAPI.fetchSchedules(startDateStr, endDateStr, []);
      setSchedules(schedulesData);
      console.log('✅ 스케줄 정보 로딩 완료:', schedulesData.length);

    } catch (error) {
      console.error('❌ 데이터 로딩 오류:', error);
      setError(error instanceof Error ? error.message : '데이터 로딩 실패');
    } finally {
      setIsLoading(false);
    }
  }, [hasAccess, currentWeek]);

  useEffect(() => {
    if (hasAccess) {
      loadData();
    }
  }, [hasAccess, loadData]);

  useEffect(() => {
    if (!hasAccess) return;
    
    const subscription = supabase
      .channel('academy_schedule_changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'schedules',
          filter: 'schedule_type=eq.academy'
        }, 
        (payload) => {
          console.log('📡 학원 스케줄 변경 감지:', payload);
          if (!modalOpen) {
            loadData();
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [hasAccess, loadData, modalOpen]);

  const handleCellClick = (date: string, location: any) => {
    if (!hasAccess) return;
    
    console.log('📝 학원 셀 클릭:', { date, locationId: location.id });
    setModalData({
      date,
      locationId: location.id
    });
    setModalOpen(true);
  };

  const getScheduleForCell = (date: string, location: any) => {
    return schedules.filter(s => s.shoot_date === date && s.sub_location_id === location.id);
  };

  const getLocationColor = (locationId: number) => {
    const location = locations.find(loc => loc.id === locationId);
    const academyId = location?.main_locations?.id;
    
    return academyColors[academyId as keyof typeof academyColors] || academyColors.default;
  };

  const renderScheduleCard = (schedule: any) => {
    const statusInfo = getStatusInfo(schedule.approval_status);
    const locationColor = getLocationColor(schedule.sub_location_id);
    
    return (
      <div 
        key={schedule.id}
        onClick={(e) => {
          e.stopPropagation();
          console.log('📝 스케줄 카드 클릭:', schedule);
          setModalData({
            date: schedule.shoot_date,
            locationId: schedule.sub_location_id,
            scheduleData: schedule
          });
          setModalOpen(true);
        }}
        style={{ 
          padding: '8px',
          background: locationColor.bg,
          borderRadius: '6px',
          border: `2px solid ${locationColor.border}`,
          cursor: 'pointer',
          marginBottom: '4px',
          position: 'relative'
        }}
      >
        <div style={{ 
          fontWeight: '700', 
          color: locationColor.text,
          fontSize: '12px',
          marginBottom: '4px'
        }}>
          {schedule.start_time?.substring(0, 5)}~{schedule.end_time?.substring(0, 5)}
        </div>
        
        <div style={{ 
          fontSize: '10px', 
          marginBottom: '4px', 
          color: locationColor.text,
          fontWeight: '600',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }}>
          {schedule.professor_name}
        </div>
        
        <div style={{ 
          fontSize: '9px', 
          color: locationColor.text,
          fontWeight: '400',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          marginBottom: '4px'
        }}>
          {schedule.course_name}
        </div>
        
        <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
          <span style={{
            fontSize: 7, 
            padding: '1px 3px', 
            borderRadius: 2,
            background: statusInfo.bg, 
            color: statusInfo.color,
            fontWeight: 600
          }}>
            {statusInfo.text}
          </span>
        </div>
      </div>
    );
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'approved':
        return { bg: '#22c55e', color: '#ffffff', text: '승인완료' };
      case 'pending':
        return { bg: '#f59e0b', color: '#ffffff', text: '승인대기' };
      case 'temp':
        return { bg: '#6b7280', color: '#ffffff', text: '임시저장' };
      case 'cancelled':
        return { bg: '#dc2626', color: '#ffffff', text: '취소' };
      default:
        return { bg: '#6b7280', color: '#ffffff', text: '기타' };
    }
  };

  const handleSave = async (data: any, action: string) => {
    try {
      await AcademyAPI.saveSchedule(data, action);
      alert('저장되었습니다.');
      setModalOpen(false);
      loadData();
      return { success: true, message: '저장되었습니다.' };
    } catch (error) {
      console.error('저장 오류:', error);
      const message = error instanceof Error ? error.message : '저장 실패';
      alert(message);
      return { success: false, message };
    }
  };

  if (accessLoading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '4px solid #3b82f6',
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }} />
        <p>세션 및 권한을 확인하는 중...</p>
        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div style={{ 
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        padding: '40px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <h3 style={{ color: '#dc2626', marginBottom: '16px' }}>
            접근 권한이 없습니다
          </h3>
          <p>학원 스케줄 관리는 관리자 및 학원 매니저만 접근할 수 있습니다.</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh'
      }}>
        🏫 학원 데이터를 불러오는 중...
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ 
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        padding: '40px'
      }}>
        <div style={{ 
          textAlign: 'center',
          backgroundColor: '#fef2f2',
          border: '1px solid #fecaca',
          borderRadius: '8px',
          padding: '32px',
          maxWidth: '500px'
        }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚠️</div>
          <h3 style={{ color: '#dc2626', marginBottom: '16px', fontSize: '18px' }}>
            데이터 로딩 오류
          </h3>
          <p style={{ marginBottom: '24px', color: '#6b7280', lineHeight: '1.5' }}>
            {error}
          </p>
          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
            <button 
              onClick={() => window.location.reload()}
              style={{
                padding: '10px 20px',
                backgroundColor: '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontWeight: '500'
              }}
            >
              페이지 새로고침
            </button>
            <button 
              onClick={() => window.location.href = '/login'}
              style={{
                padding: '10px 20px',
                backgroundColor: '#6b7280',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontWeight: '500'
              }}
            >
              다시 로그인
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    // 🔥 하단 여백 제거를 위한 컨테이너 스타일 수정
    <div style={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      padding: '0',
      margin: '0'
    }}>
      <BaseScheduleGrid
        title="🏫 학원 스케줄 관리"
        leftColumnTitle="강의실"
        locations={locations.map(loc => ({
          id: loc.id,
          name: `${loc.main_locations?.name}\n${loc.name}`,
        }))}
        schedules={schedules}
        currentWeek={currentWeek}
        onWeekChange={navigateWeek}
        onCellClick={handleCellClick}
        getScheduleForCell={getScheduleForCell}
        renderScheduleCard={renderScheduleCard}
        showAddButton={true}
        onCopyPreviousWeek={undefined}
        userRole={userInfo?.role === 'system_admin' ? 'admin' : 'manager'}
        pageType="academy"
        getLocationColor={getLocationColor}
      />

      {modalOpen && (
        <RegistrationModal
          open={modalOpen}
          onClose={() => {
            console.log('📝 학원 모달 닫기');
            setModalOpen(false);
            setModalData(null);
          }}
          initialData={modalData}
          locations={locations.map(loc => ({
            value: loc.id,
            label: `${loc.main_locations?.name} - ${loc.name}`,
            disabled: false
          }))}
          shootingTypes={['촬영', '라이브', '녹화', '화상강의']}
          userRole={userInfo?.role === 'system_admin' ? 'admin' : 'manager'}
          pageType="academy"
          onSave={handleSave}
        />
      )}
    </div>
  );
}
