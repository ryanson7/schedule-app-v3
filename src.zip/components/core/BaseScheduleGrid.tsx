"use client";
import { ReactNode, useRef, useEffect } from "react";

interface BaseScheduleGridProps {
  title?: string;
  leftColumnTitle?: string;
  locations?: Array<{ id: number; name: string }>;
  schedules?: any[];
  currentWeek?: Date;
  onWeekChange?: (direction: number) => void;
  onCellClick?: (date: string, location: any) => void;
  getScheduleForCell?: (date: string, location: any) => any[];
  renderScheduleCard?: (schedule: any) => ReactNode;
  showAddButton?: boolean;
  onCopyPreviousWeek?: () => void;
  userRole?: 'admin' | 'manager' | 'user';
  pageType?: 'academy' | 'studio' | 'internal' | 'integrated';
  getLocationColor?: (locationId: number) => { bg: string; border: string; text: string };
}

export default function BaseScheduleGrid({
  title,
  leftColumnTitle,
  locations,
  schedules,
  currentWeek,
  onWeekChange,
  onCellClick,
  getScheduleForCell,
  renderScheduleCard,
  showAddButton = false,
  onCopyPreviousWeek,
  userRole = 'user',
  pageType,
  getLocationColor
}: BaseScheduleGridProps) {
  
  // 기본값 복구 시스템
  const safeTitle = title || "스케줄 관리";
  const safeLeftColumnTitle = leftColumnTitle || "위치";
  const safeLocations = locations || [];
  const safeSchedules = schedules || [];
  const safeCurrentWeek = currentWeek || new Date();
  const safePageType = pageType || 'integrated';
  
  const safeOnWeekChange = onWeekChange || (() => {
    console.warn('onWeekChange not provided - using default handler');
  });
  
  const safeOnCellClick = onCellClick || (() => {
    console.warn('onCellClick not provided - using default handler');
  });
  
  const safeGetScheduleForCell = getScheduleForCell || ((date: string, location: any) => {
    return safeSchedules.filter(s => 
      s.shoot_date === date && s.sub_location_id === location.id
    );
  });
  
  // 기본 카드 렌더러
  const defaultCardRenderer = (schedule: any) => {
    return (
      <div 
        key={schedule.id}
        className="default-schedule-card"
      >
        <div className="card-time">
          {schedule.start_time?.substring(0, 5) || '00:00'}~{schedule.end_time?.substring(0, 5) || '00:00'}
        </div>
        <div className="card-content">
          {schedule.professor_name || schedule.task_name || '제목 없음'}
        </div>
        <div className="card-sub">
          {schedule.course_name || schedule.department || '내용 없음'}
        </div>
      </div>
    );
  };
  
  const safeRenderScheduleCard = renderScheduleCard || defaultCardRenderer;
  
  // 휴일 체크 함수
  const isHoliday = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const dayOfWeek = date.getDay();
      return dayOfWeek === 0 || dayOfWeek === 6;
    } catch {
      return false;
    }
  };

  // 주간 날짜 생성
  const generateWeekDates = () => {
    const startOfWeek = new Date(safeCurrentWeek);
    const dayOfWeek = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    startOfWeek.setDate(diff);
    
    const dates = [];
    const dayNames = ['월', '화', '수', '목', '금', '토', '일'];
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);
      const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
      
      const isWeekend = isHoliday(dateStr);
      const isToday = dateStr === new Date().toISOString().split('T')[0];
      
      dates.push({
        date: dateStr,
        day: date.getDate(),
        dayName: dayNames[i],
        isWeekend,
        isToday
      });
    }
    return dates;
  };

  const weekDates = generateWeekDates();
  const canManage = userRole === 'admin' || userRole === 'manager';
  
  // 날짜 범위 포맷
  const formatDateRange = () => {
    if (weekDates.length < 7) return "날짜 로딩 중...";
    
    const start = weekDates[0];
    const end = weekDates[6];
    const startFormatted = `${start.date.slice(2, 4)}.${start.date.slice(5, 7)}.${start.date.slice(8, 10)}`;
    const endFormatted = `${end.date.slice(2, 4)}.${end.date.slice(5, 7)}.${end.date.slice(8, 10)}`;
    return `${startFormatted} ~ ${endFormatted}`;
  };

  // 페이지 타입별 브랜드 색상
  const getBrandColor = () => {
    switch(safePageType) {
      case 'academy': return '#2563eb';
      case 'studio': return '#059669';
      case 'internal': return '#7c3aed';
      case 'integrated': return '#d97706';
      default: return '#6b7280';
    }
  };

  const brandColor = getBrandColor();

  return (
    <div className="schedule-grid-container">
      {/* 헤더 */}
      <div className="schedule-header">
        <h2 className="schedule-title">{safeTitle}</h2>
        <div className="schedule-info">
          <span className="page-type" style={{ backgroundColor: brandColor }}>
            {safePageType.toUpperCase()}
          </span>
          <span className="schedule-count">{safeSchedules.length}개</span>
        </div>
      </div>

      {/* 툴바 */}
      <div className="schedule-toolbar">
        <div className="toolbar-spacer"></div>
        <div className="navigation-section">
          {canManage && onCopyPreviousWeek && (
            <button onClick={onCopyPreviousWeek} className="copy-button" style={{ backgroundColor: brandColor }}>
              지난 주 복사
            </button>
          )}
          <button onClick={() => safeOnWeekChange(-1)} className="nav-button">
            &lt; 이전 주
          </button>
          <div className="week-display">{formatDateRange()}</div>
          <button onClick={() => safeOnWeekChange(1)} className="nav-button">
            다음 주 &gt;
          </button>
        </div>
      </div>

      {/* 테이블 컨테이너 */}
      <div className="scrollable-table-container">
        <table className="schedule-table">
          {/* 고정 헤더 */}
          <thead className="sticky-header">
            <tr className="table-header-row">
              <th className="location-header">
                <span className="header-title">{safeLeftColumnTitle}</span>
              </th>
              {weekDates.map((dateInfo) => (
                <th key={dateInfo.date} className="date-header">
                  <div className="date-header-content">
                    <div className={`date-day-format ${dateInfo.isWeekend ? 'weekend-text' : ''}`}>
                      {dateInfo.day} ({dateInfo.dayName})
                    </div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          
          {/* 스크롤 가능한 바디 */}
          <tbody>
            {safeLocations.length === 0 ? (
              <tr className="schedule-row">
                <td className="location-cell">
                  <div className="location-name">데이터 없음</div>
                </td>
                {weekDates.map((dateInfo) => (
                  <td key={`empty-${dateInfo.date}`} className="schedule-cell empty-data">
                    <div className="cell-wrapper">
                      <div className="empty-message">위치 정보 없음</div>
                    </div>
                  </td>
                ))}
              </tr>
            ) : (
              safeLocations.map((location) => {
                const locationColor = getLocationColor ? getLocationColor(location.id) : null;
                
                return (
                  <tr key={location.id} className="schedule-row">
                    <td 
                      className="location-cell"
                      style={locationColor ? {
                        backgroundColor: locationColor.bg,
                        borderLeft: `4px solid ${locationColor.border}`,
                        color: locationColor.text
                      } : {}}
                    >
                      <div className="location-name">{location.name || '이름 없음'}</div>
                    </td>
                    {weekDates.map((dateInfo) => {
                      const cellSchedules = safeGetScheduleForCell(dateInfo.date, location);
                      const hasSchedules = cellSchedules.length > 0;
                      
                      return (
                        <td 
                          key={`${location.id}-${dateInfo.date}`}
                          className={`schedule-cell ${hasSchedules ? 'has-schedules' : 'empty-cell'}`}
                          onClick={() => canManage && showAddButton && safeOnCellClick(dateInfo.date, location)}
                        >
                          {/* 🔥 유연한 셀 래퍼 */}
                          <div className="cell-wrapper">
                            {/* 🔥 스케줄 카드 리스트 */}
                            <div className="schedule-list">
                              {cellSchedules.map((schedule) => 
                                safeRenderScheduleCard(schedule)
                              )}
                            </div>
                            
                            {/* 🔥 유연한 등록 버튼 */}
                            {canManage && showAddButton && (
                              <button 
                                className="add-schedule-btn"
                                style={{ borderColor: brandColor + '60', color: brandColor }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  safeOnCellClick(dateInfo.date, location);
                                }}
                              >
                                <span className="add-icon">+</span>
                                <span className="add-text">스케줄 등록</span>
                              </button>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <style jsx>{`
        .schedule-grid-container {
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          overflow: hidden;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          height: 100%;
          display: flex;
          flex-direction: column;
        }

        /* 헤더 */
        .schedule-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 20px;
          background: #f8fafc;
          border-bottom: 1px solid #e5e7eb;
          flex-shrink: 0;
        }

        .schedule-title {
          margin: 0;
          font-size: 18px;
          font-weight: 700;
          color: #1f2937;
        }

        .schedule-info {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .page-type {
          color: white;
          padding: 2px 8px;
          border-radius: 12px;
          font-size: 10px;
          font-weight: 600;
        }

        .schedule-count {
          background: #f3f4f6;
          color: #6b7280;
          padding: 2px 6px;
          border-radius: 10px;
          font-size: 10px;
          font-weight: 500;
        }

        /* 툴바 */
        .schedule-toolbar {
          display: flex;
          justify-content: flex-end;
          padding: 10px 20px;
          background: #f9fafb;
          border-bottom: 1px solid #e5e7eb;
          flex-shrink: 0;
        }

        .toolbar-spacer {
          flex: 1;
        }

        .navigation-section {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .week-display {
          font-size: 14px;
          font-weight: 600;
          color: #1f2937;
          min-width: 120px;
          text-align: center;
        }

        .nav-button {
          padding: 6px 12px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          background: white;
          color: #374151;
          cursor: pointer;
          font-size: 12px;
          font-weight: 500;
          transition: all 0.2s ease;
        }

        .nav-button:hover {
          background: #f3f4f6;
          border-color: ${brandColor};
        }

        .copy-button {
          padding: 6px 12px;
          border: none;
          border-radius: 4px;
          color: white;
          cursor: pointer;
          font-size: 12px;
          font-weight: 600;
          transition: all 0.2s ease;
        }

        .copy-button:hover {
          opacity: 0.9;
        }

        /* 세로 스크롤 컨테이너 */
        .scrollable-table-container {
          flex: 1;
          overflow-x: auto;
          overflow-y: auto;
          max-height: calc(100vh - 200px);
          background: white;
        }

        /* 스크롤바 커스터마이징 */
        .scrollable-table-container::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }

        .scrollable-table-container::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }

        .scrollable-table-container::-webkit-scrollbar-thumb {
          background: #c1c1c1;
          border-radius: 4px;
        }

        .scrollable-table-container::-webkit-scrollbar-thumb:hover {
          background: #a8a8a8;
        }

        .scrollable-table-container::-webkit-scrollbar-corner {
          background: #f1f1f1;
        }

        /* 테이블 */
        .schedule-table {
          width: 100%;
          min-width: 1000px;
          border-collapse: collapse;
          table-layout: fixed;
          display: table;
        }

        /* 고정 헤더 */
        .sticky-header {
          position: sticky;
          top: 0;
          z-index: 10;
          background: #f8fafc;
          display: table-header-group;
        }

        .table-header-row {
          background: #f8fafc;
          border-bottom: 2px solid #e5e7eb;
          display: table-row;
        }

        /* 헤더 셀 */
        .location-header {
          width: 160px;
          min-width: 160px;
          max-width: 160px;
          padding: 12px;
          border-right: 2px solid #e5e7eb;
          text-align: center;
          background: #f8fafc;
          white-space: nowrap;
          display: table-cell;
        }

        .header-title {
          font-size: 13px;
          font-weight: 700;
          color: #1f2937;
        }

        .date-header {
          width: 120px;
          min-width: 120px;
          max-width: 120px;
          padding: 12px 8px;
          border-right: 1px solid #e5e7eb;
          text-align: center;
          background: #f8fafc;
          white-space: nowrap;
          display: table-cell;
        }

        .date-header-content {
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .date-day-format {
          font-size: 13px;
          font-weight: 600;
          color: #1f2937;
        }

        .date-day-format.weekend-text {
          color: #dc2626;
        }

        /* 바디 */
        tbody {
          display: table-row-group;
        }

        .schedule-row {
          display: table-row;
        }

        .schedule-row:hover {
          background: #f9fafb;
        }

        /* 위치 셀 */
        .location-cell {
          width: 160px;
          min-width: 160px;
          max-width: 160px;
          padding: 10px 12px;
          border-right: 2px solid #e5e7eb;
          border-bottom: 1px solid #e5e7eb;
          background: #f8fafc;
          vertical-align: top;
          white-space: nowrap;
          display: table-cell;
        }

        .location-name {
          font-size: 12px;
          font-weight: 600;
          color: inherit;
          line-height: 1.3;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* 🔥 스케줄 셀 - 유연한 레이아웃 */
        .schedule-cell {
          width: 120px;
          min-width: 120px;
          max-width: 120px;
          padding: 0;
          border-right: 1px solid #e5e7eb;
          border-bottom: 1px solid #e5e7eb;
          vertical-align: top;
          background: white;
          display: table-cell;
          height: 100px;
        }

        /* 🔥 유연한 셀 래퍼 */
        .cell-wrapper {
          display: flex;
          flex-direction: column;
          height: 100%;
          min-height: 100px;
          padding: 6px;
          position: relative;
        }

        /* 🔥 빈 셀일 때 중앙 정렬 */
        .schedule-cell.empty-cell .cell-wrapper {
          justify-content: center;
          align-items: center;
        }

        .schedule-cell.empty-data .cell-wrapper {
          justify-content: center;
          align-items: center;
        }

        /* 🔥 스케줄 리스트 영역 */
        .schedule-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
          flex: 1 1 auto;
          overflow-y: auto;
          max-height: calc(100% - 36px);
        }

        /* 빈 스케줄 리스트일 때 공간 차지하지 않음 */
        .schedule-cell.empty-cell .schedule-list {
          flex: 0 0 auto;
          height: 0;
        }

        /* 기본 카드 스타일 */
        .default-schedule-card {
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 4px;
          padding: 6px;
          font-size: 11px;
          transition: all 0.2s ease;
          cursor: pointer;
          flex-shrink: 0;
        }

        .default-schedule-card:hover {
          border-color: ${brandColor};
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .card-time {
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 3px;
          font-size: 12px;
        }

        .card-content {
          color: #374151;
          margin-bottom: 2px;
          font-size: 10px;
          font-weight: 500;
        }

        .card-sub {
          color: #6b7280;
          font-size: 9px;
        }

         /* 🔥 유연한 셀 래퍼 - 개선된 레이아웃 */
        .cell-wrapper {
          display: flex;
          flex-direction: column;
          height: 100%;
          min-height: 100px;
          padding: 6px;
          position: relative;
        }

        /* 🔥 빈 셀일 때 완전한 중앙 정렬 */
        .schedule-cell.empty-cell .cell-wrapper {
          justify-content: center;
          align-items: center;
        }

        .schedule-cell.empty-data .cell-wrapper {
          justify-content: center;
          align-items: center;
        }

        /* 🔥 스케줄이 있는 셀일 때 상단 정렬 */
        .schedule-cell.has-schedules .cell-wrapper {
          justify-content: flex-start;
          align-items: stretch;
        }

        /* 🔥 스케줄 리스트 영역 */
        .schedule-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
          flex: 1 1 auto;
          overflow-y: auto;
          max-height: calc(100% - 36px);
        }

        /* 빈 스케줄 리스트일 때 공간 차지하지 않음 */
        .schedule-cell.empty-cell .schedule-list {
          display: none;  /* 🔥 완전히 숨김 */
        }

        /* 🔥 유연한 등록 버튼 - 개선된 정렬 */
        .add-schedule-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          width: 100%;
          min-height: 32px;
          max-height: 36px;
          background: rgba(248, 250, 252, 0.8);
          border: 1px dashed #d1d5db;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          flex-shrink: 0;
          overflow: hidden;
        }

        /* 🔥 스케줄이 있을 때 버튼 위치 - 하단에 고정 */
        .schedule-cell.has-schedules .add-schedule-btn {
          margin-top: 6px;
          align-self: stretch;
        }

        /* 🔥 빈 셀일 때 버튼 스타일 - 완전한 중앙 정렬 */
        .schedule-cell.empty-cell .add-schedule-btn {
          width: 90%;
          max-width: 90%;
          align-self: center;
          margin: 0;  /* 🔥 margin 제거로 중앙 정렬 */
        }

        .add-schedule-btn:hover {
          background: rgba(248, 250, 252, 1);
          border-style: solid;
          transform: translateY(-1px);
        }

        .add-icon {
          font-size: 14px;
          font-weight: 300;
          line-height: 1;
        }

        .add-text {
          font-size: 11px;
          font-weight: 500;
          line-height: 1;
        }

        /* 🔥 빈 상태 메시지 - 중앙 정렬 개선 */
        .empty-message {
          color: #9ca3af;
          font-size: 11px;
          font-style: italic;
          text-align: center;
          margin: 0;
          padding: 0;
        }

        /* 반응형에서도 중앙 정렬 유지 */
        @media (max-width: 768px) {
          .schedule-header {
            padding: 10px 16px;
          }

          .schedule-toolbar {
            padding: 8px 16px;
          }

          .navigation-section {
            gap: 8px;
          }

          .schedule-table {
            min-width: 800px;
          }

          .location-header, .location-cell {
            width: 140px;
            min-width: 140px;
            max-width: 140px;
          }

          .schedule-cell {
            width: 100px;
            min-width: 100px;
            max-width: 100px;
          }

          .add-text {
            display: none;
          }

          .add-schedule-btn {
            min-height: 28px;
            max-height: 32px;
          }

          /* 🔥 모바일에서도 중앙 정렬 유지 */
          .schedule-cell.empty-cell .add-schedule-btn {
            width: 85%;
            max-width: 85%;
          }

          .scrollable-table-container {
            max-height: calc(100vh - 160px);
          }
        }
      `}</style>
    </div>
  );
}
