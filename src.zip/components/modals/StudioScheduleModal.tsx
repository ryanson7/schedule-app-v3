"use client";
import { useState, useEffect } from "react";
import { supabase } from "../../utils/supabaseClient";
import { ScheduleFormData, Location } from "../../types/academy";
import BaseScheduleModal from "./BaseScheduleModal";

interface StudioScheduleModalProps {
  open: boolean;
  onClose: () => void;
  initialData?: {
    date: string;
    locationId: number;
    scheduleData?: ScheduleFormData;
  };
  locations: Location[];
  userRole: 'admin' | 'manager' | 'user';
  onSave: (data: ScheduleFormData, action: 'temp' | 'request' | 'approve') => Promise<{ success: boolean; message: string }>;
}

export default function StudioScheduleModal({
  open,
  onClose,
  initialData,
  locations,
  userRole,
  onSave
}: StudioScheduleModalProps) {
  const [formData, setFormData] = useState<ScheduleFormData>({
    shoot_date: '',
    start_time: '',
    end_time: '',
    professor_name: '',
    course_name: '',
    course_code: '',
    shooting_type: '',
    notes: '',
    sub_location_id: 0
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  
  // 촬영형식 및 스튜디오 연동 상태
  const [allShootingTypes, setAllShootingTypes] = useState<any[]>([]);
  const [availableShootingTypes, setAvailableShootingTypes] = useState<any[]>([]);
  const [compatibleStudios, setCompatibleStudios] = useState<any[]>([]);
  const [studioShootingMap, setStudioShootingMap] = useState<Map<number, any[]>>(new Map());

  // 스튜디오 시간 옵션 생성 (09:00~22:00, 30분 단위)
  const generateStudioTimeOptions = () => {
    const times = [];
    for (let hour = 9; hour < 22; hour++) {
      for (let min = 0; min < 60; min += 30) {
        const h = hour.toString().padStart(2, "0");
        const m = min.toString().padStart(2, "0");
        times.push(`${h}:${m}`);
      }
    }
    times.push('22:00');
    return times;
  };

  const timeOptions = generateStudioTimeOptions();

  // 모달 열릴 때 전체 촬영형식과 스튜디오-촬영형식 매핑 로딩
  useEffect(() => {
    if (open) {
      console.log('스튜디오 모달 열림 - 데이터 로딩 시작');
      loadAllShootingTypes();
      loadStudioShootingMapping();
    }
  }, [open]);

  // 스튜디오 선택 시 해당 스튜디오의 촬영형식 필터링
  useEffect(() => {
    if (formData.sub_location_id && studioShootingMap.size > 0) {
      const studioTypes = studioShootingMap.get(formData.sub_location_id) || [];
      console.log(`스튜디오 ${formData.sub_location_id} 촬영형식:`, studioTypes);
      setAvailableShootingTypes(studioTypes);
      
      // 현재 선택된 촬영형식이 호환되지 않으면 초기화
      if (formData.shooting_type && !studioTypes.some(type => type.name === formData.shooting_type)) {
        const primaryType = studioTypes.find(type => type.is_primary);
        const defaultType = primaryType || studioTypes[0];
        console.log('호환되지 않는 촬영형식 초기화:', defaultType?.name);
        setFormData(prev => ({ 
          ...prev, 
          shooting_type: defaultType ? defaultType.name : '' 
        }));
      }
    } else if (formData.sub_location_id === 0) {
      // 스튜디오 선택 해제 시 전체 촬영형식 표시
      setAvailableShootingTypes(allShootingTypes);
    }
  }, [formData.sub_location_id, studioShootingMap, allShootingTypes]);

  // 촬영형식 선택 시 호환 스튜디오 필터링
  useEffect(() => {
    if (formData.shooting_type) {
      loadCompatibleStudios(formData.shooting_type);
    } else {
      setCompatibleStudios([]);
    }
  }, [formData.shooting_type]);

  // 전체 촬영형식 로딩
  const loadAllShootingTypes = async () => {
    try {
      console.log('전체 촬영형식 로딩 시작');
      
      const { data, error } = await supabase
        .from('shooting_types')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;

      console.log('전체 촬영형식 로딩 완료:', data?.length || 0, '개');
      setAllShootingTypes(data || []);
      setAvailableShootingTypes(data || []);
      
    } catch (error) {
      console.error('전체 촬영형식 로딩 오류:', error);
    }
  };

  // 스튜디오별 촬영형식 매핑 로딩
  const loadStudioShootingMapping = async () => {
    try {
      console.log('스튜디오-촬영형식 매핑 로딩 시작');
      
      const { data, error } = await supabase
        .from('sub_location_shooting_types')
        .select(`
          sub_location_id,
          is_primary,
          shooting_types!inner(
            id,
            name,
            description,
            is_active
          )
        `)
        .eq('shooting_types.is_active', true);

      if (error) throw error;

      // 스튜디오별로 촬영형식 그룹핑
      const mappingMap = new Map<number, any[]>();
      
      data?.forEach(item => {
        const studioId = item.sub_location_id;
        const shootingType = {
          ...item.shooting_types,
          is_primary: item.is_primary
        };
        
        if (mappingMap.has(studioId)) {
          mappingMap.get(studioId)?.push(shootingType);
        } else {
          mappingMap.set(studioId, [shootingType]);
        }
      });

      console.log('스튜디오-촬영형식 매핑 완료:', mappingMap.size, '개 스튜디오');
      setStudioShootingMap(mappingMap);
      
    } catch (error) {
      console.error('스튜디오-촬영형식 매핑 로딩 오류:', error);
    }
  };

  // 촬영형식에 호환되는 스튜디오 로딩
  const loadCompatibleStudios = async (shootingTypeName: string) => {
    try {
      console.log('호환 스튜디오 로딩:', shootingTypeName);
      
      const { data, error } = await supabase
        .from('sub_location_shooting_types')
        .select(`
          sub_location_id,
          is_primary,
          shooting_types!inner(name)
        `)
        .eq('shooting_types.name', shootingTypeName)
        .eq('shooting_types.is_active', true);

      if (error) throw error;

      const compatibleStudioIds = data?.map(item => item.sub_location_id) || [];
      const filteredStudios = locations.filter(studio => 
        compatibleStudioIds.includes(studio.id)
      );

      console.log('호환 스튜디오 필터링 완료:', filteredStudios.length, '개');
      setCompatibleStudios(filteredStudios);

      // 현재 선택된 스튜디오가 호환되지 않으면 초기화
      if (formData.sub_location_id && !compatibleStudioIds.includes(formData.sub_location_id)) {
        console.log('현재 스튜디오가 호환되지 않음 - 초기화');
        setFormData(prev => ({ ...prev, sub_location_id: 0 }));
      }

    } catch (error) {
      console.error('호환 스튜디오 로딩 오류:', error);
      setCompatibleStudios([]);
    }
  };

  // 초기 데이터 설정
  useEffect(() => {
    if (open && initialData) {
      console.log('초기 데이터 설정:', initialData);
      setFormData(prev => ({
        ...prev,
        shoot_date: initialData.date || '',
        sub_location_id: initialData.locationId || 0,
        ...(initialData.scheduleData || {})
      }));
      setErrors({});
    }
  }, [open, initialData]);

  // 폼 리셋
  useEffect(() => {
    if (!open) {
      console.log('모달 닫힘 - 폼 리셋');
      setFormData({
        shoot_date: '',
        start_time: '',
        end_time: '',
        professor_name: '',
        course_name: '',
        course_code: '',
        shooting_type: '',
        notes: '',
        sub_location_id: 0
      });
      setErrors({});
      setAvailableShootingTypes([]);
      setCompatibleStudios([]);
      setStudioShootingMap(new Map());
    }
  }, [open]);

  const updateField = (field: keyof ScheduleFormData, value: any) => {
    const newValue = field === 'sub_location_id' ? parseInt(value) || 0 : String(value || '');
    
    console.log('필드 업데이트:', field, '=', newValue);
    
    setFormData(prev => ({
      ...prev,
      [field]: newValue
    }));

    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.shoot_date) {
      newErrors.shoot_date = '촬영 날짜를 선택하세요';
    }

    if (!formData.start_time) {
      newErrors.start_time = '시작 시간을 선택하세요';
    }

    if (!formData.end_time) {
      newErrors.end_time = '종료 시간을 선택하세요';
    }

    if (formData.start_time && formData.end_time && formData.start_time >= formData.end_time) {
      newErrors.end_time = '종료 시간은 시작 시간보다 늦어야 합니다';
    }

    if (!formData.professor_name.trim()) {
      newErrors.professor_name = '교수명을 입력하세요';
    }

    if (!formData.shooting_type) {
      newErrors.shooting_type = '촬영형식을 선택하세요';
    }

    if (!formData.sub_location_id || formData.sub_location_id === 0) {
      newErrors.sub_location_id = '스튜디오를 선택하세요';
    }

    // 촬영형식과 스튜디오 호환성 체크
    if (formData.shooting_type && formData.sub_location_id) {
      const studioTypes = studioShootingMap.get(formData.sub_location_id) || [];
      const isCompatible = studioTypes.some(type => type.name === formData.shooting_type);
      
      if (!isCompatible) {
        newErrors.sub_location_id = '선택한 촬영형식과 호환되지 않는 스튜디오입니다';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async (action: 'temp' | 'request' | 'approve') => {
    console.log('저장 시도:', action, formData);
    
    if (!validateForm()) {
      console.log('폼 검증 실패:', errors);
      return;
    }

    setLoading(true);
    try {
      const result = await onSave(formData, action);
      
      if (result.success) {
        alert(result.message);
        onClose();
      } else {
        alert(result.message);
      }
    } catch (error) {
      console.error('저장 오류:', error);
      alert('저장 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  // 표시할 스튜디오 목록 결정
  const getDisplayStudios = () => {
    if (formData.shooting_type && compatibleStudios.length > 0) {
      return compatibleStudios;
    }
    return locations;
  };

  const displayStudios = getDisplayStudios();

  return (
    <BaseScheduleModal
      open={open}
      onClose={onClose}
      title="스튜디오 스케줄 등록"
      titleColor="#8b5cf6"
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {/* 기본 정보 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
              촬영 날짜 *
            </label>
            <input
              type="date"
              value={formData.shoot_date}
              onChange={(e) => updateField('shoot_date', e.target.value)}
              style={{
                width: '100%',
                padding: '10px 12px',
                border: `1px solid ${errors.shoot_date ? '#ef4444' : '#d1d5db'}`,
                borderRadius: '6px',
                fontSize: '14px'
              }}
              required
            />
            {errors.shoot_date && (
              <span style={{ fontSize: '12px', color: '#ef4444', marginTop: '4px', display: 'block' }}>
                {errors.shoot_date}
              </span>
            )}
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
              촬영형식 *
            </label>
            <select
              value={formData.shooting_type}
              onChange={(e) => updateField('shooting_type', e.target.value)}
              style={{
                width: '100%',
                padding: '10px 12px',
                border: `1px solid ${errors.shooting_type ? '#ef4444' : '#d1d5db'}`,
                borderRadius: '6px',
                fontSize: '14px'
              }}
              required
            >
              <option value="">촬영형식을 선택하세요</option>
              {availableShootingTypes.map(type => (
                <option key={type.id} value={type.name}>
                  {type.name} {type.is_primary ? '(기본)' : ''}
                </option>
              ))}
            </select>
            {errors.shooting_type && (
              <span style={{ fontSize: '12px', color: '#ef4444', marginTop: '4px', display: 'block' }}>
                {errors.shooting_type}
              </span>
            )}
          </div>
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
            스튜디오 *
            {formData.shooting_type && (
              <span style={{ fontSize: '12px', color: '#6b7280', fontWeight: 'normal', marginLeft: '8px' }}>
                ({formData.shooting_type} 호환 스튜디오만 표시)
              </span>
            )}
          </label>
          <select
            value={formData.sub_location_id}
            onChange={(e) => updateField('sub_location_id', parseInt(e.target.value))}
            style={{
              width: '100%',
              padding: '10px 12px',
              border: `1px solid ${errors.sub_location_id ? '#ef4444' : '#d1d5db'}`,
              borderRadius: '6px',
              fontSize: '14px'
            }}
            required
          >
            <option value={0}>스튜디오를 선택하세요</option>
            {displayStudios.map(studio => (
              <option key={studio.id} value={studio.id}>
                {studio.name}번 스튜디오
              </option>
            ))}
          </select>
          {errors.sub_location_id && (
            <span style={{ fontSize: '12px', color: '#ef4444', marginTop: '4px', display: 'block' }}>
              {errors.sub_location_id}
            </span>
          )}
          {formData.shooting_type && displayStudios.length === 0 && (
            <span style={{ fontSize: '12px', color: '#f59e0b', marginTop: '4px', display: 'block' }}>
              선택한 촬영형식과 호환되는 스튜디오가 없습니다.
            </span>
          )}
          {formData.shooting_type && compatibleStudios.length > 0 && (
            <span style={{ fontSize: '12px', color: '#22c55e', marginTop: '4px', display: 'block' }}>
              {compatibleStudios.length}개의 호환 스튜디오가 있습니다.
            </span>
          )}
        </div>

        {/* 시간 정보 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
              시작 시간 * 
              <span style={{ fontSize: '12px', color: '#6b7280', fontWeight: 'normal' }}>
                (30분 단위)
              </span>
            </label>
            <select
              value={formData.start_time}
              onChange={(e) => updateField('start_time', e.target.value)}
              style={{
                width: '100%',
                padding: '10px 12px',
                border: `1px solid ${errors.start_time ? '#ef4444' : '#d1d5db'}`,
                borderRadius: '6px',
                fontSize: '14px'
              }}
              required
            >
              <option value="">시작 시간 선택</option>
              {timeOptions.map(time => (
                <option key={time} value={time}>{time}</option>
              ))}
            </select>
            {errors.start_time && (
              <span style={{ fontSize: '12px', color: '#ef4444', marginTop: '4px', display: 'block' }}>
                {errors.start_time}
              </span>
            )}
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
              종료 시간 *
            </label>
            <select
              value={formData.end_time}
              onChange={(e) => updateField('end_time', e.target.value)}
              style={{
                width: '100%',
                padding: '10px 12px',
                border: `1px solid ${errors.end_time ? '#ef4444' : '#d1d5db'}`,
                borderRadius: '6px',
                fontSize: '14px'
              }}
              required
            >
              <option value="">종료 시간 선택</option>
              {timeOptions.map(time => (
                <option key={time} value={time}>{time}</option>
              ))}
            </select>
            {errors.end_time && (
              <span style={{ fontSize: '12px', color: '#ef4444', marginTop: '4px', display: 'block' }}>
                {errors.end_time}
              </span>
            )}
          </div>
        </div>

        {/* 강의 정보 */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
              교수명 *
            </label>
            <input
              type="text"
              value={formData.professor_name}
              onChange={(e) => updateField('professor_name', e.target.value)}
              placeholder="교수명을 입력하세요"
              style={{
                width: '100%',
                padding: '10px 12px',
                border: `1px solid ${errors.professor_name ? '#ef4444' : '#d1d5db'}`,
                borderRadius: '6px',
                fontSize: '14px'
              }}
              required
            />
            {errors.professor_name && (
              <span style={{ fontSize: '12px', color: '#ef4444', marginTop: '4px', display: 'block' }}>
                {errors.professor_name}
              </span>
            )}
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
              강의명
            </label>
            <input
              type="text"
              value={formData.course_name}
              onChange={(e) => updateField('course_name', e.target.value)}
              placeholder="강의명을 입력하세요"
              style={{
                width: '100%',
                padding: '10px 12px',
                border: '1px solid #d1d5db',
                borderRadius: '6px',
                fontSize: '14px'
              }}
            />
          </div>
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
            강의코드
          </label>
          <input
            type="text"
            value={formData.course_code}
            onChange={(e) => updateField('course_code', e.target.value)}
            placeholder="강의코드를 입력하세요"
            style={{
              width: '100%',
              padding: '10px 12px',
              border: '1px solid #d1d5db',
              borderRadius: '6px',
              fontSize: '14px'
            }}
          />
        </div>

        {/* 비고 */}
        <div>
          <label style={{ display: 'block', marginBottom: '6px', fontWeight: '500', color: '#374151' }}>
            비고
          </label>
          <textarea
            value={formData.notes}
            onChange={(e) => updateField('notes', e.target.value)}
            placeholder="추가 정보나 특이사항을 입력하세요"
            rows={3}
            style={{
              width: '100%',
              padding: '10px 12px',
              border: '1px solid #d1d5db',
              borderRadius: '6px',
              fontSize: '14px',
              resize: 'vertical'
            }}
          />
        </div>

        {/* 버튼 영역 */}
        <div style={{
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '12px',
          marginTop: '24px',
          paddingTop: '16px',
          borderTop: '1px solid #e5e7eb'
        }}>
          <button
            onClick={onClose}
            disabled={loading}
            style={{
              padding: '10px 20px',
              border: '1px solid #d1d5db',
              borderRadius: '6px',
              backgroundColor: 'white',
              color: '#374151',
              cursor: loading ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500'
            }}
          >
            취소
          </button>
          
          <button
            onClick={() => handleSave('temp')}
            disabled={loading}
            style={{
              padding: '10px 20px',
              border: '1px solid #6b7280',
              borderRadius: '6px',
              backgroundColor: '#6b7280',
              color: 'white',
              cursor: loading ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500'
            }}
          >
            임시저장
          </button>
          
          {userRole === 'admin' ? (
            <button
              onClick={() => handleSave('approve')}
              disabled={loading}
              style={{
                padding: '10px 20px',
                border: '1px solid #22c55e',
                borderRadius: '6px',
                backgroundColor: '#22c55e',
                color: 'white',
                cursor: loading ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
              승인 완료
            </button>
          ) : (
            <button
              onClick={() => handleSave('request')}
              disabled={loading}
              style={{
                padding: '10px 20px',
                border: '1px solid #8b5cf6',
                borderRadius: '6px',
                backgroundColor: '#8b5cf6',
                color: 'white',
                cursor: loading ? 'not-allowed' : 'pointer',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
              등록 요청
            </button>
          )}
        </div>
      </div>
    </BaseScheduleModal>
  );
}
