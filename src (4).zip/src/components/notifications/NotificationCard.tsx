// ?�림 카드 컴포?�트 
export default function NotificationCard() {} 
