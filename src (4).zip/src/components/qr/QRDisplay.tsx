// QR 코드 ?�시 
export default function QRDisplay() {} 
