export const config = { runtime: 'edge' };

 
