// 자동 생성된 메뉴 파일 (수정하지 마세요!)
// 페이지 파일의 @menu-* 주석에서 자동 생성됨
// 생성 시간: 2025. 12. 15. 오후 12:51:59

export const AUTO_GENERATED_MENUS = [
  {
    "id": "-admin-menu-manager",
    "path": "/admin/menu-manager",
    "name": "페이지 이름",
    "icon": "ICON_NAME",
    "category": "카테고리",
    "defaultRoles": [
      "shooter",
      "admin"
    ]
  }
];
