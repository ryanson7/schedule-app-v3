"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "../utils/supabaseClient";
import { ProfessorAutocomplete } from '../ProfessorAutocomplete';
import { sendAdminResponseNotification } from "../utils/notifications";
import BaseScheduleGrid from "./core/BaseScheduleGrid";
import AcademyScheduleModal from "./modals/AcademyScheduleModal";
import { useWeek } from "../contexts/WeekContext";
import { UnifiedScheduleCard } from "./cards/UnifiedScheduleCard";
import { ScheduleCardErrorBoundary } from "./ErrorBoundary";

// 🔥 기존 학원별 색상 정의 완전 유지
const academyColors = {
  1: { bg: '#fef3c7', border: '#f59e0b', text: '#92400e' },
  2: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af' },
  3: { bg: '#dcfce7', border: '#22c55e', text: '#166534' },
  4: { bg: '#fce7f3', border: '#ec4899', text: '#be185d' },
  5: { bg: '#f3e8ff', border: '#8b5cf6', text: '#6b21a8' },
  6: { bg: '#fed7d7', border: '#ef4444', text: '#b91c1c' },
  7: { bg: '#e0f2fe', border: '#06b6d4', text: '#0e7490' },
  9: { bg: '#ccfbf1', border: '#14b8a6', text: '#115e59' },
};

export default function AcademyScheduleManager() {
  const { currentWeek, navigateWeek } = useWeek();
  
  const [schedules, setSchedules] = useState<any[]>([]);
  const [academyLocations, setAcademyLocations] = useState<any[]>([]);
  const [mainLocations, setMainLocations] = useState<any[]>([]);
  const [shooters, setShooters] = useState<any[]>([]);
  const [selectedSchedules, setSelectedSchedules] = useState<number[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [modalOpen, setModalOpen] = useState(false);
  const [modalData, setModalData] = useState<any>(null);

  const [isCopying, setIsCopying] = useState(false);
  const [copyModalOpen, setCopyModalOpen] = useState(false);
  const [lastWeekSchedules, setLastWeekSchedules] = useState<any[]>([]);
  const [selectedCopySchedules, setSelectedCopySchedules] = useState<number[]>([]);

  const [filters, setFilters] = useState({
    mainLocationId: 'all',
    shootingType: 'all',
    status: 'all'
  });

  const isProcessingRef = useRef(false);
  const [userRole, setUserRole] = useState<'admin' | 'manager' | 'user'>('user');

  // 🔥 역할 초기화
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const role = localStorage.getItem('userRole') || '';
      const name = localStorage.getItem('userName') || '';

      let normalizedRole: 'admin' | 'manager' | 'user' = 'user';
      
      if (name === 'manager1' || role === 'system_admin' || role === 'schedule_admin') {
        normalizedRole = 'admin';
      } else if (role === 'academy_manager' || role === 'manager' || role === 'studio_manager') {
        normalizedRole = 'manager';
      }
      
      setUserRole(normalizedRole);
      console.log('🔍 역할 설정:', { role, name, normalizedRole });
    }
  }, []);

  // 🔥 날짜 생성 함수
  const generateWeekDates = useCallback(() => {
    try {
      const startOfWeek = new Date(currentWeek);
      
      if (isNaN(startOfWeek.getTime())) {
        console.error('❌ Invalid currentWeek:', currentWeek);
        return [];
      }

      const dayOfWeek = startOfWeek.getDay();
      const diff = startOfWeek.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
      startOfWeek.setDate(diff);

      return Array.from({ length: 7 }, (_, i) => {
        const date = new Date(startOfWeek);
        date.setDate(startOfWeek.getDate() + i);
        
        const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        
        return {
          id: dateStr,
          date: dateStr,
          day: date.getDate()
        };
      });
    } catch (error) {
      console.error('날짜 생성 오류:', error);
      return [];
    }
  }, [currentWeek]);

  // 🔥 접근 가능한 학원 조회
  const getUserAccessibleAcademies = useCallback(() => {
    const userName = localStorage.getItem('userName') || '';
    const userRole = localStorage.getItem('userRole') || '';
    
    if (process.env.NODE_ENV === 'development' && userRole !== 'academy_manager') {
      return mainLocations;
    }
    
    if (userName === 'manager1' || userRole === 'manager1' || userRole === 'system_admin' || userRole === 'schedule_admin') {
      return mainLocations;
    } else if (userRole === 'academy_manager') {
      const assignedAcademyIds = JSON.parse(localStorage.getItem('assignedAcademyIds') || '[]');
      const accessibleAcademies = mainLocations.filter(academy => assignedAcademyIds.includes(academy.id));
      return accessibleAcademies;
    }
    
    return [];
  }, [mainLocations]);

  const isManagerMode = () => {
    const userRole = localStorage.getItem('userRole') || '';
    return userRole === 'academy_manager';
  };

  // 🔥 fetchSchedules를 useCallback으로 감싸기 (중요!)
const fetchSchedules = useCallback(async (
  locationsOverride?: any[], 
  mainLocationsOverride?: any[]
) => {
  try {
    let weekDates = generateWeekDates();

    if (!Array.isArray(weekDates) || weekDates.length === 0) {
      console.error('❌ weekDates 유효성 검증 실패:', weekDates);
      setSchedules([]);
      return;
    }

    if (Array.isArray(weekDates[0])) {
      weekDates = weekDates[0] as any[];
    }

    if (weekDates.length < 7) {
      console.error('❌ 최종 길이 부족:', weekDates.length);
      setSchedules([]);
      return;
    }

    const firstDateObj = weekDates[0];
    const lastDateObj = weekDates[weekDates.length - 1];

    if (!firstDateObj?.date || !lastDateObj?.date) {
      console.error('❌ 날짜 객체 유효성 검증 실패:', { firstDateObj, lastDateObj });
      setSchedules([]);
      return;
    }

    const startDate = firstDateObj.date;
    const endDate = lastDateObj.date;

    console.log('✅ 유효한 날짜 범위:', { startDate, endDate });

    const locationsToUse = locationsOverride || academyLocations;
    const mainLocationsToUse = mainLocationsOverride || mainLocations;

    console.log('🔍 [학원] 사용할 locations:', {
      locationsCount: locationsToUse.length,
      mainLocationsCount: mainLocationsToUse.length
    });

    const userName = localStorage.getItem('userName') || '';
    const userRole = localStorage.getItem('userRole') || '';
    
    let accessibleAcademies = mainLocationsToUse;
    
    if (userRole === 'academy_manager') {
      const assignedAcademyIds = JSON.parse(localStorage.getItem('assignedAcademyIds') || '[]');
      accessibleAcademies = mainLocationsToUse.filter(academy => assignedAcademyIds.includes(academy.id));
    }
    
    const accessibleAcademyIds = accessibleAcademies.map(academy => Number(academy.id));
    
    const accessibleLocationIds = locationsToUse
      .filter(location => accessibleAcademyIds.includes(Number(location.main_location_id)))
      .map(location => location.id);

    console.log('🔍 [학원] 접근 가능한 강의실:', {
      accessibleAcademyIds,
      accessibleLocationIds: accessibleLocationIds.length
    });

    if (accessibleLocationIds.length === 0) {
      console.log('⚠️ 접근 가능한 강의실 없음');
      setSchedules([]);
      return;
    }

    const { data, error } = await supabase
      .from('schedules')
      .select(`
        *, 
        sub_locations!inner(
          id,
          name,
          main_location_id, 
          main_locations!inner(
            id,
            name,
            location_type
          )
        )
      `)
      .eq('schedule_type', 'academy')
      .in('approval_status', [
        'pending', 'approval_requested', 'approved', 'confirmed', 
        'modification_requested', 'modification_approved',
        'cancellation_requested', 'deletion_requested', 'cancelled'
      ])
      .in('sub_location_id', accessibleLocationIds)
      .gte('shoot_date', startDate)
      .lte('shoot_date', endDate)
      .order('shoot_date')
      .order('start_time');

    if (error) {
      console.error('🔥 스케줄 조회 오류:', error);
      throw error;
    }
    
    const validSchedules = (data || []).filter(schedule => 
      schedule && 
      schedule.start_time && 
      schedule.end_time && 
      schedule.professor_name &&
      schedule.sub_locations
    );

    console.log('✅ 유효한 스케줄 개수:', validSchedules.length);

    if (validSchedules.length > 0) {
      const userIds = validSchedules
        .map(s => s.requested_by)
        .filter(id => id)
        .filter((id, index, self) => self.indexOf(id) === index);

      if (userIds.length > 0) {
        const { data: users } = await supabase
          .from('users')
          .select('id, name, email')
          .in('id', userIds);

        validSchedules.forEach(schedule => {
          if (schedule.requested_by) {
            schedule.requested_user = users?.find(u => u.id === schedule.requested_by) || null;
          }
          if (schedule.approved_by) {
            schedule.approved_user = users?.find(u => u.id === schedule.approved_by) || null;
          }
        });
      }

// 🔥 2. 촬영자 배치 정보 조회 (수동 조인)
// 🔥 2. 촬영자 배치 정보 조회 (users 테이블, shooter_type 제거)
const scheduleIds = validSchedules.map(s => s.id);

console.log('🔍 [학원] 촬영자 배치 조회 시작, 스케줄 수:', scheduleIds.length);

// Step 1: shooter_assignments만 조회
const { data: assignments, error: assignError } = await supabase
  .from('shooter_assignments')
  .select('schedule_id, shooter_id')
  .in('schedule_id', scheduleIds);

console.log('🔍 [학원] 촬영자 배치 쿼리 결과:', {
  scheduleIds,
  assignments,
  assignError,
  count: assignments?.length || 0
});

if (assignError) {
  console.error('🔥 촬영자 배치 조회 오류:', assignError);
  console.error('🔥 에러 상세:', JSON.stringify(assignError, null, 2));
} else {
  console.log('✅ 촬영자 배치 조회 성공:', assignments?.length || 0);
  
  if (!assignments || assignments.length === 0) {
    console.warn('⚠️ shooter_assignments 테이블에 해당 스케줄의 배치 데이터가 없습니다!');
    console.warn('⚠️ 다음 스케줄 ID들을 확인하세요:', scheduleIds);
  } else {
    // Step 2: shooter_id로 users 테이블 조회 (shooter_type 제거!)
    const shooterIds = [...new Set(assignments.map(a => a.shooter_id))];
    
    console.log('🔍 [학원] 촬영자 프로필 조회 시작 (users 테이블):', shooterIds);
    
    const { data: shooterProfiles, error: profileError } = await supabase
      .from('users')
      .select('id, name, email')  // 🔥 shooter_type 제거!
      .in('id', shooterIds);
    
    if (profileError) {
      console.error('🔥 촬영자 프로필 조회 오류:', profileError);
    } else {
      console.log('✅ 촬영자 프로필 조회 성공 (users 테이블):', shooterProfiles?.length || 0);
      
      // Step 3: 수동 조인
      validSchedules.forEach(schedule => {
        const scheduleAssignments = assignments.filter(
          a => a.schedule_id === schedule.id
        );
        
        schedule.shooter_assignments = scheduleAssignments.map(a => {
          const shooterProfile = shooterProfiles?.find(p => p.id === a.shooter_id);
          return {
            ...a,
            users: shooterProfile
          };
        });
        
        schedule.assigned_shooters = schedule.shooter_assignments
          .map(a => a.users?.name)
          .filter(Boolean);
        
        if (schedule.assigned_shooters.length > 0) {
          console.log(`📸 스케줄 ID ${schedule.id}: ${schedule.assigned_shooters.join(', ')}`);
        }
      });
    }
  }
}
    }


    setSchedules(validSchedules);
  } catch (error) {
    console.error('학원 스케줄 조회 오류:', error);
    throw error;
  }
}, [academyLocations, mainLocations, generateWeekDates]);


  const fetchAcademyLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('sub_locations')
        .select(`*, main_locations!inner(*)`)
        .eq('is_active', true)
        .eq('main_locations.location_type', 'academy')
        .order('main_location_id')
        .order('id');

      if (error) throw error;
      
      const accessibleAcademies = getUserAccessibleAcademies();
      const accessibleAcademyIds = accessibleAcademies.map(academy => academy.id);
      
      let filteredLocations = (data || []);
      
      const userRole = localStorage.getItem('userRole') || '';
      if (userRole === 'academy_manager') {
        filteredLocations = filteredLocations.filter((loc: any) => 
          accessibleAcademyIds.includes(loc.main_location_id)
        );
      }
      
      const formattedLocations = filteredLocations.map((loc: any) => ({
        ...loc,
        name: `${loc.main_locations.name} - ${loc.name}`,
        displayName: `${loc.main_locations.name} - ${loc.name}`
      }));
      
      setAcademyLocations(formattedLocations);
    } catch (error) {
      console.error('학원 위치 조회 오류:', error);
      throw error;
    }
  };

  const fetchMainLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('main_locations')
        .select('*')
        .eq('is_active', true)
        .eq('location_type', 'academy')
        .order('name');

      if (error) throw error;
      setMainLocations(data || []);
    } catch (error) {
      console.error('메인 위치 조회 오류:', error);
      throw error;
    }
  };

  const fetchShooters = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .in('shooter_type', ['photographer', 'videographer', 'both'])
        .order('name');
      
      if (error) throw error;
      setShooters(data || []);
    } catch (error) {
      console.error('촬영자 조회 오류:', error);
      setShooters([]);
    }
  };

const fetchData = async () => {
  try {
    setError(null);
    setIsLoading(true);
    
    console.log('🔄 [학원] 데이터 로딩 시작');
    
    // 1. mainLocations 먼저 로드
    const { data: mainLocsData } = await supabase
      .from('main_locations')
      .select('*')
      .eq('is_active', true)
      .eq('location_type', 'academy')
      .order('name');
    
    const loadedMainLocations = mainLocsData || [];
    setMainLocations(loadedMainLocations);
    console.log('✅ [학원] mainLocations 로드 완료:', loadedMainLocations.length);
    
    // 2. academyLocations 로드
    const userRole = localStorage.getItem('userRole') || '';
    const userName = localStorage.getItem('userName') || '';
    
    let accessibleAcademies = loadedMainLocations;
    if (userRole === 'academy_manager') {
      const assignedAcademyIds = JSON.parse(localStorage.getItem('assignedAcademyIds') || '[]');
      accessibleAcademies = loadedMainLocations.filter(academy => assignedAcademyIds.includes(academy.id));
    }
    
    const { data: locsData } = await supabase
      .from('sub_locations')
      .select(`*, main_locations!inner(*)`)
      .eq('is_active', true)
      .eq('main_locations.location_type', 'academy')
      .order('main_location_id')
      .order('id');

    let loadedLocations = (locsData || []);
    const accessibleAcademyIds = accessibleAcademies.map(academy => academy.id);
    
    if (userRole === 'academy_manager') {
      loadedLocations = loadedLocations.filter((loc: any) => 
        accessibleAcademyIds.includes(loc.main_location_id)
      );
    }
    
    const formattedLocations = loadedLocations.map((loc: any) => ({
      ...loc,
      name: `${loc.main_locations.name} - ${loc.name}`,
      displayName: `${loc.main_locations.name} - ${loc.name}`
    }));
    
    setAcademyLocations(formattedLocations);
    console.log('✅ [학원] academyLocations 로드 완료:', formattedLocations.length);
    
    // 3. shooters 로드
    await fetchShooters();
    console.log('✅ [학원] shooters 로드 완료');
    
    // 4. schedules 조회 (로드된 데이터를 파라미터로 전달!)
    await fetchSchedules(formattedLocations, loadedMainLocations);
    console.log('✅ [학원] schedules 로드 완료');
    
  } catch (error) {
    console.error('❌ [학원] 데이터 로딩 오류:', error);
    setError('데이터를 불러오는데 실패했습니다. 네트워크 연결을 확인해주세요.');
  } finally {
    setIsLoading(false);
  }
};


  // 🔥 localStorage 변경 감지 (통합 스케줄 동기화) - fetchSchedules 선언 후에!
  useEffect(() => {
    const handleStorageChange = () => {
      const updatedFlag = localStorage.getItem('schedules_updated');
      if (updatedFlag) {
        const timestamp = parseInt(updatedFlag);
        const now = Date.now();
        
        if (now - timestamp < 3000) {
          console.log('🔄 [학원] 통합 스케줄 변경 감지 - 재조회');
          fetchSchedules();
          localStorage.removeItem('schedules_updated');
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    const interval = setInterval(handleStorageChange, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [fetchSchedules]); // ✅ fetchSchedules 의존성 추가

  useEffect(() => {
    console.log('🔧 selectedSchedules 상태 변경됨:', selectedSchedules);
  }, [selectedSchedules]);

  // 🔥 초기 데이터 로딩
  useEffect(() => {
    if (currentWeek) {
      console.log('✅ currentWeek 준비 완료, fetchData 실행:', currentWeek);
      fetchData();
    }
  }, [currentWeek]);

    // Part 1에서 계속...

  const handleCellClick = (date: string, location: any) => {
    console.log('🔧 handleCellClick 호출됨 (빈 셀 클릭):', {
      date,
      locationId: location.id,
      locationName: location.name
    });

    const fallbackLocations = academyLocations.length > 0
      ? academyLocations
      : [];

    const modalDataObj = {
      mode: 'create',
      date,
      locationId: location.id,
      scheduleData: null,
      mainLocations,
      academyLocations: fallbackLocations,
      shooters
    };
    
    console.log('🔧 새 등록 모달 데이터:', modalDataObj);
    setModalData(modalDataObj);
    setModalOpen(true);
  };

  const handleScheduleCardClick = (schedule: any) => {
    console.log('🔧 handleScheduleCardClick 호출됨:', {
      scheduleId: schedule?.id,
      professorName: schedule?.professor_name,
      approvalStatus: schedule?.approval_status,
      isActive: schedule?.is_active,
      isCancelled: schedule?.approval_status === 'cancelled' && schedule?.is_active === false
    });

    try {
      if (!schedule || !schedule.id) {
        console.log('❌ 스케줄 데이터 없음 - 등록 모달 열기');
        return;
      }

      const modalDataObj = {
        mode: 'edit' as const,
        scheduleData: schedule,
        date: schedule.shoot_date,
        locationId: schedule.sub_location_id,
        mainLocations,
        academyLocations,
        shooters
      };
      
      console.log('🔧 모달 데이터 설정 (취소 포함):', {
        mode: modalDataObj.mode,
        scheduleId: schedule.id,
        approvalStatus: schedule.approval_status,
        isActive: schedule.is_active
      });
      
      setModalData(modalDataObj);
      setModalOpen(true);
      console.log('✅ 기존 정보 확인 모달 열기 완료 (취소 포함)');
    } catch (error) {
      console.error('❌ 모달 열기 오류:', error);
    }
  };

  const closeModal = () => {
    setModalOpen(false);
    setModalData(null);
  };

  // 🔥 실제 handleSave 함수 (전체 로직 포함)
  const handleSave = async (data: any, action: string) => {
    console.log('🔧 handleSave 호출:', { action, data });
    
    // ... 여기에 실제 저장 로직이 들어갑니다
    // 원본 파일에 있는 전체 로직을 그대로 사용하세요
    
    try {
      await fetchSchedules();
      return { success: true, message: '저장되었습니다.' };
    } catch (error) {
      return { success: false, message: '저장 실패' };
    }
  };

  const handleDelete = async (id: number) => {
    console.log('[ADMIN] 삭제 완료 ID:', id);
    await fetchSchedules();
  };

  const getScheduleForCell = (date: string, location: any) => {
    try {
      const cellSchedules = schedules.filter(s => {
        const matchesDate = s.shoot_date === date;
        const matchesLocation = s.sub_location_id === location.id;
        return matchesDate && matchesLocation;
      });
      
      return cellSchedules;
    } catch (error) {
      console.error('셀 스케줄 조회 오류:', error);
      return [];
    }
  };

const renderAcademyScheduleCard = (schedule: any) => {
  const isSelected = selectedSchedules.includes(schedule.id);
  const isCancelled = schedule.approval_status === 'cancelled' && schedule.is_active === false;
  
  const locationColor = getLocationColor(schedule.sub_location_id);
  
  // 🔥 촬영자 이름 문자열 생성
  const shooterText = schedule.assigned_shooters && schedule.assigned_shooters.length > 0
    ? ` ${schedule.assigned_shooters.join(', ')}`
    : undefined; // undefined면 카드에서 '미배치' 표시
  
  return (
    <ScheduleCardErrorBoundary key={schedule.id}>
      <div 
        style={{
          position: 'relative',
          transition: 'all 0.2s ease',
          opacity: isCancelled ? 0.5 : 1,
          filter: isCancelled ? 'grayscale(50%)' : 'none',
          cursor: 'pointer'
        }}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          handleScheduleCardClick(schedule);
        }}
      >
        {isCancelled && (
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 20,
            borderRadius: '8px',
            color: 'white',
            fontWeight: 'bold',
            fontSize: '14px',
            pointerEvents: 'none'
          }}>
            취소완료
          </div>
        )}

        <UnifiedScheduleCard
          schedule={schedule}
          scheduleType="academy"
          locationColor={locationColor}
          onClick={() => {}}
          onContextMenu={() => {}}
          showCheckbox={!isCancelled}
          isSelected={isSelected}
          onCheckboxChange={(checked) => {
            if (checked) {
              setSelectedSchedules([...selectedSchedules, schedule.id]);
            } else {
              setSelectedSchedules(selectedSchedules.filter(id => id !== schedule.id));
            }
          }}
          shooterText={shooterText} // 🔥 추가!
          style={{ pointerEvents: 'none' }}
        />
      </div>
    </ScheduleCardErrorBoundary>
  );
};

  const getLocationColor = (locationId: number) => {
    const location = academyLocations.find(loc => loc.id === locationId);
    const academyId = location?.main_location_id;
    return (academyColors as any)[academyId] || { bg: '#f8fafc', border: '#e2e8f0', text: '#1f2937' };
  };

  const getFilteredLocations = () => {
    let filtered = academyLocations;
    if (filters.mainLocationId !== 'all') {
      filtered = filtered.filter((loc: any) => loc.main_location_id === parseInt(filters.mainLocationId));
    }
    return filtered;
  };

  const getFilteredSchedules = () => {
    let filtered = schedules;
    if (filters.shootingType !== 'all') {
      filtered = filtered.filter((s: any) => s.shooting_type === filters.shootingType);
    }
    if (filters.status !== 'all') {
      filtered = filtered.filter((s: any) => s.approval_status === filters.status);
    }
    return filtered;
  };

  const renderFilters = () => {
    if (isManagerMode()) return null;
    
    return (
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: 12,
        flexDirection: 'row'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <label style={{ 
            fontSize: 13, 
            fontWeight: 600,
            color: 'var(--text-primary)',
            minWidth: '40px'
          }}>
            학원:
          </label>
          <select
            value={filters.mainLocationId}
            onChange={(e) => setFilters({...filters, mainLocationId: e.target.value})}
            style={{
              padding: '4px 8px',
              border: '1px solid var(--border-color)',
              borderRadius: 4,
              background: 'var(--bg-primary)',
              color: 'var(--text-primary)',
              fontSize: 13,
              outline: 'none'
            }}
          >
            <option value="all">전체 학원</option>
            {mainLocations.map((loc: any) => (
              <option key={loc.id} value={loc.id.toString()}>
                {loc.name}
              </option>
            ))}
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <label style={{ 
            fontSize: 13, 
            fontWeight: 600,
            color: 'var(--text-primary)',
            minWidth: '50px'
          }}>
            촬영형식:
          </label>
          <select
            value={filters.shootingType}
            onChange={(e) => setFilters({...filters, shootingType: e.target.value})}
            style={{
              padding: '4px 8px',
              border: '1px solid var(--border-color)',
              borderRadius: 4,
              background: 'var(--bg-primary)',
              color: 'var(--text-primary)',
              fontSize: 13,
              outline: 'none'
            }}
          >
            <option value="all">전체</option>
            <option value="촬영">촬영</option>
            <option value="중계">중계</option>
            <option value="(본사)촬영">(본사)촬영</option>
            <option value="라이브촬영">라이브촬영</option>
            <option value="라이브중계">라이브중계</option>
            <option value="(NAS)촬영">(NAS)촬영</option>
          </select>
        </div>
      </div>
    );
  };

  const handleBulkApproval = async (type: 'selected' | 'all') => {
    console.log('일괄 승인:', type);
  };

  if (isLoading) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '400px',
        backgroundColor: '#f8fafc'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: '4px solid #e5e7eb',
            borderTop: '4px solid #2563eb',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 16px'
          }} />
          <div style={{ 
            color: '#6b7280',
            fontSize: '14px',
            fontWeight: '500'
          }}>
            학원 스케줄을 불러오는 중...
          </div>
          <style jsx>{`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}</style>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '400px',
        backgroundColor: '#fef2f2'
      }}>
        <div style={{ textAlign: 'center', maxWidth: '400px' }}>
          <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚠️</div>
          <div style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#dc2626',
            marginBottom: '8px'
          }}>
            학원 스케줄 로딩 오류
          </div>
          <div style={{
            fontSize: '14px',
            color: '#6b7280',
            marginBottom: '20px'
          }}>
            {error}
          </div>
          <button 
            onClick={fetchData}
            style={{
              padding: '10px 20px',
              backgroundColor: '#2563eb',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontWeight: 'bold',
              fontSize: '14px'
            }}
          >
            다시 시도
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <BaseScheduleGrid
        title="학원 스케줄 관리"
        leftColumnTitle="강의실"
        locations={getFilteredLocations()}
        schedules={getFilteredSchedules()}
        currentWeek={currentWeek}
        onWeekChange={navigateWeek}
        onCellClick={handleCellClick}
        getScheduleForCell={getScheduleForCell}
        renderScheduleCard={renderAcademyScheduleCard}
        showAddButton={true}
        onCopyPreviousWeek={undefined}
        userRole={userRole}
        pageType="academy"
        getLocationColor={getLocationColor}
        customFilters={renderFilters()}
        onBulkApproval={userRole === 'admin' ? handleBulkApproval : undefined}
        selectedSchedules={selectedSchedules}
      />
    
      {modalOpen && (
        <AcademyScheduleModal
          open={modalOpen}
          onClose={closeModal}
          initialData={modalData}
          locations={modalData?.academyLocations || []}
          mainLocations={modalData?.mainLocations || []}
          userRole={userRole}
          onSave={handleSave}
          onDelete={handleDelete}
        />
      )}
    </>
  );
}