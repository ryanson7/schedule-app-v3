"use client";
import React, { useState, useEffect } from "react";
import { supabase } from "../../utils/supabaseClient";
import { ProfessorAutocomplete } from "../ProfessorAutocomplete";

interface AcademyScheduleModalProps {
  open: boolean;
  onClose: () => void;
  initialData?: any;
  locations: any[];
  mainLocations?: any[];
  userRole: string;
  currentUserId?: number | null; // ✅ 페이지에서 내려주는 내부 users.id
  onSave: (
    data: any,
    action:
      | "temp"
      | "request"
      | "approve"
      | "modify_request"
      | "cancel_request"
      | "delete_request"
      | "modify_approve"
      | "cancel_approve"
      | "delete_approve"
      | "cancel"
      | "delete"
      | "cancel_cancel"
      | "cancel_delete"
      | "approve_modification"
  ) => Promise<{ success: boolean; message: string }>;
}

/* ======================
   🔥 사유 입력 모달
   ====================== */
const ReasonModal = ({
  open,
  type,
  onClose,
  onSubmit,
}: {
  open: boolean;
  type: "modify" | "cancel" | "delete";
  onClose: () => void;
  onSubmit: (reason: string) => void;
}) => {
  const [reason, setReason] = useState("");

  const titles = {
    modify: "수정 요청 사유",
    cancel: "취소 요청 사유",
    delete: "삭제 요청 사유",
  };
  const placeholders = {
    modify: "수정이 필요한 이유를 입력해주세요...",
    cancel: "취소가 필요한 이유를 입력해주세요...",
    delete: "삭제가 필요한 이유를 입력해주세요...",
  };
  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 2000,
      }}
    >
      <div
        style={{
          backgroundColor: "white",
          borderRadius: 12,
          width: 400,
          maxWidth: "90vw",
          padding: 24,
          boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)",
        }}
      >
        <h3 style={{ margin: "0 0 16px 0", fontSize: 18, fontWeight: "bold" }}>
          {titles[type]}
        </h3>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder={placeholders[type]}
          rows={4}
          style={{
            width: "100%",
            padding: 12,
            border: "1px solid #d1d5db",
            borderRadius: 6,
            fontSize: 14,
            outline: "none",
            resize: "vertical",
            marginBottom: 16,
          }}
        />
        <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
          <button
            onClick={() => {
              setReason("");
              onClose();
            }}
            style={{
              padding: "8px 16px",
              border: "1px solid #d1d5db",
              borderRadius: 6,
              backgroundColor: "white",
              cursor: "pointer",
            }}
          >
            취소
          </button>
          <button
            onClick={() => {
              if (!reason.trim()) {
                alert("사유를 입력해주세요.");
                return;
              }
              onSubmit(reason.trim());
              setReason("");
            }}
            style={{
              padding: "8px 16px",
              border: "none",
              borderRadius: 6,
              backgroundColor: "#2563eb",
              color: "white",
              cursor: "pointer",
            }}
          >
            요청 전송
          </button>
        </div>
      </div>
    </div>
  );
};

/* ==============================
   🔥 메인: AcademyScheduleModal
   ============================== */

type WeekDayOption = { label: string; value: string };

export default function AcademyScheduleModal({
  open,
  onClose,
  initialData,
  locations,
  mainLocations,
  userRole,
  currentUserId: propCurrentUserId,
  onSave,
}: AcademyScheduleModalProps) {
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  // ✅ 모달에서 사용할 내부 users.id (페이지에서 받은 값 우선)
  const [modalUserId, setModalUserId] = useState<number | null>(null);
  const [userIdLoading, setUserIdLoading] = useState(true);

  const [reasonModalOpen, setReasonModalOpen] = useState(false);
  const [requestType, setRequestType] = useState<"modify" | "cancel" | "delete">(
    "modify"
  );

  // 🔥 히스토리
  const [scheduleHistory, setScheduleHistory] = useState<any[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // 🔥 차주 입력 잠금
  const [weekDays, setWeekDays] = useState<WeekDayOption[]>([]);
  const [isScheduleLocked, setIsScheduleLocked] = useState(false);

  // 🔥 시간 포맷 (히스토리용)
  const formatDateTime = (dateTime: string) => {
    return new Date(dateTime).toLocaleString("ko-KR", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // 🔥 차주 월~일 계산
  const getNextWeekRange = () => {
    const now = new Date();
    const day = now.getDay(); // 0:일, 1:월 ...
    const diffToMonday = day === 0 ? -6 : 1 - day;
    const thisMonday = new Date(now);
    thisMonday.setHours(0, 0, 0, 0);
    thisMonday.setDate(now.getDate() + diffToMonday);

    const nextMonday = new Date(thisMonday);
    nextMonday.setDate(thisMonday.getDate() + 7);

    const nextSunday = new Date(nextMonday);
    nextSunday.setDate(nextMonday.getDate() + 6);

    return { start: nextMonday, end: nextSunday };
  };

  // ✅ 모달 사용자 ID 세팅 (user_profiles 조회 제거)
  useEffect(() => {
    if (!open) return;

    setUserIdLoading(true);

    // 1) 페이지에서 내려온 internal users.id 우선
    if (typeof propCurrentUserId === "number" && propCurrentUserId > 0) {
      setModalUserId(propCurrentUserId);
      setUserIdLoading(false);
      return;
    }

    // 2) fallback: localStorage userId
    const storedUserId = localStorage.getItem("userId");
    if (storedUserId && storedUserId !== "null" && storedUserId !== "undefined") {
      const parsed = parseInt(storedUserId);
      if (!isNaN(parsed) && parsed > 0) {
        setModalUserId(parsed);
        setUserIdLoading(false);
        return;
      }
    }

    // 3) 마지막 fallback
    setModalUserId(1);
    setUserIdLoading(false);
  }, [open, propCurrentUserId]);

// ✅ ESC로 모달 닫기 (다시 안되는 문제 복구)
useEffect(() => {
  if (!open) return;

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.key !== "Escape") return;

    // 사유 모달이 떠 있으면 우선 그것부터 닫고, 메인 모달은 유지
    if (reasonModalOpen) {
      e.preventDefault();
      setReasonModalOpen(false);
      return;
    }

    // 저장 중에는 예기치 않은 중단 방지
    if (saving) return;

    e.preventDefault();
    onClose();
  };

  window.addEventListener("keydown", onKeyDown);
  return () => window.removeEventListener("keydown", onKeyDown);
}, [open, reasonModalOpen, saving, onClose]);


  const formatKoreanDate = (dateStr?: string) => {
    if (!dateStr) return "";
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    const yoil = ["일", "월", "화", "수", "목", "금", "토"][d.getDay()];
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${mm}/${dd}(${yoil})`;
  };

  // 🔥 차주 주간 정보 + LOCK 계산
  useEffect(() => {
    if (!open) return;

    const { start } = getNextWeekRange();
    const days: WeekDayOption[] = [];
    const labels = ["월", "화", "수", "목", "금", "토", "일"];

    for (let i = 0; i < 7; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const label = `${mm}/${dd}(${labels[i]})`;

      days.push({ label, value: `${yyyy}-${mm}-${dd}` });
    }
    setWeekDays(days);

    // 🔒 학원 매니저: "이번 주 화요일 17:00" 이후에는 차주 입력 잠금
//    ⚠️ 기존 구현은 '다음 화요일'을 기준으로 잡히는 경우가 있어, 실제로는 잠금이 풀려버리는 버그가 발생할 수 있음.
const now = new Date();

// 이번 주(월~일) 기준 월요일 00:00
const day = now.getDay(); // 0(일)~6(토)
const diffToMonday = day === 0 ? -6 : 1 - day;
const thisMonday = new Date(now);
thisMonday.setHours(0, 0, 0, 0);
thisMonday.setDate(now.getDate() + diffToMonday);

// 이번 주 화요일 17:00
const thisTuesday1700 = new Date(thisMonday);
thisTuesday1700.setDate(thisMonday.getDate() + 1);
thisTuesday1700.setHours(17, 0, 0, 0);

const role = localStorage.getItem("userRole") || "";
if (role === "academy_manager" && now > thisTuesday1700) setIsScheduleLocked(true);
else setIsScheduleLocked(false);
  }, [open]);

  // 🔥 초기 폼 데이터
  const getInitValue = (v: any): string =>
    v === null || v === undefined ? "" : String(v).trim();

  const formatTimeForInput = (t: any): string => {
    if (!t) return "";
    const s = String(t).trim();
    if (s.includes(":")) {
      const [h, m] = s.split(":");
      return `${h.padStart(2, "0")}:${(m ?? "00").padStart(2, "0")}`;
    }
    return s;
  };

  const getInitialFormData = () => {
    const scheduleData = initialData?.scheduleData;
    const isEditModeLocal = !!(scheduleData && scheduleData.id);

    if (isEditModeLocal) {
      return {
        shoot_date: getInitValue(scheduleData.shoot_date || initialData.date),
        start_time: formatTimeForInput(scheduleData.start_time),
        end_time: formatTimeForInput(scheduleData.end_time),
        professor_name: getInitValue(scheduleData.professor_name),
        course_name: getInitValue(scheduleData.course_name),
        course_code: getInitValue(scheduleData.course_code),
        shooting_type: getInitValue(scheduleData.shooting_type || "촬영"),
        notes: getInitValue(scheduleData.notes),
        sub_location_id: getInitValue(
          scheduleData.sub_location_id || initialData.locationId
        ),
        professor_category_name: getInitValue(scheduleData.professor_category_name),
        professor_category_id: scheduleData.professor_category_id ?? null,
      };
    }

    return {
      shoot_date: getInitValue(initialData?.date),
      start_time: "",
      end_time: "",
      professor_name: "",
      course_name: "",
      course_code: "",
      shooting_type: "촬영",
      notes: "",
      sub_location_id: getInitValue(initialData?.locationId),
      professor_category_name: "",
      professor_category_id: null,
    };
  };

  const [formData, setFormData] = useState(getInitialFormData);
  const [selectedProfessorInfo, setSelectedProfessorInfo] = useState<any>(null);

  const isEditMode = !!(initialData?.scheduleData && initialData.scheduleData.id);
  const scheduleData = initialData?.scheduleData || null;
  const currentStatus = scheduleData?.approval_status || "pending";
  const isInactive = scheduleData?.is_active === false;

  const isAfterApproval = ["approved", "confirmed"].includes(currentStatus);
  const isAfterApprovalRequest = ["approval_requested", "approved", "confirmed"].includes(
    currentStatus
  );
  const isModificationInProgress = currentStatus === "modification_approved";
  const isModificationRequested = currentStatus === "modification_requested";
  const isCancellationInProgress = currentStatus === "cancellation_requested";
  const isDeletionInProgress = currentStatus === "deletion_requested";

  // 🔥 교수 자동완성 변경 핸들러
  const handleProfessorChange = (value: string, professor?: any) => {
    setFormData((prev) => ({
      ...prev,
      professor_name: value,
      professor_category_name:
        professor?.category_name ?? prev.professor_category_name ?? "",
      professor_category_id:
        professor?.category_id ??
        professor?.categoryId ??
        professor?.id ??
        prev.professor_category_id ??
        null,
    }));

    if (professor) {
      setSelectedProfessorInfo({
        id: professor?.id ?? professor?.category_id ?? professor?.categoryId ?? null,
        category_name: professor?.category_name ?? "",
      });
    } else {
      setSelectedProfessorInfo(null);
    }
  };

  // 🔥 모달 열릴 때 저장된 매칭 배지 복원
  useEffect(() => {
    if (!open) return;
    const sd = initialData?.scheduleData;
    if (sd?.professor_category_name) {
      setSelectedProfessorInfo({
        id: sd.professor_category_id ?? null,
        category_name: sd.professor_category_name,
      });
    } else if (!formData.professor_category_name) {
      setSelectedProfessorInfo(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialData?.scheduleData?.id]);

  useEffect(() => {
    if (!open) {
      setSaving(false);
      setMessage("");
      setUserIdLoading(true);
      setSelectedProfessorInfo(null);
      setScheduleHistory([]);
    }
  }, [open]);

  useEffect(() => {
    const newFormData = getInitialFormData();
    setFormData(newFormData);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialData?.scheduleData?.approval_status]);

  // 🔥 권한
  const getUserPermissions = () => {
    const currentUserRole = localStorage.getItem("userRole") || "";
    const userName = localStorage.getItem("userName") || "";
    if (
      userName === "manager1" ||
      currentUserRole === "system_admin" ||
      currentUserRole === "schedule_admin"
    ) {
      return { roleType: "admin" as const };
    }
    if (currentUserRole === "academy_manager") {
      return { roleType: "manager" as const };
    }
    return { roleType: "basic" as const };
  };
  const permissions = getUserPermissions();

  const validateFieldsForAction = (action: string) => {
    const skip = [
      "modify_request",
      "cancel_request",
      "delete_request",
      "cancel_approve",
      "delete_approve",
      "cancel",
      "delete",
      "cancel_cancel",
      "cancel_delete",
    ];
    if (skip.includes(action)) return [];
    const required = [
      { field: "shoot_date", label: "촬영 날짜" },
      { field: "start_time", label: "시작 시간" },
      { field: "end_time", label: "종료 시간" },
      { field: "professor_name", label: "교수명" },
      { field: "shooting_type", label: "촬영형식" },
      { field: "sub_location_id", label: "강의실" },
    ];
    return required.filter(
      (f) =>
        !formData[f.field as keyof typeof formData] ||
        String(formData[f.field as keyof typeof formData]).trim() === "" ||
        String(formData[f.field as keyof typeof formData]) === "0"
    );
  };

  // ✅ 강의실 표시 텍스트 (드롭다운 제거)
  const getLocationLabel = () => {
    const idStr = String(formData.sub_location_id || "");
    if (!idStr) return "강의실 정보 없음";
    const found =
      (locations || []).find((l: any) => String(l.id) === idStr) ||
      (initialData?.academyLocations || []).find((l: any) => String(l.id) === idStr);

    return (
      found?.displayName ||
      found?.name ||
      found?.fullName ||
      initialData?.locationName ||
      `강의실 ID: ${idStr}`
    );
  };

  // 🔥 히스토리 조회 (users 테이블로 매핑)
  const fetchScheduleHistory = async (scheduleId: number) => {
    if (!scheduleId) return;

    setLoadingHistory(true);
    try {
      const { data: historyData, error: historyError } = await supabase
        .from("schedule_history")
        .select("*")
        .eq("schedule_id", scheduleId)
        .order("created_at", { ascending: false });

      if (historyError) {
        console.error("히스토리 조회 오류:", historyError);
      }

      const { data: scheduleData, error: scheduleError } = await supabase
        .from("schedules")
        .select("*")
        .eq("id", scheduleId)
        .single();

      if (scheduleError) {
        console.error("스케줄 데이터 조회 오류:", scheduleError);
      }

      // 1) changed_by 수집
      const allUserIds = new Set<number>();
      (historyData || []).forEach((h: any) => {
        if (typeof h.changed_by === "number") allUserIds.add(h.changed_by);
        if (typeof h.changed_by === "string" && !isNaN(Number(h.changed_by))) {
          allUserIds.add(Number(h.changed_by));
        }
      });

      // 2) users 테이블 조회
      let userMap = new Map<number, string>();
      if (allUserIds.size > 0) {
        const { data: users } = await supabase
          .from("users")
          .select("id, name")
          .in("id", Array.from(allUserIds));
        userMap = new Map((users || []).map((u: any) => [u.id, u.name]));
      }

      const getUserDisplayName = (changedBy: any): string => {
        if (!changedBy) return "담당자 정보 없음";
        if (typeof changedBy === "number") return userMap.get(changedBy) || `ID: ${changedBy}`;
        if (typeof changedBy === "string" && !isNaN(Number(changedBy))) {
          const n = Number(changedBy);
          return userMap.get(n) || `ID: ${changedBy}`;
        }
        return String(changedBy);
      };

      const historyMap = new Map<string, any>();

      // 등록됨(시스템)
      if (scheduleData) {
        const createdHistory = (historyData || []).find(
          (h: any) => h.change_type === "created"
        );
        if (createdHistory) {
          historyMap.set(`created_${scheduleData.id}`, {
            id: `created_${scheduleData.id}`,
            action: "등록됨",
            reason: "최초 스케줄 등록",
            changed_by: getUserDisplayName(createdHistory.changed_by),
            created_at: scheduleData.created_at,
            details: `${scheduleData.professor_name} 교수님 스케줄 등록`,
            source: "system",
          });
        }
      }

      // schedule_history 병합
      (historyData || []).forEach((item: any) => {
        const userName = getUserDisplayName(item.changed_by);

        const actionLabel =
          item.change_type === "approved" || item.change_type === "approve"
            ? "승인완료"
            : item.change_type === "cancelled"
            ? "취소완료"
            : item.change_type &&
              typeof item.change_type === "string" &&
              item.change_type.toLowerCase() === "update"
            ? "수정됨"
            : item.change_type === "created"
            ? "등록됨"
            : item.change_type === "cross_check_requested"
            ? "크로스체크요청"
            : item.change_type === "cross_check_confirmed"
            ? "크로스체크완료"
            : "처리됨";

        historyMap.set(String(item.id), {
          id: String(item.id),
          action: actionLabel,
          reason: item.description || "-",
          changed_by: userName,
          created_at: item.created_at,
          details: item.description || "",
          source: "history",
        });
      });

      const essentialHistory = Array.from(historyMap.values()).sort(
        (a, b) =>
          new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );

      setScheduleHistory(essentialHistory);
    } catch (e) {
      console.error("히스토리 조회 오류:", e);
      setScheduleHistory([]);
    } finally {
      setLoadingHistory(false);
    }
  };

  // 히스토리 로딩 트리거
  useEffect(() => {
    if (isEditMode && initialData?.scheduleData?.id && open) {
      fetchScheduleHistory(initialData.scheduleData.id);
    } else {
      setScheduleHistory([]);
    }
  }, [isEditMode, initialData?.scheduleData?.id, open]);

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // 🔥 필드 비활성화
  const getFieldDisabled = () => {
    if (saving || userIdLoading || isInactive) return true;
    if (permissions.roleType === "admin") return false;

    if (permissions.roleType === "manager") {
      if (isModificationInProgress) return false;
      if (isModificationRequested) return true;
      if (isAfterApproval) return true;
      if (isAfterApprovalRequest && currentStatus !== "pending") return true;
      return false;
    }
    return true;
  };
  const fieldDisabled = getFieldDisabled();

  // 🔥 저장
  const handleSave = async (action: string, reason?: string) => {
    // 🔒 학원 매니저 신규 등록 잠금
    if (
      !isEditMode &&
      permissions.roleType === "manager" &&
      isScheduleLocked &&
      ["temp", "request"].includes(action)
    ) {
      const msg =
        "차주 스케줄 입력 가능 시간이 지났습니다. 관리자에게 문의해주세요.";
      setMessage(msg);
      alert(msg);
      return;
    }

    // ✅ 학원 매니저: '차주(월~일)' 범위 외 날짜 등록 방지 (주간 제한이 부분적으로 풀려버리는 문제 방지)
if (
  !isEditMode &&
  permissions.roleType === "manager" &&
  ["temp", "request"].includes(action)
) {
  const { start, end } = getNextWeekRange();
  const target = new Date(String(formData.shoot_date || ""));
  const targetYMD = new Date(target.getFullYear(), target.getMonth(), target.getDate());
  const startYMD = new Date(start.getFullYear(), start.getMonth(), start.getDate());
  const endYMD = new Date(end.getFullYear(), end.getMonth(), end.getDate());

  if (
    !formData.shoot_date ||
    isNaN(targetYMD.getTime()) ||
    targetYMD < startYMD ||
    targetYMD > endYMD
  ) {
    const mm = String(start.getMonth() + 1).padStart(2, "0");
    const dd = String(start.getDate()).padStart(2, "0");
    const mm2 = String(end.getMonth() + 1).padStart(2, "0");
    const dd2 = String(end.getDate()).padStart(2, "0");
    const msg = `학원 스케줄은 차주(${mm}/${dd}~${mm2}/${dd2})만 입력 가능합니다.`;
    setMessage(msg);
    alert(msg);
    return;
  }
}

if (userIdLoading) {
      setMessage("사용자 정보를 확인하는 중입니다. 잠시만 기다려주세요.");
      return;
    }
    if (!modalUserId) {
      setMessage("사용자 정보를 확인할 수 없습니다. 새로고침 후 다시 시도해주세요.");
      return;
    }

    setSaving(true);
    setMessage("");

    try {
      const emptyFields = validateFieldsForAction(action);
      if (emptyFields.length > 0) {
        const names = emptyFields.map((f) => f.label).join(", ");
        throw new Error(`다음 필수 필드를 입력해주세요: ${names}`);
      }

      const currentUserName =
        localStorage.getItem("userName") ||
        localStorage.getItem("displayName") ||
        "";

      // schedules 테이블 담당자 메타
      const userMeta: any = {};

      if (!isEditMode && ["temp", "request", "approve"].includes(action)) {
        userMeta.created_by_id = modalUserId;
        userMeta.created_by_name = currentUserName;
      }
      if (["approve", "modify_approve", "approve_modification"].includes(action)) {
        userMeta.approved_by_id = modalUserId;
        userMeta.approved_by_name = currentUserName;
      }
      if (["cancel", "cancel_approve"].includes(action)) {
        userMeta.cancelled_by_id = modalUserId;
        userMeta.cancelled_by_name = currentUserName;
      }
      if (["delete", "delete_approve"].includes(action)) {
        userMeta.deleted_by_id = modalUserId;
        userMeta.deleted_by_name = currentUserName;
      }

      const formDataWithUser = {
        ...formData,
        changed_by: modalUserId,
        changed_by_name: currentUserName,
        ...userMeta,

        currentUserId: modalUserId,
        reason: reason || "",
        schedule_id: initialData?.scheduleData?.id || null,
        professor_category_name: selectedProfessorInfo?.category_name || null,
        professor_category_id: selectedProfessorInfo?.id || null,
      };

      const result = await onSave(formDataWithUser, action as any);
      setMessage(result.message);

      if (result.success) {
        alert(result.message);
        onClose();
        setMessage("");
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "처리 중 오류가 발생했습니다.";
      setMessage(msg);
      alert(msg);
      console.error("저장 오류:", e);
    } finally {
      setSaving(false);
    }
  };

  const handleRequestWithReason = (reason: string) => {
    setReasonModalOpen(false);
    const map = {
      modify: "modify_request",
      cancel: "cancel_request",
      delete: "delete_request",
    } as const;
    handleSave(map[requestType], reason);
  };

  const generateTimeOptions = () => {
    const options: string[] = [];
    for (let h = 7; h <= 22; h++) {
      for (let m = 0; m < 60; m += 5) {
        options.push(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
      }
    }
    return options;
  };
  const timeOptions = generateTimeOptions();

  const academyShootingTypes = [
    "촬영",
    "중계",
    "(본사)촬영",
    "라이브촬영",
    "라이브중계",
    "(NAS)촬영",
  ];

  // 🔥 버튼 구성(원본 유지: 좌/우 그룹)
  const renderActionButtons = () => {
    const emptyForTemp = validateFieldsForAction("temp");
    const canSave =
      !saving &&
      !userIdLoading &&
      emptyForTemp.length === 0 &&
      !isInactive &&
      modalUserId;

    const BTN = {
      padding: "10px 16px",
      border: "none",
      borderRadius: 6,
      cursor: "pointer",
      fontSize: 14,
      fontWeight: 500,
      whiteSpace: "nowrap",
    } as const;

    const leftButtons: React.ReactNode[] = [];
    const rightButtons: React.ReactNode[] = [];

    leftButtons.push(
      <button
        key="close"
        onClick={onClose}
        disabled={saving}
        style={{
          ...BTN,
          border: "1px solid #d1d5db",
          backgroundColor: "white",
          color: "#374151",
          cursor: saving ? "not-allowed" : "pointer",
          opacity: saving ? 0.5 : 1,
        }}
      >
        닫기
      </button>
    );

    if (isInactive) return { leftButtons, rightButtons };
    const isDisabled = saving || userIdLoading || !modalUserId;

    if (permissions.roleType === "admin") {
      leftButtons.push(
        <button
          key="temp"
          onClick={() => handleSave("temp")}
          disabled={!canSave}
          style={{
            ...BTN,
            backgroundColor: canSave ? "#6b7280" : "#d1d5db",
            color: "white",
          }}
        >
          임시저장
        </button>
      );

      if (!isEditMode) {
        rightButtons.push(
          <button
            key="approve"
            onClick={() => handleSave("approve")}
            disabled={!canSave}
            style={{
              ...BTN,
              backgroundColor: canSave ? "#059669" : "#d1d5db",
              color: "white",
            }}
          >
            승인
          </button>
        );
      } else {
        rightButtons.push(
          <button
            key="modify_approve"
            onClick={() => handleSave("modify_approve")}
            disabled={!canSave}
            style={{
              ...BTN,
              backgroundColor: canSave ? "#059669" : "#d1d5db",
              color: "white",
            }}
          >
            승인
          </button>
        );

        if (currentStatus === "modification_requested") {
          rightButtons.push(
            <button
              key="approve_modification"
              onClick={() => handleSave("approve_modification")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#8b5cf6",
                color: "white",
              }}
            >
              수정권한부여
            </button>
          );
        }

        if (currentStatus === "cancellation_requested") {
          rightButtons.push(
            <button
              key="cancel_approve"
              onClick={() => handleSave("cancel_approve")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
                color: "white",
              }}
            >
              취소승인
            </button>
          );
          rightButtons.push(
            <button
              key="cancel_cancel"
              onClick={() => handleSave("cancel_cancel")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#6b7280",
                color: "white",
              }}
            >
              취소거부
            </button>
          );
        }

        if (currentStatus === "deletion_requested") {
          rightButtons.push(
            <button
              key="delete_approve"
              onClick={() => handleSave("delete_approve")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#dc2626",
                color: "white",
              }}
            >
              삭제승인
            </button>
          );
          rightButtons.push(
            <button
              key="cancel_delete"
              onClick={() => handleSave("cancel_delete")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#6b7280",
                color: "white",
              }}
            >
              삭제거부
            </button>
          );
        }

        rightButtons.push(
          <button
            key="cancel"
            onClick={() => handleSave("cancel")}
            disabled={isDisabled}
            style={{
              ...BTN,
              backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
              color: "white",
            }}
          >
            취소
          </button>
        );
        rightButtons.push(
          <button
            key="delete"
            onClick={() => handleSave("delete")}
            disabled={isDisabled}
            style={{
              ...BTN,
              backgroundColor: isDisabled ? "#d1d5db" : "#dc2626",
              color: "white",
            }}
          >
            삭제
          </button>
        );
      }
    } else if (permissions.roleType === "manager") {
      if (!isEditMode) {
        leftButtons.push(
          <button
            key="temp"
            onClick={() => handleSave("temp")}
            disabled={!canSave}
            style={{
              ...BTN,
              backgroundColor: canSave ? "#6b7280" : "#d1d5db",
              color: "white",
            }}
          >
            임시저장
          </button>
        );

        rightButtons.push(
          <button
            key="request"
            onClick={() => handleSave("request")}
            disabled={!canSave}
            style={{
              ...BTN,
              backgroundColor: canSave ? "#2563eb" : "#d1d5db",
              color: "white",
            }}
          >
            승인요청
          </button>
        );
      } else {
        if (currentStatus === "pending") {
          leftButtons.push(
            <button
              key="temp"
              onClick={() => handleSave("temp")}
              disabled={!canSave}
              style={{
                ...BTN,
                backgroundColor: canSave ? "#6b7280" : "#d1d5db",
                color: "white",
              }}
            >
              임시저장
            </button>
          );
          rightButtons.push(
            <button
              key="request"
              onClick={() => handleSave("request")}
              disabled={!canSave}
              style={{
                ...BTN,
                backgroundColor: canSave ? "#2563eb" : "#d1d5db",
                color: "white",
              }}
            >
              승인요청
            </button>
          );
        } else if (["approved", "confirmed"].includes(currentStatus)) {
          rightButtons.push(
            <button
              key="modify_request"
              onClick={() => {
                setRequestType("modify");
                setReasonModalOpen(true);
              }}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#8b5cf6",
                color: "white",
              }}
            >
              수정권한요청
            </button>
          );
          rightButtons.push(
            <button
              key="cancel_request"
              onClick={() => {
                setRequestType("cancel");
                setReasonModalOpen(true);
              }}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
                color: "white",
              }}
            >
              취소요청
            </button>
          );
          rightButtons.push(
            <button
              key="delete_request"
              onClick={() => {
                setRequestType("delete");
                setReasonModalOpen(true);
              }}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#dc2626",
                color: "white",
              }}
            >
              삭제요청
            </button>
          );
        } else if (isModificationRequested) {
          leftButtons.push(
            <button
              key="cancel_cancel"
              onClick={() => handleSave("cancel_cancel")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
                color: "white",
              }}
            >
              요청철회
            </button>
          );
        } else if (isModificationInProgress) {
          leftButtons.push(
            <button
              key="temp"
              onClick={() => handleSave("temp")}
              disabled={!canSave}
              style={{
                ...BTN,
                backgroundColor: canSave ? "#6b7280" : "#d1d5db",
                color: "white",
              }}
            >
              임시저장
            </button>
          );
          rightButtons.push(
            <button
              key="request"
              onClick={() => handleSave("request")}
              disabled={!canSave}
              style={{
                ...BTN,
                backgroundColor: canSave ? "#2563eb" : "#d1d5db",
                color: "white",
              }}
            >
              수정승인요청
            </button>
          );
          rightButtons.push(
            <button
              key="cancel_request"
              onClick={() => {
                setRequestType("cancel");
                setReasonModalOpen(true);
              }}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
                color: "white",
              }}
            >
              취소요청
            </button>
          );
        }

        if (currentStatus === "cancellation_requested") {
          leftButtons.push(
            <button
              key="cancel_cancel_2"
              onClick={() => handleSave("cancel_cancel")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
                color: "white",
              }}
            >
              요청철회
            </button>
          );
        }
        if (currentStatus === "deletion_requested") {
          leftButtons.push(
            <button
              key="cancel_delete_2"
              onClick={() => handleSave("cancel_delete")}
              disabled={isDisabled}
              style={{
                ...BTN,
                backgroundColor: isDisabled ? "#d1d5db" : "#f59e0b",
                color: "white",
              }}
            >
              요청철회
            </button>
          );
        }
      }
    }

    return { leftButtons, rightButtons };
  };

  if (!open) return null;
  const { leftButtons, rightButtons } = renderActionButtons();

  return (
    <>
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1000,
        }}
      >
        <div
          style={{
            backgroundColor: "white",
            borderRadius: 12,
            width: 1200,
            maxWidth: "95vw",
            height: 800,
            maxHeight: "90vh",
            overflow: "hidden",
            boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* 헤더 */}
          <div
            style={{
              padding: "20px 24px",
              borderBottom: "1px solid #E5E7EB",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              flexShrink: 0,
            }}
          >
            <h2 style={{ margin: 0, fontSize: 18, fontWeight: "bold", color: "#111827" }}>
              {isEditMode ? "학원 스케줄 수정" : "학원 스케줄 등록"}
            </h2>
            <button
              onClick={onClose}
              disabled={saving}
              style={{
                background: "none",
                border: "none",
                fontSize: 24,
                cursor: saving ? "not-allowed" : "pointer",
                padding: 0,
                color: "#6b7280",
                opacity: saving ? 0.5 : 1,
              }}
            >
              ×
            </button>
          </div>

          {/* 본문 */}
          <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
            {/* 좌측 폼 */}
            <div
              style={{
                flex: "0 0 50%",
                padding: 24,
                overflowY: "auto",
                borderRight: "1px solid #E5E7EB",
              }}
            >
              {/* 안내/상태 배너 */}
              {permissions.roleType === "manager" && isModificationInProgress && (
                <div
                  style={{
                    marginBottom: 16,
                    padding: 12,
                    backgroundColor: "#fffbeb",
                    color: "#92400e",
                    fontSize: 14,
                    borderRadius: 6,
                    border: "1px solid #f59e0b",
                  }}
                >
                  🔄 <strong>수정 권한 부여됨</strong> - 내용을 수정한 후{" "}
                  <strong>수정승인요청</strong>을 클릭하세요.
                </div>
              )}

              {permissions.roleType === "manager" &&
                fieldDisabled &&
                isAfterApproval &&
                !isModificationInProgress &&
                !isInactive && (
                  <div
                    style={{
                      marginBottom: 16,
                      padding: 12,
                      backgroundColor: "#fef3c7",
                      color: "#92400e",
                      fontSize: 14,
                      borderRadius: 6,
                      border: "1px solid #fbbf24",
                    }}
                  >
                    ⚠️ 승인된 스케줄은 직접 수정할 수 없습니다.{" "}
                    <strong>수정권한요청</strong>을 사용해주세요.
                  </div>
                )}

              {permissions.roleType === "manager" && isModificationRequested && (
                <div
                  style={{
                    marginBottom: 16,
                    padding: 12,
                    backgroundColor: "#f3e8ff",
                    color: "#6b21a8",
                    fontSize: 14,
                    borderRadius: 6,
                    border: "1px solid #8b5cf6",
                  }}
                >
                  ⏳ 수정요청 대기 중 - 관리자 승인을 기다리고 있습니다.
                </div>
              )}

              {permissions.roleType === "admin" &&
                currentStatus === "modification_requested" && (
                  <div
                    style={{
                      marginBottom: 16,
                      padding: 12,
                      backgroundColor: "#f3e8ff",
                      color: "#6b21a8",
                      fontSize: 14,
                      borderRadius: 6,
                      border: "1px solid #8b5cf6",
                    }}
                  >
                    📋 <strong>수정 권한 요청됨</strong> - 매니저가 수정 권한을 요청했습니다.
                  </div>
                )}

              {isInactive && (
                <div
                  style={{
                    marginBottom: 16,
                    padding: 12,
                    backgroundColor: "#fef2f2",
                    color: "#dc2626",
                    fontSize: 14,
                    borderRadius: 6,
                    border: "1px solid #fecaca",
                  }}
                >
                  이 스케줄은 {currentStatus === "cancelled" ? "취소완료" : "삭제완료"} 되었습니다.
                  수정할 수 없습니다.
                </div>
              )}

              {userIdLoading && (
                <div
                  style={{
                    marginBottom: 16,
                    padding: 12,
                    backgroundColor: "#eff6ff",
                    color: "#1e40af",
                    fontSize: 14,
                    borderRadius: 6,
                    border: "1px solid #bfdbfe",
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                  }}
                >
                  <div
                    style={{
                      width: 16,
                      height: 16,
                      border: "2px solid #bfdbfe",
                      borderTop: "2px solid #1e40af",
                      borderRadius: "50%",
                      animation: "spin 1s linear infinite",
                    }}
                  />
                  사용자 매핑 중...
                </div>
              )}

              {/* 수정/취소/삭제 사유 표시 */}
              {isEditMode && scheduleData && (
                <div>
                  {scheduleData.modification_reason && isModificationRequested && (
                    <div
                      style={{
                        padding: 12,
                        backgroundColor: "#faf5ff",
                        border: "1px solid #8b5cf6",
                        borderRadius: 6,
                        marginBottom: 12,
                      }}
                    >
                      <div style={{ fontSize: 12, fontWeight: "bold", color: "#8b5cf6", marginBottom: 4 }}>
                        📝 수정 요청 사유:
                      </div>
                      <div style={{ fontSize: 14, color: "#374151", lineHeight: 1.4 }}>
                        {scheduleData.modification_reason}
                      </div>
                    </div>
                  )}
                  {scheduleData.cancellation_reason && isCancellationInProgress && (
                    <div
                      style={{
                        padding: 12,
                        backgroundColor: "#fffbeb",
                        border: "1px solid #f59e0b",
                        borderRadius: 6,
                        marginBottom: 12,
                      }}
                    >
                      <div style={{ fontSize: 12, fontWeight: "bold", color: "#f59e0b", marginBottom: 4 }}>
                        ❌ 취소 요청 사유:
                      </div>
                      <div style={{ fontSize: 14, color: "#374151", lineHeight: 1.4 }}>
                        {scheduleData.cancellation_reason}
                      </div>
                    </div>
                  )}
                  {scheduleData.deletion_reason && isDeletionInProgress && (
                    <div
                      style={{
                        padding: 12,
                        backgroundColor: "#fef2f2",
                        border: "1px solid #dc2626",
                        borderRadius: 6,
                        marginBottom: 12,
                      }}
                    >
                      <div style={{ fontSize: 12, fontWeight: "bold", color: "#dc2626", marginBottom: 4 }}>
                        🗑️ 삭제 요청 사유:
                      </div>
                      <div style={{ fontSize: 14, color: "#374151", lineHeight: 1.4 }}>
                        {scheduleData.deletion_reason}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 폼 */}
              <div>
                {/* 날짜 */}
                <div style={{ marginBottom: 20 }}>
                  <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                    촬영 날짜 <span style={{ color: "#ef4444" }}>*</span>
                  </label>

                  {permissions.roleType === "manager" && !isEditMode && isScheduleLocked && (
                    <div
                      style={{
                        marginBottom: 8,
                        padding: 10,
                        borderRadius: 6,
                        backgroundColor: "#fef3c7",
                        border: "1px solid #fbbf24",
                        fontSize: 12,
                        color: "#92400e",
                      }}
                    >
                      이번 주 화요일 17시 이후로 차주 스케줄 입력이 마감되었습니다.
                      <br />
                      변경이 필요하면 관리자에게 요청해주세요.
                    </div>
                  )}

                  <div
                    style={{
                      padding: "8px 12px",
                      borderRadius: 6,
                      border: "1px solid #e5e7eb",
                      backgroundColor: "#f9fafb",
                      fontSize: 13,
                      fontWeight: 500,
                    }}
                  >
                    {formatKoreanDate(formData.shoot_date)}
                  </div>
                </div>

                {/* 시간 */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 16,
                    marginBottom: 20,
                  }}
                >
                  <div>
                    <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                      시작 시간 <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <select
                      value={formData.start_time}
                      onChange={(e) => handleChange("start_time", e.target.value)}
                      disabled={fieldDisabled}
                      style={{
                        width: "100%",
                        padding: "8px 12px",
                        border: "1px solid #d1d5db",
                        borderRadius: 6,
                        fontSize: 14,
                        outline: "none",
                        backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      }}
                    >
                      <option value="">시작 시간 선택</option>
                      {timeOptions.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                      종료 시간 <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <select
                      value={formData.end_time}
                      onChange={(e) => handleChange("end_time", e.target.value)}
                      disabled={fieldDisabled}
                      style={{
                        width: "100%",
                        padding: "8px 12px",
                        border: "1px solid #d1d5db",
                        borderRadius: 6,
                        fontSize: 14,
                        outline: "none",
                        backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      }}
                    >
                      <option value="">종료 시간 선택</option>
                      {timeOptions.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* 교수 / 강의명 */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 16,
                    marginBottom: 20,
                  }}
                >
                  <div>
                    <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                      교수명 <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <ProfessorAutocomplete
                      value={formData.professor_name}
                      onChange={handleProfessorChange}
                      placeholder="교수명을 입력하면 자동완성됩니다"
                      disabled={fieldDisabled}
                      required
                      style={{
                        backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      }}
                    />
                    {(selectedProfessorInfo?.category_name ||
                      formData.professor_category_name) && (
                      <p style={{ color: "#059669", fontSize: 12, margin: "6px 0 0 0" }}>
                        ✓ 매칭됨:{" "}
                        {selectedProfessorInfo?.category_name ||
                          formData.professor_category_name}
                      </p>
                    )}
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                      강의명
                    </label>
                    <input
                      type="text"
                      value={formData.course_name}
                      onChange={(e) => handleChange("course_name", e.target.value)}
                      disabled={fieldDisabled}
                      style={{
                        width: "100%",
                        padding: "8px 12px",
                        border: "1px solid #d1d5db",
                        borderRadius: 6,
                        fontSize: 14,
                        outline: "none",
                        backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      }}
                    />
                  </div>
                </div>

                {/* 강의코드 / 촬영형식 */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 16,
                    marginBottom: 20,
                  }}
                >
                  <div>
                    <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                      강의코드
                    </label>
                    <input
                      type="text"
                      value={formData.course_code}
                      onChange={(e) => handleChange("course_code", e.target.value)}
                      disabled={fieldDisabled}
                      style={{
                        width: "100%",
                        padding: "8px 12px",
                        border: "1px solid #d1d5db",
                        borderRadius: 6,
                        fontSize: 14,
                        outline: "none",
                        backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                      촬영형식 <span style={{ color: "#ef4444" }}>*</span>
                    </label>
                    <select
                      value={formData.shooting_type}
                      onChange={(e) => handleChange("shooting_type", e.target.value)}
                      disabled={fieldDisabled}
                      style={{
                        width: "100%",
                        padding: "8px 12px",
                        border: "1px solid #d1d5db",
                        borderRadius: 6,
                        fontSize: 14,
                        outline: "none",
                        backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      }}
                    >
                      {academyShootingTypes.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* ✅ 강의실: 드롭다운 제거, 클릭 셀 값만 표시 */}
                <div style={{ marginBottom: 20 }}>
                  <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                    강의실 <span style={{ color: "#ef4444" }}>*</span>
                  </label>

                  <div
                    style={{
                      width: "100%",
                      padding: "10px 12px",
                      border: "1px solid #e5e7eb",
                      borderRadius: 6,
                      backgroundColor: "#f9fafb",
                      fontSize: 13,
                      fontWeight: 600,
                      color: "#111827",
                    }}
                    title={String(formData.sub_location_id || "")}
                  >
                    {getLocationLabel()}
                  </div>

                  {/* hidden 유지(저장에 필요) */}
                  <input type="hidden" value={formData.sub_location_id} readOnly />
                </div>

                {/* 비고 */}
                <div style={{ marginBottom: 20 }}>
                  <label style={{ display: "block", marginBottom: 6, fontSize: 14, fontWeight: 600, color: "#374151" }}>
                    비고
                  </label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => handleChange("notes", e.target.value)}
                    disabled={fieldDisabled}
                    rows={3}
                    style={{
                      width: "100%",
                      padding: "8px 12px",
                      border: "1px solid #d1d5db",
                      borderRadius: 6,
                      fontSize: 14,
                      outline: "none",
                      backgroundColor: fieldDisabled ? "#f9fafb" : "white",
                      resize: "vertical",
                      minHeight: 60,
                    }}
                  />
                </div>
              </div>
            </div>

            {/* 우측 이력 */}
            <div
              style={{
                flex: "0 0 50%",
                display: "flex",
                flexDirection: "column",
                backgroundColor: "#f8fafc",
              }}
            >
              <div
                style={{
                  padding: "20px 24px 16px",
                  borderBottom: "1px solid #e5e7eb",
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: "bold", color: "#374151" }}>
                  처리 이력
                </h3>
                {scheduleHistory.length > 0 && (
                  <span
                    style={{
                      fontSize: 10,
                      backgroundColor: "#e5e7eb",
                      color: "#6b7280",
                      padding: "2px 6px",
                      borderRadius: 999,
                    }}
                  >
                    {scheduleHistory.length}
                  </span>
                )}
              </div>

              <div style={{ flex: 1, overflowY: "auto", padding: "16px 24px" }}>
                {isEditMode && initialData?.scheduleData?.id ? (
                  loadingHistory ? (
                    <div style={{ padding: 16, textAlign: "center", color: "#6b7280", fontSize: 12 }}>
                      <div
                        style={{
                          width: 16,
                          height: 16,
                          border: "2px solid #e5e7eb",
                          borderTop: "2px solid #3b82f6",
                          borderRadius: "50%",
                          animation: "spin 1s linear infinite",
                          margin: "0 auto 6px",
                        }}
                      />
                      히스토리를 불러오는 중...
                    </div>
                  ) : scheduleHistory.length === 0 ? (
                    <div
                      style={{
                        padding: 16,
                        textAlign: "center",
                        color: "#9ca3af",
                        fontSize: 12,
                        backgroundColor: "#f9fafb",
                        borderRadius: 6,
                        border: "1px dashed #d1d5db",
                      }}
                    >
                      변경 기록이 없습니다
                    </div>
                  ) : (
                    <div style={{ flex: 1, paddingRight: 6 }}>
                      {scheduleHistory.map((historyItem: any, index: number) => (
                        <div
                          key={historyItem.id || index}
                          style={{
                            padding: 10,
                            borderBottom:
                              index < scheduleHistory.length - 1 ? "1px solid #e5e7eb" : "none",
                            backgroundColor: index % 2 === 0 ? "white" : "#f9fafb",
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "flex-start",
                              marginBottom: 6,
                            }}
                          >
                            <span style={{ fontSize: 12, fontWeight: 700, color: "#374151" }}>
                              {historyItem.action}
                            </span>
                            <span style={{ fontSize: 10, color: "#6b7280" }}>
                              {formatDateTime(historyItem.created_at)}
                            </span>
                          </div>

                          <div style={{ fontSize: 11, lineHeight: 1.3 }}>
                            <div style={{ marginBottom: 3 }}>
                              <span style={{ fontWeight: 500, color: "#374151" }}>
                                {historyItem.action && String(historyItem.action).includes("요청")
                                  ? "요청자:"
                                  : "처리자:"}
                              </span>
                              <span style={{ marginLeft: 6, color: "#6b7280" }}>
                                {historyItem.changed_by}
                              </span>
                            </div>

                            <div style={{ marginBottom: 3 }}>
                              <span style={{ fontWeight: 500, color: "#374151" }}>사유:</span>
                              <span style={{ marginLeft: 6, color: "#6b7280" }}>
                                {historyItem.reason}
                              </span>
                            </div>

                            <div>
                              <span style={{ fontWeight: 500, color: "#374151" }}>세부:</span>
                              <span style={{ marginLeft: 6, color: "#6b7280", whiteSpace: "pre-line" }}>
                                {historyItem.details || "상세 정보 없음"}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                ) : (
                  <div style={{ textAlign: "center", color: "#6b7280", fontSize: 14, padding: "40px 20px" }}>
                    스케줄 저장 후 처리 이력이 표시됩니다.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 메시지 */}
          {message && (
            <div
              style={{
                margin: "0 24px 16px",
                padding: 12,
                borderRadius: 6,
                backgroundColor:
                  message.includes("오류") || message.includes("실패") ? "#fef2f2" : "#f0fdf4",
                color:
                  message.includes("오류") || message.includes("실패") ? "#dc2626" : "#166534",
                fontSize: 14,
                border: `1px solid ${
                  message.includes("오류") || message.includes("실패") ? "#fecaca" : "#bbf7d0"
                }`,
                flexShrink: 0,
              }}
            >
              {message}
            </div>
          )}

          {/* 푸터 버튼 */}
          <div
            style={{
              padding: 16,
              borderTop: "1px solid #E5E7EB",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 12,
              flexShrink: 0,
              backgroundColor: "white",
              flexWrap: "wrap",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              {(saving || userIdLoading) && (
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginRight: 8 }}>
                  <div
                    style={{
                      width: 14,
                      height: 14,
                      border: "2px solid #d1d5db",
                      borderTop: "2px solid #059669",
                      borderRadius: "50%",
                      animation: "spin 1s linear infinite",
                    }}
                  />
                  <span style={{ fontSize: 14, color: "#6b7280" }}>
                    {userIdLoading ? "사용자 매핑 중..." : "처리 중..."}
                  </span>
                </div>
              )}
              {leftButtons}
            </div>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
              {rightButtons}
            </div>
          </div>
        </div>

        <style jsx>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>

      <ReasonModal
        open={reasonModalOpen}
        type={requestType}
        onClose={() => setReasonModalOpen(false)}
        onSubmit={handleRequestWithReason}
      />
    </>
  );
}
