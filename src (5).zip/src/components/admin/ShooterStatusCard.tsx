// Shooter ?�태 ?�시 컴포?�트 
export default function ShooterStatusCard() {} 
