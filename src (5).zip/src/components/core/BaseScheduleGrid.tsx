'use client';
import React, { ReactNode, useState, useCallback, useMemo } from 'react';

interface BaseScheduleGridProps {
  title?: string;
  leftColumnTitle?: string;
  locations?: Array<{
    id: number | string;
    name: string;
    type?: string;
    studioId?: number;
    studioName?: string;
    shootingTypes?: string[];
    primaryShootingType?: string;
  }>;
  schedules?: any[];
  currentWeek?: Date;
  onWeekChange?: (direction: number) => void;
  onCellClick?: (date: string, location: any) => void;
  getScheduleForCell?: (date: string, location: any) => any[];
  renderScheduleCard?: (schedule: any, ctx?: { selected: boolean }) => ReactNode;

  showAddButton?: boolean;
  onCopyPreviousWeek?: (mode?: 'selected' | 'all') => void;

  /** 화면에서 쓰는 단순 role (기존 유지) */
  userRole?: 'admin' | 'manager' | 'user';
  pageType?: 'academy' | 'studio' | 'internal' | 'integrated' | 'all';
  hideHeader?: boolean;

  getLocationColor?: (locationId: number | string) => { bg: string; border: string; text: string };
  customFilters?: ReactNode;
  getStudioShootingTypes?: (studioId: number) => string | null;

  onCellDrop?: (date: string, location: any, draggedData: any) => void;
  draggedSchedule?: any;
  isStudioCompatible?: (studioId: number, shootingType: string) => boolean;

  /** 일괄 승인 */
  onBulkApproval?: (type: 'selected' | 'all') => void;
  selectedSchedules?: number[];

  /** ✅ 추가: 입력/클릭을 막아야 하는 셀(등록제한/락/과거주 등) */
  isCellDisabled?: (date: string, location: any) => { disabled: boolean; reason?: string };

  /** ✅ 추가: 스케줄 선택 토글 (선택복사/선택승인 등에 사용) */
  onToggleScheduleSelect?: (scheduleId: number, nextSelected: boolean) => void;
  onClearSelection?: () => void;
}

export default function BaseScheduleGrid({
  title,
  leftColumnTitle,
  locations,
  schedules,
  currentWeek,
  onWeekChange,
  onCellClick,
  getScheduleForCell,
  renderScheduleCard,
  showAddButton = false,
  onCopyPreviousWeek,
  userRole = 'user',
  pageType,
  hideHeader = false,
  getLocationColor,
  customFilters,
  getStudioShootingTypes,
  onCellDrop,
  draggedSchedule,
  isStudioCompatible,
  onBulkApproval,
  selectedSchedules = [],
  isCellDisabled,
  onToggleScheduleSelect,
  onClearSelection
}: BaseScheduleGridProps) {
  const [dragOverCell, setDragOverCell] = useState<string | null>(null);
  const [cellDropStates, setCellDropStates] = useState<Record<string, 'ok' | 'no' | ''>>({});

  const safeTitle = title || '스케줄 관리';
  const safeLeftColumnTitle = leftColumnTitle || '위치';
  const safeLocations = locations || [];
  const safeSchedules = schedules || [];
  const safeCurrentWeek = currentWeek || new Date();
  const safePageType = pageType || 'integrated';

  const safeOnWeekChange = onWeekChange || (() => console.warn('onWeekChange not provided'));
  const safeOnCellClick = onCellClick || (() => console.warn('onCellClick not provided'));

  const safeGetScheduleForCell =
    getScheduleForCell ||
    ((date: string, location: any) => safeSchedules.filter((s) => s.shoot_date === date && s.sub_location_id === location.id));

  const defaultCardRenderer = (schedule: any, ctx?: { selected: boolean }) => {
    const selected = !!ctx?.selected;
    return (
      <div
        key={schedule.id}
        className={`default-schedule-card ${selected ? 'selected' : ''}`}
        title={selected ? '선택됨' : '클릭하여 선택'}
      >
        <div className="card-time">
          {schedule.start_time?.substring(0, 5) || '00:00'}~{schedule.end_time?.substring(0, 5) || '00:00'}
        </div>
        <div className="card-content">{schedule.professor_name || schedule.task_name || '제목 없음'}</div>
        <div className="card-sub">{schedule.course_name || schedule.department || '내용 없음'}</div>
      </div>
    );
  };

  const safeRenderScheduleCard = renderScheduleCard || defaultCardRenderer;

  const selectedSet = useMemo(() => new Set(selectedSchedules || []), [selectedSchedules]);

  const canManage = userRole === 'admin' || userRole === 'manager';

  const checkDropAllowed = useCallback(
    (location: any, draggedData: any) => {
      if (!draggedData || !isStudioCompatible) return true;
      if (draggedData.sub_location_id === location.id) return true;
      if (draggedData.shooting_type) return isStudioCompatible(location.id, draggedData.shooting_type);
      return true;
    },
    [isStudioCompatible]
  );

  const handleCellDragEnter = useCallback(
    (e: React.DragEvent, date: string, location: any) => {
      e.preventDefault();
      const cellKey = `${location.id}-${date}`;
      setDragOverCell(cellKey);

      if (draggedSchedule) {
        const dropAllowed = checkDropAllowed(location, draggedSchedule);
        setCellDropStates((prev) => ({ ...prev, [cellKey]: dropAllowed ? 'ok' : 'no' }));
      }
    },
    [draggedSchedule, checkDropAllowed]
  );

  const handleCellDragOver = useCallback(
    (e: React.DragEvent, date: string, location: any) => {
      e.preventDefault();
      e.stopPropagation();
      const cellKey = `${location.id}-${date}`;
      const dropState = cellDropStates[cellKey];
      e.dataTransfer.dropEffect = dropState === 'no' ? 'none' : 'move';
    },
    [cellDropStates]
  );

  const handleCellDragLeave = useCallback((e: React.DragEvent, date: string, location: any) => {
    const relatedTarget = e.relatedTarget as HTMLElement;
    const currentTarget = e.currentTarget as HTMLElement;

    if (!currentTarget.contains(relatedTarget)) {
      const cellKey = `${location.id}-${date}`;
      setDragOverCell(null);
      setCellDropStates((prev) => ({ ...prev, [cellKey]: '' }));
    }
  }, []);

  const handleCellDrop = useCallback(
    (e: React.DragEvent, date: string, location: any) => {
      e.preventDefault();
      e.stopPropagation();

      const cellKey = `${location.id}-${date}`;
      setDragOverCell(null);
      setCellDropStates((prev) => ({ ...prev, [cellKey]: '' }));

      // ✅ 셀 비활성 시 드롭도 막음
      const disabledInfo = isCellDisabled?.(date, location);
      if (disabledInfo?.disabled) return;

      let dragDataJson = e.dataTransfer.getData('application/json') || e.dataTransfer.getData('text/plain');
      if (dragDataJson && onCellDrop) {
        try {
          const draggedData = JSON.parse(dragDataJson);
          onCellDrop(date, location, draggedData);
        } catch (error) {
          console.error('드래그 데이터 파싱 오류:', error);
        }
      }
    },
    [onCellDrop, isCellDisabled]
  );

  const handleCellClick = useCallback(
    (date: string, location: any, e: React.MouseEvent) => {
      if (e.defaultPrevented) return;

      const disabledInfo = isCellDisabled?.(date, location);
      if (disabledInfo?.disabled) {
        // 셀 자체 클릭은 막되, UX상 커서/오버레이로 안내
        e.preventDefault();
        return;
      }

      safeOnCellClick(date, location);
    },
    [safeOnCellClick, isCellDisabled]
  );

  const handleScheduleClick = useCallback(
    (e: React.MouseEvent, schedule: any) => {
      if (!onToggleScheduleSelect) return; // 선택 기능 미사용
      e.preventDefault();
      e.stopPropagation();

      const id = Number(schedule?.id);
      if (!id) return;

      const next = !selectedSet.has(id);
      onToggleScheduleSelect(id, next);
    },
    [onToggleScheduleSelect, selectedSet]
  );

  const generateWeekDates = () => {
    let startOfWeek = new Date(safeCurrentWeek);

    if (isNaN(startOfWeek.getTime())) startOfWeek = new Date();

    // 월요일 시작
    const dayOfWeek = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    startOfWeek.setDate(diff);

    const dates: Array<{ date: string; day: number; dayName: string; isWeekend: boolean; isToday: boolean }> = [];
    const dayNames = ['월', '화', '수', '목', '금', '토', '일'];

    for (let i = 0; i < 7; i++) {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);

      if (isNaN(date.getTime())) continue;

      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, '0');
      const d = String(date.getDate()).padStart(2, '0');
      const dateStr = `${y}-${m}-${d}`;

      const isWeekend = date.getDay() === 0 || date.getDay() === 6;
      const today = new Date();
      const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      const isToday = dateStr === todayStr;

      dates.push({ date: dateStr, day: date.getDate(), dayName: dayNames[i] || `Day${i}`, isWeekend, isToday });
    }

    return dates;
  };

  const weekDates = generateWeekDates();

  const formatDateRange = () => {
    if (weekDates.length < 7) return '날짜 로딩 중...';
    const start = weekDates[0];
    const end = weekDates[6];
    const startFormatted = `${start.date.slice(2, 4)}.${start.date.slice(5, 7)}.${start.date.slice(8, 10)}`;
    const endFormatted = `${end.date.slice(2, 4)}.${end.date.slice(5, 7)}.${end.date.slice(8, 10)}`;
    return `${startFormatted} ~ ${endFormatted}`;
  };

  const brandColor = (() => {
    switch (safePageType) {
      case 'academy':
        return '#2563eb';
      case 'studio':
        return '#059669';
      case 'internal':
        return '#7c3aed';
      case 'integrated':
      case 'all':
        return '#d97706';
      default:
        return '#6b7280';
    }
  })();

  const hasSelection = (selectedSchedules?.length || 0) > 0;

  return (
    <div className="schedule-grid-container">
      {!hideHeader && (
        <div className="schedule-header">
          <h2 className="schedule-title">{safeTitle}</h2>
          <div className="schedule-info">
            <span className="page-type" style={{ backgroundColor: brandColor }}>
              {safePageType.toUpperCase()}
            </span>
            <span className="schedule-count">{safeSchedules.length}개</span>

            {/* ✅ 선택 개수 표시 */}
            {onToggleScheduleSelect && (
              <span className="selection-count" title="선택된 스케줄">
                선택 {selectedSchedules?.length || 0}개
              </span>
            )}
          </div>
        </div>
      )}

      <div className="schedule-toolbar">
        <div className="toolbar-left">{customFilters}</div>

        <div className="navigation-section">
          {/* ✅ 선택 기반 작업 (일괄승인/복사) */}
          {canManage && userRole === 'admin' && onBulkApproval && (
            <div style={{ display: 'flex', gap: 8, marginRight: 12, alignItems: 'center' }}>
              <button
                onClick={() => onBulkApproval('selected')}
                disabled={!hasSelection}
                style={{
                  padding: '8px 16px',
                  fontSize: '13px',
                  backgroundColor: '#3b82f6',
                  opacity: hasSelection ? 1 : 0.45,
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: hasSelection ? 'pointer' : 'not-allowed',
                  fontWeight: '500'
                }}
              >
                선택 승인
              </button>
              <button
                onClick={() => onBulkApproval('all')}
                style={{
                  padding: '8px 16px',
                  fontSize: '13px',
                  backgroundColor: '#059669',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '500'
                }}
              >
                전체 승인
              </button>

              {onClearSelection && (
                <button
                  onClick={onClearSelection}
                  disabled={!hasSelection}
                  style={{
                    padding: '8px 10px',
                    fontSize: '12px',
                    backgroundColor: '#f3f4f6',
                    color: '#374151',
                    border: '1px solid #d1d5db',
                    borderRadius: '6px',
                    cursor: hasSelection ? 'pointer' : 'not-allowed',
                    opacity: hasSelection ? 1 : 0.5
                  }}
                >
                  선택 해제
                </button>
              )}
            </div>
          )}

          {/* ✅ 선택복사: 선택이 있으면 selected, 없으면 all */}
          {canManage && onCopyPreviousWeek && (
            <button
              onClick={() => onCopyPreviousWeek(hasSelection ? 'selected' : 'all')}
              className="copy-button"
              style={{ backgroundColor: brandColor }}
              title={hasSelection ? '선택된 스케줄만 복사' : '전체 복사'}
            >
              지난 주 복사{hasSelection ? ' (선택)' : ''}
            </button>
          )}

          <button onClick={() => safeOnWeekChange(-1)} className="nav-button">
            &lt; 이전 주
          </button>
          <div className="week-display">{formatDateRange()}</div>
          <button onClick={() => safeOnWeekChange(1)} className="nav-button">
            다음 주 &gt;
          </button>
        </div>
      </div>

      <div className="scrollable-table-container">
        <table className="schedule-table">
          <thead className="sticky-header">
            <tr className="table-header-row">
              <th className="location-header">
                <span className="header-title">{safeLeftColumnTitle}</span>
              </th>
              {weekDates.map((dateInfo, headerIndex) => (
                <th key={`header-${dateInfo.date}-${headerIndex}`} className="date-header">
                  <div className="date-header-content">
                    <div className={`date-day-format ${dateInfo.isWeekend ? 'weekend-text' : ''} ${dateInfo.isToday ? 'today-text' : ''}`}>
                      {dateInfo.day} ({dateInfo.dayName})
                    </div>
                  </div>
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {safeLocations.length === 0 ? (
              <tr className="schedule-row">
                <td className="location-cell">
                  <div className="location-name">데이터 없음</div>
                </td>
                {weekDates.map((dateInfo, emptyIndex) => (
                  <td key={`empty-${dateInfo.date}-${emptyIndex}`} className="schedule-cell empty-data">
                    <div className="cell-wrapper">
                      <div className="empty-message">위치 정보 없음</div>
                    </div>
                  </td>
                ))}
              </tr>
            ) : (
              safeLocations.map((location, locationIndex) => {
                const locationColor = getLocationColor ? getLocationColor(location.id) : null;

                return (
                  <tr key={`row-${location.id}-${locationIndex}`} className="schedule-row">
                    <td
                      className="location-cell"
                      style={
                        locationColor
                          ? { backgroundColor: locationColor.bg, borderLeft: `4px solid ${locationColor.border}`, color: locationColor.text }
                          : {}
                      }
                    >
                      <div className="location-name">{location.name || '이름 없음'}</div>
                      {location.type === 'studio' && getStudioShootingTypes && location.studioId && (
                        <div className="studio-shooting-types">{getStudioShootingTypes(location.studioId)}</div>
                      )}
                      {location.shootingTypes && location.shootingTypes.length > 0 && (
                        <div className="studio-shooting-types">
                          {location.shootingTypes.slice(0, 2).join(', ')}
                          {location.shootingTypes.length > 2 && ' 등'}
                        </div>
                      )}
                    </td>

                    {weekDates.map((dateInfo, dayIndex) => {
                      const cellSchedules = safeGetScheduleForCell(dateInfo.date, location);
                      const hasSchedules = cellSchedules.length > 0;
                      const cellKey = `${location.id}-${dateInfo.date}`;
                      const isDragOver = dragOverCell === cellKey;
                      const dropState = cellDropStates[cellKey] || '';

                      const disabledInfo = isCellDisabled?.(dateInfo.date, location);
                      const disabled = !!disabledInfo?.disabled;

                      return (
                        <td
                          key={`cell-${location.id}-${dateInfo.date}-${dayIndex}`}
                          data-cell={cellKey}
                          data-drop-state={dropState}
                          className={`schedule-cell ${hasSchedules ? 'has-schedules' : 'empty-cell'} ${isDragOver ? 'drag-over' : ''} ${
                            disabled ? 'cell-disabled' : ''
                          }`}
                          onDragEnter={(e) => (!disabled ? handleCellDragEnter(e, dateInfo.date, location) : undefined)}
                          onDragOver={(e) => (!disabled ? handleCellDragOver(e, dateInfo.date, location) : undefined)}
                          onDragLeave={(e) => (!disabled ? handleCellDragLeave(e, dateInfo.date, location) : undefined)}
                          onDrop={(e) => (!disabled ? handleCellDrop(e, dateInfo.date, location) : undefined)}
                          onClick={(e) => handleCellClick(dateInfo.date, location, e)}
                          style={{
                            backgroundColor:
                              disabled
                                ? 'rgba(243, 244, 246, 0.9)'
                                : dropState === 'ok'
                                  ? 'rgba(5, 150, 105, 0.1)'
                                  : dropState === 'no'
                                    ? 'rgba(220, 38, 38, 0.1)'
                                    : 'white',
                            border:
                              dropState === 'ok'
                                ? '2px dashed #059669'
                                : dropState === 'no'
                                  ? '2px dashed #dc2626'
                                  : '1px solid #e5e7eb',
                            transition: 'all 0.2s ease',
                            position: 'relative',
                            cursor: disabled ? 'not-allowed' : 'pointer',
                            opacity: disabled ? 0.75 : 1
                          }}
                          title={disabled ? disabledInfo?.reason || '등록/수정 불가' : ''}
                        >
                          <div className="cell-wrapper">
                            <div className="schedule-list">
                              {cellSchedules.map((schedule, scheduleIndex) => {
                                const id = Number(schedule?.id);
                                const selected = !!id && selectedSet.has(id);

                                return (
                                  <div
                                    key={`schedule-${schedule.id}-${scheduleIndex}`}
                                    className="schedule-wrapper"
                                    onClick={(e) => handleScheduleClick(e, schedule)}
                                  >
                                    {safeRenderScheduleCard(schedule, { selected })}
                                    {onToggleScheduleSelect && (
                                      <span className={`selection-badge ${selected ? 'on' : ''}`}>{selected ? '선택' : ''}</span>
                                    )}
                                  </div>
                                );
                              })}
                            </div>

                            {canManage && showAddButton && !disabled && (
                              <button
                                className="add-schedule-btn"
                                style={{ borderColor: brandColor + '60', color: brandColor }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  safeOnCellClick(dateInfo.date, location);
                                }}
                              >
                                <span className="add-icon">+</span>
                                <span className="add-text">스케줄 등록</span>
                              </button>
                            )}

                            {/* ✅ 비활성 오버레이(입력폼도 못 열게) */}
                            {disabled && (
                              <div className="disabled-overlay">
                                <div className="disabled-text">{disabledInfo?.reason || '등록 제한'}</div>
                              </div>
                            )}

                            {isDragOver && dropState && !disabled && (
                              <div className={`drag-feedback ${dropState === 'ok' ? 'drop-ok' : 'drop-no'}`}>
                                {dropState === 'ok' ? '✅ 드롭 가능' : '❌ 드롭 불가능'}
                              </div>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <style jsx>{`
        .schedule-grid-container {
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          overflow: hidden;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          height: 100%;
          display: flex;
          flex-direction: column;
        }

        .schedule-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 20px;
          background: #f8fafc;
          border-bottom: 1px solid #e5e7eb;
          flex-shrink: 0;
        }

        .schedule-title {
          margin: 0;
          font-size: 18px;
          font-weight: 700;
          color: #1f2937;
        }

        .schedule-info {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .page-type {
          color: white;
          padding: 2px 8px;
          border-radius: 12px;
          font-size: 10px;
          font-weight: 600;
        }

        .schedule-count {
          background: #f3f4f6;
          color: #6b7280;
          padding: 2px 6px;
          border-radius: 10px;
          font-size: 10px;
          font-weight: 500;
        }

        .selection-count {
          background: #111827;
          color: #fff;
          padding: 2px 6px;
          border-radius: 10px;
          font-size: 10px;
          font-weight: 600;
          opacity: 0.85;
        }

        .schedule-toolbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 20px;
          background: #f9fafb;
          border-bottom: 1px solid #e5e7eb;
          flex-shrink: 0;
          min-height: 60px;
        }

        .toolbar-left {
          flex: 1;
          display: flex;
          align-items: center;
        }

        .navigation-section {
          display: flex;
          align-items: center;
          gap: 12px;
          flex-shrink: 0;
        }

        .week-display {
          font-size: 14px;
          font-weight: 600;
          color: #1f2937;
          min-width: 120px;
          text-align: center;
        }

        .nav-button {
          padding: 6px 12px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          background: white;
          color: #374151;
          cursor: pointer;
          font-size: 12px;
          font-weight: 500;
          transition: all 0.2s ease;
        }

        .nav-button:hover {
          background: #f3f4f6;
          border-color: ${brandColor};
        }

        .copy-button {
          padding: 6px 12px;
          border: none;
          border-radius: 4px;
          color: white;
          cursor: pointer;
          font-size: 12px;
          font-weight: 600;
          transition: all 0.2s ease;
        }

        .copy-button:hover {
          opacity: 0.9;
        }

        .scrollable-table-container {
          flex: 1;
          overflow-x: auto;
          overflow-y: auto;
          background: white;
          overscroll-behavior: contain;
          height: calc(100vh - 200px);
        }

        .schedule-table {
          width: 100%;
          min-width: 1000px;
          border-collapse: collapse;
          table-layout: fixed;
          display: table;
        }

        .sticky-header {
          position: sticky;
          top: 0;
          z-index: 10;
          background: #f8fafc;
          display: table-header-group;
        }

        .location-header {
          width: 160px;
          min-width: 160px;
          max-width: 160px;
          padding: 12px;
          border-right: 2px solid #e5e7eb;
          text-align: center;
          background: #f8fafc;
          white-space: nowrap;
          display: table-cell;
        }

        .date-header {
          width: 120px;
          min-width: 120px;
          max-width: 120px;
          padding: 12px 8px;
          border-right: 1px solid #e5e7eb;
          text-align: center;
          background: #f8fafc;
          white-space: nowrap;
          display: table-cell;
        }

        .date-day-format {
          font-size: 13px;
          font-weight: 600;
          color: #1f2937;
        }

        .date-day-format.weekend-text {
          color: #dc2626;
        }

        .date-day-format.today-text {
          color: #059669;
          font-weight: 700;
        }

        .location-cell {
          width: 160px;
          min-width: 160px;
          max-width: 160px;
          padding: 10px 12px;
          border-right: 2px solid #e5e7eb;
          border-bottom: 1px solid #e5e7eb;
          background: #f8fafc;
          vertical-align: top;
          white-space: nowrap;
          display: table-cell;
        }

        .location-name {
          font-size: 12px;
          font-weight: 600;
          color: inherit;
          line-height: 1.3;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .studio-shooting-types {
          font-size: 10px;
          color: #6b7280;
          margin-top: 4px;
          line-height: 1.2;
          font-weight: 400;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .schedule-cell {
          width: 120px;
          min-width: 120px;
          max-width: 120px;
          padding: 0;
          border-right: 1px solid #e5e7eb;
          border-bottom: 1px solid #e5e7eb;
          vertical-align: top;
          background: white;
          display: table-cell;
          height: 100px;
          position: relative;
          transition: all 0.2s ease;
        }

        .cell-wrapper {
          display: flex;
          flex-direction: column;
          height: 100%;
          min-height: 100px;
          padding: 6px;
          position: relative;
        }

        .schedule-list {
          display: flex;
          flex-direction: column;
          gap: 4px;
          flex: 1 1 auto;
          overflow-y: auto;
          max-height: calc(100% - 36px);
        }

        .schedule-wrapper {
          position: relative;
        }

        .selection-badge {
          position: absolute;
          top: 4px;
          right: 4px;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 999px;
          background: rgba(17, 24, 39, 0.08);
          color: #111827;
          opacity: 0.85;
          pointer-events: none;
        }

        .selection-badge.on {
          background: rgba(37, 99, 235, 0.12);
          color: #2563eb;
        }

        .default-schedule-card {
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 6px;
          padding: 6px;
          font-size: 11px;
          transition: all 0.15s ease;
          cursor: pointer;
          flex-shrink: 0;
        }

        .default-schedule-card:hover {
          border-color: ${brandColor};
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.06);
        }

        .default-schedule-card.selected {
          border-color: #2563eb;
          box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.18);
        }

        .card-time {
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 3px;
          font-size: 12px;
        }

        .card-content {
          color: #374151;
          margin-bottom: 2px;
          font-size: 10px;
          font-weight: 500;
        }

        .card-sub {
          color: #6b7280;
          font-size: 9px;
        }

        .add-schedule-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          width: 100%;
          min-height: 32px;
          max-height: 36px;
          background: rgba(248, 250, 252, 0.8);
          border: 1px dashed #d1d5db;
          border-radius: 6px;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          flex-shrink: 0;
          overflow: hidden;
        }

        .add-schedule-btn:hover {
          background: rgba(248, 250, 252, 1);
          border-style: solid;
          transform: translateY(-1px);
        }

        .disabled-overlay {
          position: absolute;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(243, 244, 246, 0.72);
          border-radius: 0;
          pointer-events: none;
        }

        .disabled-text {
          font-size: 11px;
          font-weight: 700;
          color: #6b7280;
          background: rgba(255, 255, 255, 0.9);
          padding: 6px 10px;
          border: 1px solid #e5e7eb;
          border-radius: 999px;
        }

        .drag-feedback {
          position: absolute;
          top: 4px;
          right: 4px;
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 10px;
          font-weight: bold;
          pointer-events: none;
          z-index: 5;
        }

        .drag-feedback.drop-ok {
          background: #059669;
          color: white;
        }

        .drag-feedback.drop-no {
          background: #dc2626;
          color: white;
        }

        @media (max-width: 768px) {
          .schedule-toolbar {
            padding: 8px 16px;
            flex-direction: column;
            gap: 12px;
            align-items: stretch;
          }

          .navigation-section {
            justify-content: center;
            gap: 8px;
          }

          .schedule-table {
            min-width: 800px;
          }

          .location-header,
          .location-cell {
            width: 140px;
            min-width: 140px;
            max-width: 140px;
          }

          .schedule-cell {
            width: 100px;
            min-width: 100px;
            max-width: 100px;
          }
        }
      `}</style>
    </div>
  );
}
