// src/utils/scheduleHistory.ts
import { supabase } from "./supabaseClient";

export type ScheduleChangeType =
  | "created"
  | "updated"
  | "approved"
  | "rejected"
  | "cancelled"
  | "status_changed";

export interface HistoryActor {
  /** ✅ users.id (int) */
  userId?: number | null;
  name?: string | null;
  email?: string | null;
  role?: string | null;
  source?: "professor-page" | "admin-panel" | "studio-modal" | "system" | string;
}

export interface ScheduleSnapshot {
  id?: number;
  shoot_date?: string | null;
  start_time?: string | null;
  end_time?: string | null;
  professor_name?: string | null;
  course_name?: string | null;
  course_code?: string | null;
  shooting_type?: string | null;
  sub_location_id?: number | null;
  approval_status?: string | null;
  notes?: string | null;
  schedule_group_id?: string | null;
  is_split_schedule?: boolean | null;
  break_time_enabled?: boolean | null;
  break_start_time?: string | null;
  break_end_time?: string | null;
  break_duration_minutes?: number | null;
  is_active?: boolean | null;
}

export interface LogScheduleHistoryParams {
  scheduleId: number;
  changeType: ScheduleChangeType;
  oldValues?: ScheduleSnapshot | null;
  newValues?: ScheduleSnapshot | null;
  description?: string | null; // ✅ DB 컬럼명
  actor?: HistoryActor;
  /** ✅ jsonb 컬럼 */
  changeDetails?: Record<string, any> | null;
}

/** schedules row → snapshot */
export const buildSnapshotFromSchedule = (row: any): ScheduleSnapshot => ({
  id: row.id,
  shoot_date: row.shoot_date,
  start_time: row.start_time,
  end_time: row.end_time,
  professor_name: row.professor_name,
  course_name: row.course_name,
  course_code: row.course_code,
  shooting_type: row.shooting_type,
  sub_location_id: row.sub_location_id,
  approval_status: row.approval_status,
  notes: row.notes,
  schedule_group_id: row.schedule_group_id,
  is_split_schedule: row.is_split_schedule,
  break_time_enabled: row.break_time_enabled,
  break_start_time: row.break_start_time,
  break_end_time: row.break_end_time,
  break_duration_minutes: row.break_duration_minutes,
  is_active: row.is_active,
});

/**
 * ✅ DB 스키마에 맞는 insert payload
 * - changed_by: int(users.id)
 * - old_value/new_value: text(JSON string)
 * - change_details: jsonb
 */
export const logScheduleHistory = async ({
  scheduleId,
  changeType,
  oldValues = null,
  newValues = null,
  description = null,
  actor,
  changeDetails = null,
}: LogScheduleHistoryParams) => {
  try {
    const now = new Date().toISOString();

    const payload = {
      schedule_id: scheduleId,
      change_type: changeType, // varchar NOT NULL
      changed_by: actor?.userId ?? null, // ✅ int only
      description: description ?? null,

      // ✅ text 컬럼이므로 문자열로 저장
      old_value: oldValues ? JSON.stringify(oldValues) : null,
      new_value: newValues ? JSON.stringify(newValues) : null,

      // ✅ jsonb
      change_details: changeDetails ?? null,

      // timestamptz(nullable) - 넣어도 되고 안 넣어도 됨
      changed_at: now,
      created_at: now,
    };

    const { error } = await supabase.from("schedule_history").insert(payload);
    if (error) {
      console.error("[schedule_history] insert error:", error, payload);
    }
  } catch (err) {
    console.error("[schedule_history] logScheduleHistory exception:", err);
  }
};

/** 최초 생성 */
export const logScheduleCreated = async (row: any, actor?: HistoryActor, description?: string) => {
  if (!row?.id) return;
  return logScheduleHistory({
    scheduleId: row.id,
    changeType: "created",
    oldValues: null,
    newValues: buildSnapshotFromSchedule(row),
    actor,
    description: description ?? "created",
  });
};

/** 수정 */
export const logScheduleUpdated = async (
  oldRow: any,
  newRow: any,
  actor?: HistoryActor,
  description?: string,
  changeDetails?: Record<string, any>
) => {
  if (!oldRow?.id) return;
  return logScheduleHistory({
    scheduleId: oldRow.id,
    changeType: "updated",
    oldValues: buildSnapshotFromSchedule(oldRow),
    newValues: buildSnapshotFromSchedule(newRow),
    actor,
    description: description ?? "updated",
    changeDetails: changeDetails ?? null,
  });
};

/** 상태 변경 */
export const logScheduleStatusChanged = async (
  schedule: any,
  fromStatus: string,
  toStatus: string,
  actor?: HistoryActor,
  description?: string
) => {
  if (!schedule?.id) return;

  const oldSnap = buildSnapshotFromSchedule({ ...schedule, approval_status: fromStatus });
  const newSnap = buildSnapshotFromSchedule({ ...schedule, approval_status: toStatus });

  const type: ScheduleChangeType =
    toStatus === "cancelled"
      ? "cancelled"
      : fromStatus === "pending" && toStatus === "approved"
      ? "approved"
      : "status_changed";

  return logScheduleHistory({
    scheduleId: schedule.id,
    changeType: type,
    oldValues: oldSnap,
    newValues: newSnap,
    actor,
    description: description ?? `${fromStatus} -> ${toStatus}`,
    changeDetails: { fromStatus, toStatus },
  });
};
