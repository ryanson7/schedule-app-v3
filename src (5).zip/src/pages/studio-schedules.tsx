// src/pages/studio-schedules.tsx
"use client";

import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { supabase } from "../utils/supabaseClient";
import SchedulePolicy from "../utils/schedulePolicy";
import { useAuth } from "../contexts/AuthContext";

/**
 * ✅ 완전 교체본 (단일 파일)
 * - 교수/관리자 접근(roles 병합)
 * - 촬영 요청 생성(휴식시간 분할 스케줄 지원)
 * - 내 요청 목록(검색/더보기/상태표시)
 * - 인라인 수정(정책에 따라 직접수정 or 수정요청 안내)
 * - 취소 요청/철회
 * - 네이버웍스 메시지 발송(/api/message)
 * - 개발 테스트 모드(Alt+Shift+D)
 *
 * ✅ FIX 포함
 * 1) "수정했는데 리스트에 반영 안 됨" → 수정/취소/철회 후 무조건 offset=0으로 리로드
 * 2) fetchMyRequests append 중복/스테일 방지 → prev 기반 merge + 중복 제거
 * 3) schedulePolicy 로그 폭주 방지 → 정책 결과 캐시
 * 4) schedule_history changed_by 타입 오류(22P02) 방지 → auth uuid → users.id(int) 매핑해서 저장
 * 5) 수정/취소/철회도 히스토리 기록 (created + updated + cancel_requested + cancel_revoked)
 */

type MessageType = "register" | "modify" | "cancel" | "contact";

interface StudioScheduleFormData {
  shoot_date: string;
  start_time: string;
  end_time: string;
  course_name: string;
  course_code: string;
  shooting_type: string;
  notes: string;

  break_time_enabled: boolean;
  break_start_time?: string;
  break_end_time?: string;
  break_duration_minutes: number;

  schedule_group_id?: string;
  is_split_schedule: boolean;
}

interface ShootingType {
  id: number;
  name: string;
  description: string;
  is_active: boolean;
}

/** users 테이블의 id(int) + auth uid(uuid) 둘 다 관리 */
type UserInfo = {
  id: number | null; // ✅ users.id (integer) - schedule_history changed_by에 사용
  auth_id: string | null; // supabase auth uid (uuid)
  name: string;
  email: string;
};

const timeToMinutes = (time: string): number => {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
};

const minutesToTime = (minutes: number): string => {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
};

const generateTimeOptions = () => {
  const times: string[] = [];
  for (let hour = 9; hour < 22; hour++) {
    for (let min = 0; min < 60; min += 30) {
      const h = hour.toString().padStart(2, "0");
      const m = min.toString().padStart(2, "0");
      times.push(`${h}:${m}`);
    }
  }
  return times;
};

const generateBreakTimeOptions = () => {
  const times = generateTimeOptions();
  times.push("22:00");
  return times;
};

const isDevelopmentMode = () => {
  return process.env.NODE_ENV === "development" || localStorage.getItem("dev_mode") === "true";
};

const shouldShowBreakTimeSettings = (startTime: string, endTime: string): boolean => {
  if (!startTime || !endTime) return false;
  const durationMinutes = timeToMinutes(endTime) - timeToMinutes(startTime);
  return durationMinutes >= 240; // 4시간 이상
};

const generateBreakTimeOptionsInRange = (startTime: string, endTime: string, breakOptions: string[]) => {
  if (!startTime || !endTime) return breakOptions;

  const startMinutes = timeToMinutes(startTime);
  const endMinutes = timeToMinutes(endTime);

  return breakOptions.filter((time) => {
    const t = timeToMinutes(time);
    return t > startMinutes && t < endMinutes;
  });
};

const checkBreakTimeRecommendation = (startTime: string, endTime: string) => {
  const startMinutes = timeToMinutes(startTime);
  const endMinutes = timeToMinutes(endTime);
  const durationMinutes = endMinutes - startMinutes;

  if (durationMinutes < 240) {
    return { shouldRecommend: false, reason: "4시간 미만 촬영으로 휴식시간이 필수는 아닙니다" };
  }

  if (startMinutes <= timeToMinutes("12:00") && endMinutes >= timeToMinutes("13:00")) {
    return {
      shouldRecommend: true,
      reason: "4시간 이상 촬영으로 휴식시간을 권장합니다",
      suggestedBreakTime: { startTime: "12:00", endTime: "13:00", durationMinutes: 60 },
    };
  }
  if (startMinutes <= timeToMinutes("18:00") && endMinutes >= timeToMinutes("19:00")) {
    return {
      shouldRecommend: true,
      reason: "4시간 이상 촬영으로 휴식시간을 권장합니다",
      suggestedBreakTime: { startTime: "18:00", endTime: "19:00", durationMinutes: 60 },
    };
  }

  const middle = startMinutes + Math.floor(durationMinutes / 2);
  const breakStart = Math.max(middle - 30, startMinutes + 60);
  const breakEnd = Math.min(middle + 30, endMinutes - 60);

  return {
    shouldRecommend: true,
    reason: "4시간 이상 촬영으로 휴식시간을 권장합니다",
    suggestedBreakTime: { startTime: minutesToTime(breakStart), endTime: minutesToTime(breakEnd), durationMinutes: 60 },
  };
};

const generateAvailableDates = (testDate?: string | null, devMode?: boolean) => {
  const baseToday = testDate ? new Date(testDate) : new Date();

  if (devMode) {
    const dates: { value: string; label: string }[] = [];
    for (let i = -30; i <= 90; i++) {
      const date = new Date(baseToday);
      date.setDate(baseToday.getDate() + i);
      const dateStr = date.toISOString().split("T")[0];
      const dayNames = ["일", "월", "화", "수", "목", "금", "토"];
      const dayName = dayNames[date.getDay()];
      const monthDay = `${date.getMonth() + 1}/${date.getDate()}`;
      dates.push({ value: dateStr, label: `${monthDay}(${dayName})${i < 0 ? " [과거]" : i === 0 ? " [오늘]" : ""}` });
    }
    return dates;
  }

  const currentDay = baseToday.getDay();
  const daysUntilNextMonday = (8 - currentDay) % 7 || 7;
  const nextMonday = new Date(baseToday);
  nextMonday.setDate(baseToday.getDate() + daysUntilNextMonday);

  const availableDates: { value: string; label: string }[] = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(nextMonday);
    d.setDate(nextMonday.getDate() + i);

    const dateStr = d.toISOString().split("T")[0];
    const dayNames = ["일", "월", "화", "수", "목", "금", "토"];
    const dayName = dayNames[d.getDay()];
    const monthDay = `${d.getMonth() + 1}/${d.getDate()}`;
    availableDates.push({ value: dateStr, label: `${monthDay}(${dayName})` });
  }
  return availableDates;
};

const generateAllAvailableDates = (existingDate?: string, testDate?: string | null, devMode = false) => {
  const regular = generateAvailableDates(testDate, devMode);
  if (existingDate && !regular.find((d) => d.value === existingDate)) {
    const d = new Date(existingDate);
    const dayNames = ["일", "월", "화", "수", "목", "금", "토"];
    const dayName = dayNames[d.getDay()];
    const monthDay = `${d.getMonth() + 1}/${d.getDate()}`;
    return [{ value: existingDate, label: `${monthDay}(${dayName}) - 기존 날짜` }, ...regular];
  }
  return regular;
};

const findAvailableTimeSlots = (schedules: any[], compatibleStudioIds: number[], durationMinutes: number) => {
  const workStart = 9 * 60;
  const workEnd = 22 * 60;
  const suggestions: { start: string; end: string }[] = [];

  for (let t = workStart; t <= workEnd - durationMinutes; t += 30) {
    const slotStart = t;
    const slotEnd = t + durationMinutes;

    const slotConflict = schedules.some((s) => {
      if (!compatibleStudioIds.includes(s.sub_location_id)) return false;
      const sStart = timeToMinutes(s.start_time);
      const sEnd = timeToMinutes(s.end_time);
      return slotStart < sEnd && sStart < slotEnd;
    });

    if (!slotConflict) {
      suggestions.push({ start: minutesToTime(slotStart), end: minutesToTime(slotEnd) });
      if (suggestions.length === 3) break;
    }
  }
  return suggestions;
};

const sendNaverWorksMessage = async (
  messageType: MessageType,
  scheduleInfo?: any
) => {
  try {
    const legacyUserName = localStorage.getItem("userName") || "";
    const legacyUserEmail = localStorage.getItem("userEmail") || "";
    const userPhone = localStorage.getItem("userPhone") || "";

    const professorName =
      legacyUserName ||
      (legacyUserEmail ? legacyUserEmail.split("@")[0] : "사용자");

    const currentTime = new Date().toLocaleString("ko-KR");

    const courseName = scheduleInfo?.courseName || "미입력";
    const date = scheduleInfo?.date || "";
    const startTime = scheduleInfo?.startTime || "";
    const endTime = scheduleInfo?.endTime || "";
    const shootingType = scheduleInfo?.shootingType || "";
    const breakTime = scheduleInfo?.breakTime || "";
    const notes = scheduleInfo?.notes || "";
    const cancelReason = scheduleInfo?.cancelReason || "";
    const isDirectEdit = !!scheduleInfo?.isDirectEdit;
    const isRevoke = !!scheduleInfo?.isRevoke;

    let message = "";

    switch (messageType) {
      case "register":
        message =
          `[스튜디오 촬영 등록 알림]\\n\\n` +
          `교수명: ${professorName} 교수님\\n` +
          `연락처: ${userPhone}\\n` +
          `강좌명: ${courseName}\\n` +
          `촬영일: ${date}\\n` +
          `촬영시간: ${startTime} ~ ${endTime}\\n` +
          `촬영형식: ${shootingType}` +
          `${breakTime ? `\\n휴식시간: ${breakTime}` : ""}` +
          `${notes ? `\\n전달사항: ${notes}` : ""}` +
          `\\n\\n새로운 촬영 요청이 등록되었습니다.\\n\\n` +
          `등록시간: ${currentTime}\\n---\\n에듀윌 스튜디오 촬영 시스템에서 발송`;
        break;

      case "modify":
        message =
          `[스튜디오 촬영 수정 알림]\\n\\n` +
          `교수명: ${professorName} 교수님\\n` +
          `연락처: ${userPhone}\\n\\n` +
          `강좌명: ${courseName}\\n` +
          `촬영일: ${date}\\n` +
          `촬영시간: ${startTime} ~ ${endTime}\\n` +
          `촬영형식: ${shootingType}` +
          `${breakTime ? `\\n휴식시간: ${breakTime}` : ""}` +
          `${notes ? `\\n전달사항: ${notes}` : ""}` +
          `\\n\\n` +
          `${isDirectEdit ? "스케줄이 직접 수정되었습니다." : "스케줄 수정 요청이 접수되었습니다."}` +
          `\\n\\n수정시간: ${currentTime}\\n---\\n에듀윌 스튜디오 촬영 시스템에서 발송`;
        break;

      case "cancel":
        message =
          `[스튜디오 촬영 취소 알림]\\n\\n` +
          `교수명: ${professorName} 교수님\\n` +
          `연락처: ${userPhone}\\n\\n` +
          `강좌명: ${courseName}\\n` +
          `촬영일: ${date}\\n` +
          `촬영시간: ${startTime} ~ ${endTime}` +
          `${cancelReason ? `\\n취소 사유: ${cancelReason}` : ""}` +
          `\\n\\n` +
          `${isRevoke ? "취소 요청이 철회되었습니다." : "촬영 취소가 요청되었습니다."}` +
          `\\n\\n처리시간: ${currentTime}\\n---\\n에듀윌 스튜디오 촬영 시스템에서 발송`;
        break;

      case "contact":
        message =
          `[스튜디오 촬영 수정요청]\\n\\n` +
          `교수명: ${professorName} 교수님\\n` +
          `연락처: ${userPhone}\\n\\n` +
          `강좌명: ${courseName}\\n` +
          `촬영일: ${date}` +
          `${startTime && endTime ? `\\n촬영시간: ${startTime} ~ ${endTime}` : ""}` +
          `\\n\\n수정이 필요한 스케줄입니다. 확인 부탁드립니다.\\n\\n` +
          `요청시간: ${currentTime}\\n---\\n에듀윌 스튜디오 촬영 시스템에서 발송`;
        break;
    }

    if (!message) return;

    try {
      await fetch("/api/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "professor_schedule",
          message,
        }),
      });
    } catch (e) {
      console.error("메시지 전송 실패:", e);
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(message);
        alert(
          "메시지 전송에 실패했습니다.\\n메시지가 클립보드에 복사되었으니 직접 보내주세요."
        );
      }
    }
  } catch (error) {
    console.error("네이버웍스 메시지 전송 오류:", error);
  }
};

/** ---------- UI: Dev Mode ---------- */
const DevTestMode = ({
  onClose,
  onDateSelect,
  testDate,
}: {
  onClose: () => void;
  onDateSelect: (date: string) => void;
  testDate: string | null;
}) => {
  const [userDate, setUserDate] = useState(testDate || "");
  const [currentTime, setCurrentTime] = useState("");

  useEffect(() => setUserDate(testDate || ""), [testDate]);
  useEffect(() => {
    const tick = () => setCurrentTime(new Date().toLocaleString("ko-KR"));
    tick();
    const i = setInterval(tick, 1000);
    return () => clearInterval(i);
  }, []);

  return (
    <div
      style={{
        position: "fixed",
        top: 10,
        right: 10,
        backgroundColor: "#1f2937",
        color: "white",
        borderRadius: 8,
        padding: 12,
        fontSize: 12,
        zIndex: 1000,
        maxWidth: 320,
        boxShadow: "0 10px 25px rgba(0,0,0,0.5)",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <strong style={{ color: "#10b981" }}>개발 테스트 모드</strong>
        <button onClick={onClose} style={{ background: "none", border: "none", color: "white", cursor: "pointer", fontSize: 16 }}>
          ×
        </button>
      </div>

      <div style={{ marginBottom: 8, fontSize: 10, color: "#9ca3af" }}>실제 시간: {currentTime}</div>
      <div style={{ marginBottom: 8, fontSize: 10, color: "#9ca3af" }}>
        현재 테스트 날짜: <strong>{testDate || "(미지정)"}</strong>
      </div>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", marginBottom: 4, fontSize: 11 }}>테스트 날짜 설정:</label>
        <input
          type="date"
          value={userDate}
          onChange={(e) => setUserDate(e.target.value)}
          style={{
            width: "100%",
            padding: 4,
            marginBottom: 6,
            borderRadius: 4,
            border: "1px solid #374151",
            backgroundColor: "#374151",
            color: "white",
          }}
        />
        <button
          onClick={() => {
            if (userDate) {
              onDateSelect(userDate);
              alert(`테스트 날짜 ${userDate}로 설정됨`);
            }
          }}
          disabled={!userDate}
          style={{
            width: "100%",
            padding: 6,
            backgroundColor: userDate ? "#10b981" : "#6b7280",
            color: "white",
            border: "none",
            borderRadius: 4,
            cursor: userDate ? "pointer" : "not-allowed",
            fontSize: 11,
          }}
        >
          날짜 적용
        </button>
      </div>

      <div style={{ fontSize: 10, color: "#d1d5db", lineHeight: 1.4 }}>
        • Alt+Shift+D: 모드 토글
        <br />
        • 과거/미래 모든 날짜 선택 가능
        <br />
        • localStorage.dev_mode = "true"
        <br />
        • 정책 테스트 가능
      </div>
    </div>
  );
};

const ContactModal = ({
  open,
  onClose,
  scheduleInfo,
}: {
  open: boolean;
  onClose: () => void;
  scheduleInfo: { date: string; daysLeft: number; courseName: string; startTime?: string; endTime?: string };
}) => {
  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0,0,0,0.3)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 2000,
      }}
    >
      <div
        style={{
          backgroundColor: "white",
          borderRadius: 12,
          width: "90vw",
          maxWidth: 400,
          padding: "clamp(16px, 5vw, 24px)",
          boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: 16 }}>
          <h3 style={{ margin: "0 0 8px 0", fontSize: "clamp(16px, 4vw, 18px)", fontWeight: 600, color: "#1f2937" }}>수정요청 안내</h3>
        </div>

        <div style={{ padding: 12, backgroundColor: "#f1f5f9", borderRadius: 8, marginBottom: 16, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: "clamp(12px, 3vw, 14px)", color: "#475569", lineHeight: 1.5 }}>
            <strong>스케줄 정보:</strong>
            <br />• 강좌명: {scheduleInfo.courseName || "미입력"}
            <br />• 촬영일: {scheduleInfo.date}
            <br />
            {scheduleInfo.startTime && scheduleInfo.endTime && (
              <>
                • 촬영시간: {scheduleInfo.startTime} ~ {scheduleInfo.endTime}
                <br />
              </>
            )}
            <br />
            <strong>촬영확정 또는 온라인 수정 기간이 종료되었습니다.</strong>
            <br />
            수정이 필요한 경우 아래 방법 중 하나를 선택해주세요.
          </div>
        </div>

        <div style={{ display: "grid", gap: 12, marginBottom: 16 }}>
          <button
            onClick={async () => {
              await sendNaverWorksMessage("contact", scheduleInfo);
              alert("담당자에게 연락 요청하였습니다.\n빠른 시일 내에 연락드리겠습니다.");
            }}
            style={{
              padding: "clamp(12px, 3vw, 16px)",
              backgroundColor: "#00C851",
              color: "white",
              border: "none",
              borderRadius: 8,
              cursor: "pointer",
              fontSize: "clamp(14px, 3.5vw, 16px)",
              fontWeight: 500,
            }}
          >
            메시지로 연락 요청하기
          </button>

          <div style={{ padding: 12, backgroundColor: "#f8fafc", borderRadius: 8, border: "1px solid #e2e8f0", textAlign: "center" }}>
            <div style={{ fontSize: "clamp(12px, 3vw, 14px)", color: "#475569", fontWeight: 500 }}>
              또는 직접 전화연락
              <br />
              <strong style={{ fontSize: "clamp(14px, 3.5vw, 16px)" }}>02-2650-3993</strong>
              <br />
              (평일 09:00 ~ 18:00)
            </div>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "center" }}>
          <button
            onClick={onClose}
            style={{
              padding: "clamp(10px, 2.5vw, 12px) clamp(20px, 5vw, 24px)",
              border: "none",
              borderRadius: 6,
              backgroundColor: "#6b7280",
              color: "white",
              cursor: "pointer",
              fontSize: "clamp(14px, 3.5vw, 16px)",
              fontWeight: 500,
            }}
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};

/** ---------- Main Page ---------- */
export default function StudioSchedulePage() {
  const timeOptions = useMemo(() => generateTimeOptions(), []);
  const breakTimeOptions = useMemo(() => generateBreakTimeOptions(), []);

  const { user, signOut } = useAuth();

  // dev
  const [isDevModeActive, setIsDevModeActive] = useState(false);
  const [showDevMode, setShowDevMode] = useState(false);
  const [testDate, setTestDate] = useState<string | null>(null);

  // user
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [userRoles, setUserRoles] = useState<string[]>([]);

  // master data
  const [shootingTypes, setShootingTypes] = useState<ShootingType[]>([]);
  const [availableDates, setAvailableDates] = useState<{ value: string; label: string }[]>([]);
  const [studioLocations, setStudioLocations] = useState<any[]>([]);
  const [shootingTypeMappings, setShootingTypeMappings] = useState<any[]>([]);

  // list
  const [showMyRequests, setShowMyRequests] = useState(false);
  const [myRequests, setMyRequests] = useState<any[]>([]);
  const [totalRequestCount, setTotalRequestCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchFilters, setSearchFilters] = useState({ start_date: "", end_date: "", limit: 10, offset: 0 });

  // contact modal
  const [showContactModal, setShowContactModal] = useState(false);
  const [contactScheduleInfo, setContactScheduleInfo] = useState({ date: "", daysLeft: 0, courseName: "", startTime: "", endTime: "" });

  // edit
  const [editingSchedule, setEditingSchedule] = useState<number | null>(null);
  const [editAvailableDates, setEditAvailableDates] = useState<{ value: string; label: string }[]>([]);
  const [editFormData, setEditFormData] = useState<StudioScheduleFormData>({
    shoot_date: "",
    start_time: "",
    end_time: "",
    course_name: "",
    course_code: "",
    shooting_type: "",
    notes: "",
    break_time_enabled: false,
    break_start_time: undefined,
    break_end_time: undefined,
    break_duration_minutes: 0,
    schedule_group_id: undefined,
    is_split_schedule: false,
  });

  // form
  const [formData, setFormData] = useState<StudioScheduleFormData>({
    shoot_date: "",
    start_time: "",
    end_time: "",
    course_name: "",
    course_code: "",
    shooting_type: "",
    notes: "",
    break_time_enabled: false,
    break_start_time: undefined,
    break_end_time: undefined,
    break_duration_minutes: 0,
    schedule_group_id: undefined,
    is_split_schedule: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [registrationInfo, setRegistrationInfo] = useState({ startDate: "", endDate: "", weekInfo: "", period: "" });

  // -----------------------------
  // Auth / role merge
  // -----------------------------
  const legacyUserRole = typeof window !== "undefined" ? localStorage.getItem("userRole") || "" : "";
  const legacyUserEmail = typeof window !== "undefined" ? localStorage.getItem("userEmail") || "" : "";
  const legacyUserName = typeof window !== "undefined" ? localStorage.getItem("userName") || "" : "";

  const authRole = (user?.user_metadata?.role as string) || "";
  const extraAuthRoles = ((user?.user_metadata?.roles as string[]) ?? []).filter(Boolean);

  const allRoles = useMemo(
    () => Array.from(new Set([...userRoles, authRole, ...extraAuthRoles, legacyUserRole].filter(Boolean))),
    [userRoles, authRole, extraAuthRoles, legacyUserRole]
  );

  const displayUserName =
    userInfo?.name ||
    legacyUserName ||
    ((user?.user_metadata?.name as string) || "") ||
    (legacyUserEmail ? legacyUserEmail.split("@")[0] : user?.email ? user.email.split("@")[0] : "사용자");

  const isLoggedIn = !!user || !!(legacyUserRole && legacyUserEmail && legacyUserName);
  const isAdmin = allRoles.includes("system_admin") || allRoles.includes("schedule_admin") || allRoles.includes("manager");
  const isProfessor = allRoles.includes("professor");
  const hasAccess = isAdmin || isProfessor;

  // -----------------------------
  // ✅ 정책 캐시 (로그/연산 폭주 방지)
  // -----------------------------
  const policyCacheRef = useRef(new Map<string, any>());
  const getPolicyCached = useCallback(
    (shootDate: string) => {
      const key = `${shootDate}|${testDate || ""}`;
      if (policyCacheRef.current.has(key)) return policyCacheRef.current.get(key);
      const p = SchedulePolicy.checkScheduleEditPolicy(shootDate, testDate);
      policyCacheRef.current.set(key, p);
      return p;
    },
    [testDate]
  );

  useEffect(() => {
    // testDate 바뀌면 캐시 비우기
    policyCacheRef.current.clear();
  }, [testDate]);

  // -----------------------------
  // Effects
  // -----------------------------
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.shiftKey && e.key === "D") {
        e.preventDefault();
        if (isDevelopmentMode()) {
          const next = !isDevModeActive;
          setShowDevMode(next);
          setIsDevModeActive(next);
          localStorage.setItem("dev_mode", next ? "true" : "false");
          if (!next) setTestDate(null);
        }
      }
    };

    const devModeEnabled = localStorage.getItem("dev_mode") === "true";
    setIsDevModeActive(devModeEnabled);
    setShowDevMode(devModeEnabled);

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isDevModeActive]);

  useEffect(() => {
    setAvailableDates(generateAvailableDates(testDate, isDevModeActive));
  }, [testDate, isDevModeActive]);

  useEffect(() => {
    if (testDate) setFormData((p) => ({ ...p, shoot_date: testDate }));
  }, [testDate]);

  useEffect(() => {
    // 정책 표시용 (2주)
    const baseToday = testDate ? new Date(testDate) : new Date();
    const currentDay = baseToday.getDay();
    const daysUntilNextMonday = (8 - currentDay) % 7 || 7;
    const nextMonday = new Date(baseToday);
    nextMonday.setDate(baseToday.getDate() + daysUntilNextMonday);

    const startDate = nextMonday.toISOString().split("T")[0];
    const endDate = new Date(nextMonday);
    endDate.setDate(nextMonday.getDate() + 13);
    const endDateStr = endDate.toISOString().split("T")[0];

    const startMonth = nextMonday.getMonth() + 1;
    const startDay = nextMonday.getDate();
    const endMonth = endDate.getMonth() + 1;
    const endDay = endDate.getDate();

    setRegistrationInfo({
      startDate,
      endDate: endDateStr,
      weekInfo: `${startMonth}/${startDay} ~ ${endMonth}/${endDay}`,
      period: `${nextMonday.getFullYear()}년 ${startMonth}월 ${Math.ceil(startDay / 7)}주차~${Math.ceil(endDay / 7)}주차`,
    });
  }, [testDate, isDevModeActive]);

  useEffect(() => {
    fetchUserInfo();
    fetchShootingTypes();
    fetchStudioLocations();
    fetchShootingTypeMappings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchUserInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // -----------------------------
  // ✅ Users.id(int) 매핑 (history changed_by 타입 오류 방지)
  // -----------------------------
  const fetchUserInfo = async () => {
    const storedRole = localStorage.getItem("userRole") || "";
    const storedName = localStorage.getItem("userName") || "";
    const storedEmail = localStorage.getItem("userEmail") || "";

    const aRole = (user?.user_metadata?.role as string) || "";
    const aName = (user?.user_metadata?.name as string) || "";
    const aEmail = user?.email || "";
    const authId = user?.id || null; // uuid

    const finalName = storedName || aName || (aEmail ? aEmail.split("@")[0] : "") || "사용자";
    const finalEmail = storedEmail || aEmail || "";

    const extraRoles = ((user?.user_metadata?.roles as string[]) ?? []).filter(Boolean);
    const mergedRoles = [storedRole, aRole, ...extraRoles].filter(Boolean);
    const uniqueRoles = Array.from(new Set(mergedRoles));

    // 로그인 정보가 거의 없으면 초기화
    if (!finalName && !finalEmail) {
      setUserInfo(null);
      setUserRoles([]);
      return;
    }

    // ✅ users 테이블에서 auth_id(uuid)로 id(int) 조회
    let usersTableId: number | null = null;
    try {
      if (authId) {
        const { data, error } = await supabase.from("users").select("id").eq("auth_id", authId).maybeSingle();
        if (!error && data?.id != null) usersTableId = Number(data.id);
      }
    } catch (e) {
      // 조용히 무시(legacy 모드에서는 null로)
    }

    setUserInfo({
      id: usersTableId,
      auth_id: authId,
      name: finalName,
      email: finalEmail,
    });
    setUserRoles(uniqueRoles);
  };

  const fetchShootingTypes = async () => {
    try {
      const { data, error } = await supabase.from("shooting_types").select("*").eq("is_active", true).order("name");
      if (error) throw error;
      setShootingTypes(data || []);
    } catch (e) {
      console.error("촬영 형식 로딩 오류:", e);
      setShootingTypes(
        ["PPT", "일반칠판", "전자칠판", "크로마키", "PC와콤", "PC"].map((name, idx) => ({
          id: idx + 1,
          name,
          description: name,
          is_active: true,
        }))
      );
    }
  };

  const fetchStudioLocations = async () => {
    const { data } = await supabase.from("sub_locations").select("*, main_locations(name)").eq("is_active", true);
    if (data) {
      const studioOnly = data.filter((location: any) => {
        const locationName = (location.name || "").toLowerCase();
        const mainName = (location.main_locations?.name || "").toLowerCase();
        return locationName.includes("스튜디오") || mainName.includes("스튜디오");
      });
      setStudioLocations(studioOnly);
    }
  };

  const fetchShootingTypeMappings = async () => {
    try {
      const { data, error } = await supabase
        .from("sub_location_shooting_types")
        .select(`*, shooting_types!inner(id, name, is_active), sub_locations(id, name)`)
        .eq("shooting_types.is_active", true);
      if (error) throw error;
      setShootingTypeMappings(data || []);
    } catch (e) {
      console.error("촬영형식 매핑 조회 오류:", e);
      setShootingTypeMappings([]);
    }
  };

  // -----------------------------
  // List helpers
  // -----------------------------
  const groupSplitSchedules = (schedules: any[]) => {
    const grouped: Record<string, any[]> = schedules.reduce((acc: any, schedule: any) => {
      if (schedule.schedule_group_id && !schedule.is_split_schedule) {
        schedule.schedule_group_id = null;
        schedule.sequence_order = 1;
      }

      if (schedule.schedule_group_id && schedule.is_split_schedule) {
        if (!acc[schedule.schedule_group_id]) acc[schedule.schedule_group_id] = [];
        acc[schedule.schedule_group_id].push(schedule);
      } else {
        acc[`single_${schedule.id}`] = [schedule];
      }
      return acc;
    }, {});

    return Object.values(grouped).map((group) => {
      if (group.length === 1) return group[0];
      const sorted = [...group].sort((a: any, b: any) => a.sequence_order - b.sequence_order);
      const rep = { ...sorted[0] };
      rep.start_time = sorted[0].start_time;
      rep.end_time = sorted[sorted.length - 1].end_time;
      rep.grouped_schedules = sorted;
      rep.is_grouped = true;
      return rep;
    });
  };

  const fetchMyRequests = async (opts?: { useSearch?: boolean; offset?: number; limit?: number }) => {
    const useSearch = opts?.useSearch ?? !!(searchFilters.start_date || searchFilters.end_date);
    const offset = opts?.offset ?? searchFilters.offset;
    const limit = opts?.limit ?? searchFilters.limit;

    if (!userInfo?.name) return;

    try {
      setIsSearching(true);

      const baseQuery = supabase
        .from("schedules")
        .select(`*, sub_locations!inner(id, name)`, { count: "exact" })
        .eq("professor_name", userInfo.name)
        .eq("schedule_type", "studio")
        .eq("is_active", true)
        .is("parent_schedule_id", null);

      let q = baseQuery;

      if (useSearch) {
        if (searchFilters.start_date) q = q.gte("shoot_date", searchFilters.start_date);
        if (searchFilters.end_date) q = q.lte("shoot_date", searchFilters.end_date);
      }

      q = q.order("shoot_date", { ascending: false }).order("start_time", { ascending: false });

      q = q.range(offset, offset + limit - 1);

      const { data, error, count } = await q;
      if (error) throw error;

      const grouped = groupSplitSchedules(data || []);

      setMyRequests((prev) => {
        if (offset === 0) return grouped;

        // append + 중복 제거(최신 값 우선)
        const map = new Map<number, any>();
        for (const item of prev) map.set(item.id, item);
        for (const item of grouped) map.set(item.id, item);
        return Array.from(map.values());
      });

      const nextLen = offset === 0 ? grouped.length : myRequests.length + grouped.length;
      setTotalRequestCount(count || 0);
      setHasMore((count || 0) > nextLen);
    } catch (e) {
      console.error("스케줄 조회 오류:", e);
    } finally {
      setIsSearching(false);
    }
  };

  const reloadMyRequests = async () => {
    // ✅ 수정/취소/철회 후에는 무조건 offset=0으로 재조회
    const useSearch = !!(searchFilters.start_date || searchFilters.end_date);
    setSearchFilters((p) => ({ ...p, offset: 0 }));
    await fetchMyRequests({ useSearch, offset: 0, limit: searchFilters.limit });
  };

  const handleSearch = () => {
    setSearchFilters((p) => ({ ...p, offset: 0 }));
    fetchMyRequests({ useSearch: true, offset: 0, limit: searchFilters.limit });
  };

  const handleResetSearch = () => {
    setSearchFilters({ start_date: "", end_date: "", limit: 10, offset: 0 });
    // state 갱신 직후 즉시 호출
    fetchMyRequests({ useSearch: false, offset: 0, limit: 10 });
  };

  const handleLoadMore = () => {
    const newOffset = searchFilters.offset + searchFilters.limit;
    setSearchFilters((p) => ({ ...p, offset: newOffset }));
    fetchMyRequests({ useSearch: !!(searchFilters.start_date || searchFilters.end_date), offset: newOffset, limit: searchFilters.limit });
  };

  // -----------------------------
  // Conflict helpers
  // -----------------------------
  const checkScheduleConflictAndRecommend = async (fd: StudioScheduleFormData, excludeScheduleId?: number, excludeGroupId?: string) => {
    try {
      const { data: compatibleData, error: compatibleError } = await supabase
        .from("sub_location_shooting_types")
        .select(`sub_location_id, is_primary, sub_locations(id, name), shooting_types!inner(name)`)
        .eq("shooting_types.name", fd.shooting_type)
        .eq("shooting_types.is_active", true);

      if (compatibleError) throw compatibleError;

      const compatibleStudioIds = (compatibleData || []).map((item: any) => item.sub_location_id);
      if (compatibleStudioIds.length === 0) {
        return {
          hasConflict: true,
          conflictMessage: `"${fd.shooting_type}" 촬영형식을 지원하는 스튜디오가 없습니다.\n\n다른 촬영형식을 선택해주세요.`,
          availableStudios: [],
          recommendedStudioId: null,
        };
      }

      const { data: allSchedules, error } = await supabase
        .from("schedules")
        .select(`id, start_time, end_time, sub_location_id, schedule_group_id, professor_name, course_name, shooting_type, sub_locations(name)`)
        .eq("shoot_date", fd.shoot_date)
        .eq("schedule_type", "studio")
        .eq("is_active", true)
        .in("approval_status", ["approved", "confirmed", "pending", "approval_requested"])
        .in("sub_location_id", compatibleStudioIds);

      if (error) throw error;

      let filtered = allSchedules || [];
      if (excludeScheduleId) filtered = filtered.filter((s: any) => s.id !== excludeScheduleId);
      if (excludeGroupId) filtered = filtered.filter((s: any) => s.schedule_group_id !== excludeGroupId);

      const requestStart = timeToMinutes(fd.start_time);
      const requestEnd = timeToMinutes(fd.end_time);

      const conflicting = filtered.filter((s: any) => {
        const sStart = timeToMinutes(s.start_time);
        const sEnd = timeToMinutes(s.end_time);
        return requestStart < sEnd && sStart < requestEnd;
      });

      const busyStudioIds = Array.from(new Set(conflicting.map((s: any) => s.sub_location_id)));
      const availableStudioIds = compatibleStudioIds.filter((id: number) => !busyStudioIds.includes(id));
      const availableStudios = (compatibleData || []).filter((item: any) => availableStudioIds.includes(item.sub_location_id));

      if (availableStudios.length === 0) {
        const suggestions = findAvailableTimeSlots(filtered, compatibleStudioIds, requestEnd - requestStart);
        const suggestionText = suggestions.length ? suggestions.map((s) => `• ${s.start}~${s.end}`).join("\n") : "• (동일 날짜에 가능한 시간이 없습니다)";
        return {
          hasConflict: true,
          conflictMessage: "해당 시간대에는 모든 스튜디오가 예약돼 있습니다.\n\n가능한 예시 시간:\n" + suggestionText + "\n\n다른 시간대를 선택해주세요.",
          availableStudios: [],
          recommendedStudioId: null,
        };
      }

      const primary = availableStudios.filter((s: any) => s.is_primary);
      const recommended = primary.length > 0 ? primary[0] : availableStudios[0];

      return {
        hasConflict: false,
        availableStudios,
        recommendedStudioId: recommended.sub_location_id,
        recommendedStudioName: recommended.sub_locations?.name || `${recommended.sub_location_id}번`,
      };
    } catch (e) {
      console.error("스케줄 충돌 검사 오류:", e);
      return { hasConflict: true, conflictMessage: "충돌 검사 중 오류가 발생했습니다. 다시 시도해주세요.", availableStudios: [], recommendedStudioId: null };
    }
  };

  const findAvailableStudio = async (shootingTypeName: string, date: string, startTime: string, endTime: string) => {
    try {
      const { data: compatibleData, error: compatibleError } = await supabase
        .from("sub_location_shooting_types")
        .select(`sub_location_id, is_primary, shooting_types!inner(name)`)
        .eq("shooting_types.name", shootingTypeName)
        .eq("shooting_types.is_active", true);

      if (compatibleError) throw compatibleError;

      const compatibleStudioIds = compatibleData?.map((item: any) => item.sub_location_id) || [];

      const { data: bookedData, error: bookedError } = await supabase
        .from("schedules")
        .select("sub_location_id, start_time, end_time")
        .eq("shoot_date", date)
        .eq("schedule_type", "studio")
        .eq("is_active", true)
        .in("approval_status", ["approved", "confirmed", "pending", "approval_requested"])
        .in("sub_location_id", compatibleStudioIds);

      if (bookedError) throw bookedError;

      const reqStart = timeToMinutes(startTime);
      const reqEnd = timeToMinutes(endTime);

      const bookedStudioIds = Array.from(
        new Set(
          (bookedData || [])
            .filter((s: any) => {
              const sStart = timeToMinutes(s.start_time);
              const sEnd = timeToMinutes(s.end_time);
              return reqStart < sEnd && sStart < reqEnd;
            })
            .map((s: any) => s.sub_location_id)
        )
      );

      const availableStudioIds = compatibleStudioIds.filter((id: number) => !bookedStudioIds.includes(id));
      if (availableStudioIds.length > 0) {
        const primaryStudio = compatibleData?.find((item: any) => item.is_primary && availableStudioIds.includes(item.sub_location_id));
        return primaryStudio ? primaryStudio.sub_location_id : availableStudioIds[0];
      }

      return compatibleStudioIds.length > 0 ? compatibleStudioIds[0] : null;
    } catch (e) {
      console.error("사용 가능한 스튜디오 조회 오류:", e);
      return null;
    }
  };

  // -----------------------------
  // Status helpers
  // -----------------------------
  const isPastSchedule = (scheduleDate: string) => {
    const baseToday = testDate ? new Date(testDate) : new Date();
    return new Date(scheduleDate) < baseToday;
  };

  const isCancelledSchedule = (schedule: any) => {
    return schedule.approval_status === "cancelled" || (schedule.is_active === false && schedule.deletion_reason !== "split_converted");
  };

  const getStatusInfo = (status: string, hasModificationRequest: boolean = false, isActive: boolean = true) => {
    if (!isActive) return { bg: "#f5f5f5", color: "#6c757d", text: "취소완료" };

    switch (status) {
      case "approved":
        return { bg: "#e3f2fd", color: "#1976d2", text: "촬영확정" };
      case "confirmed":
        return { bg: "#e8f5e9", color: "#2e7d32", text: "확정" };
      case "pending":
        return hasModificationRequest ? { bg: "#fef3c7", color: "#92400e", text: "수정확인 중" } : { bg: "#f5f5f5", color: "#616161", text: "검토중" };
      case "cancelled":
        return { bg: "#ffebee", color: "#d32f2f", text: "취소완료" };
      case "modification_requested":
        return { bg: "#f3e5f5", color: "#7b1fa2", text: "수정요청" };
      case "modification_approved":
        return { bg: "#e8f5e8", color: "#388e3c", text: "수정 중" };
      case "cancellation_requested":
        return { bg: "#fff3cd", color: "#856404", text: "취소요청" };
      default:
        return { bg: "#f5f5f5", color: "#616161", text: "기타" };
    }
  };

  // -----------------------------
  // ✅ schedule_history 기록 유틸 (created / updated / cancel_request / revoke 등)
  // -----------------------------
  const insertHistory = async (params: {
    schedule_id: number;
    change_type: string; // 'created' | 'updated' | 'cancellation_requested' | 'cancellation_revoked' ...
    description: string;
    old_value: any | null;
    new_value: any | null;
  }) => {
    try {
      const now = new Date().toISOString();

      // ✅ changed_by 는 users.id(int)로 저장 (없으면 null)
      const changedBy = userInfo?.id ?? null;

      const payload = {
        schedule_id: params.schedule_id,
        change_type: params.change_type,
        changed_by: changedBy,
        description: params.description || null,
        old_value: params.old_value ? JSON.stringify(params.old_value) : null,
        new_value: params.new_value ? JSON.stringify(params.new_value) : null,
        created_at: now,
        changed_at: now,
      };

      const { error } = await supabase.from("schedule_history").insert(payload);
      if (error) throw error;
    } catch (e) {
      console.error("schedule_history 저장 실패:", e);
      // 히스토리는 실패해도 UX는 막지 않음 (필요하면 alert로 올려도 됨)
    }
  };

  const buildScheduleValue = (s: any) => ({
    id: s.id,
    shoot_date: s.shoot_date ?? null,
    start_time: s.start_time ?? null,
    end_time: s.end_time ?? null,
    shooting_type: s.shooting_type ?? null,
    professor_name: s.professor_name ?? null,
    course_name: s.course_name ?? null,
    course_code: s.course_code ?? null,
    approval_status: s.approval_status ?? null,
    notes: s.notes ?? null,
    schedule_group_id: s.schedule_group_id ?? null,
    sub_location_id: s.sub_location_id ?? null,
    is_split_schedule: s.is_split_schedule ?? null,
    sequence_order: s.sequence_order ?? null,
    break_time_enabled: s.break_time_enabled ?? null,
    break_start_time: s.break_start_time ?? null,
    break_end_time: s.break_end_time ?? null,
    break_duration_minutes: s.break_duration_minutes ?? null,
    is_active: s.is_active ?? null,
    cancellation_reason: s.cancellation_reason ?? null,
    deletion_reason: s.deletion_reason ?? null,
  });

  const diffFields = (oldObj: any, newObj: any) => {
    const changes: string[] = [];
    const keys = Array.from(new Set([...Object.keys(oldObj || {}), ...Object.keys(newObj || {})]));
    for (const k of keys) {
      const a = oldObj?.[k];
      const b = newObj?.[k];
      if (String(a ?? "") !== String(b ?? "")) changes.push(k);
    }
    return changes;
  };

  // -----------------------------
  // Cancel / revoke
  // -----------------------------
  const submitCancelRequest = async (schedule: any) => {
    const cancelReason = prompt(
      `취소 사유를 입력해주세요:\n\n강좌명: ${schedule.course_name || "미입력"}\n촬영일: ${schedule.shoot_date}\n시간: ${schedule.start_time?.substring(0, 5)}~${schedule.end_time?.substring(0, 5)}\n\n취소 사유:`,
      ""
    );

    if (cancelReason === null) return;
    if (!cancelReason.trim()) return alert("취소 사유를 입력해주세요.");

    const confirmCancel = confirm(
      `정말로 취소를 요청하시겠습니까?\n\n강좌명: ${schedule.course_name || "미입력"}\n촬영일: ${schedule.shoot_date}\n시간: ${schedule.start_time?.substring(0, 5)}~${schedule.end_time?.substring(0, 5)}\n취소 사유: ${cancelReason}\n\n취소 요청 후에는 관리자 승인이 필요합니다.`
    );
    if (!confirmCancel) return;

    try {
      // ✅ old snapshot
      const oldMain = buildScheduleValue(schedule);

      const updatePayload: any = {
        approval_status: "cancellation_requested",
        cancellation_reason: cancelReason,
        cancelled_by: userInfo?.id ?? null,
        updated_at: new Date().toISOString(),
        
      };

      const { error } = await supabase.from("schedules").update(updatePayload).eq("id", schedule.id);
      if (error) throw error;

      // 그룹이면 자식도 업데이트
      if (schedule.grouped_schedules && schedule.grouped_schedules.length > 1) {
        await Promise.all(
          schedule.grouped_schedules.map((sub: any) =>
            supabase
              .from("schedules")
              .update({
                approval_status: "cancellation_requested",
                notes: sub.notes ? `${sub.notes}\n\n[취소사유: ${cancelReason}]` : `[취소사유: ${cancelReason}]`,
                cancellation_reason: cancelReason,
                cancelled_by: userInfo?.id ?? null,
                updated_at: new Date().toISOString(),
                updated_by: userInfo?.id ?? null,
              })
              .eq("id", sub.id)
          )
        );

        // ✅ 자식 히스토리도 기록
        for (const sub of schedule.grouped_schedules) {
          const oldSub = buildScheduleValue(sub);
          const newSub = { ...oldSub, approval_status: "cancellation_requested", cancellation_reason: cancelReason, cancelled_by: userInfo?.id ?? null };
          await insertHistory({
            schedule_id: sub.id,
            change_type: "cancellation_requested",
            description: `취소요청 (사유: ${cancelReason})`,
            old_value: oldSub,
            new_value: newSub,
          });
        }
      }

      // ✅ main history
      const newMain = { ...oldMain, approval_status: "cancellation_requested", cancellation_reason: cancelReason, cancelled_by: userInfo?.id ?? null };
      await insertHistory({
        schedule_id: schedule.id,
        change_type: "cancellation_requested",
        description: `취소요청 (사유: ${cancelReason})`,
        old_value: oldMain,
        new_value: newMain,
      });

      await sendNaverWorksMessage("cancel", {
        courseName: schedule.course_name,
        date: schedule.shoot_date,
        startTime: schedule.start_time?.substring(0, 5),
        endTime: schedule.end_time?.substring(0, 5),
        cancelReason,
        isRevoke: false,
      });

      alert(`취소 요청이 완료되었습니다.\n\n취소 사유: ${cancelReason}\n\n관리자 검토 후 처리됩니다.`);
      await reloadMyRequests();
    } catch (e: any) {
      console.error("취소 요청 오류:", e);
      alert(`취소 요청 실패: ${e?.message || "알 수 없는 오류"}`);
    }
  };

  const submitCancelRevoke = async (schedule: any) => {
    const confirmRevoke = confirm(`취소 요청을 철회하시겠습니까?\n\n강좌명: ${schedule.course_name || "미입력"}\n촬영일: ${schedule.shoot_date}`);
    if (!confirmRevoke) return;

    try {
      const originalStatus = "pending";

      const oldMain = buildScheduleValue(schedule);

      const { error } = await supabase
        .from("schedules")
        .update({
          approval_status: originalStatus,
          cancellation_reason: null,
          cancelled_by: null,
          updated_at: new Date().toISOString(),
          updated_by: userInfo?.id ?? null,
        })
        .eq("id", schedule.id);
      if (error) throw error;

      if (schedule.grouped_schedules && schedule.grouped_schedules.length > 1) {
        await Promise.all(
          schedule.grouped_schedules.map((sub: any) =>
            supabase
              .from("schedules")
              .update({
                approval_status: originalStatus,
                cancellation_reason: null,
                cancelled_by: null,
                updated_at: new Date().toISOString(),
                updated_by: userInfo?.id ?? null,
              })
              .eq("id", sub.id)
          )
        );

        for (const sub of schedule.grouped_schedules) {
          const oldSub = buildScheduleValue(sub);
          const newSub = { ...oldSub, approval_status: originalStatus, cancellation_reason: null, cancelled_by: null };
          await insertHistory({
            schedule_id: sub.id,
            change_type: "cancellation_revoked",
            description: "취소요청 철회",
            old_value: oldSub,
            new_value: newSub,
          });
        }
      }

      const newMain = { ...oldMain, approval_status: originalStatus, cancellation_reason: null, cancelled_by: null };
      await insertHistory({
        schedule_id: schedule.id,
        change_type: "cancellation_revoked",
        description: "취소요청 철회",
        old_value: oldMain,
        new_value: newMain,
      });

      alert("취소 요청이 철회되었습니다.");

      await sendNaverWorksMessage("cancel", {
        courseName: schedule.course_name,
        date: schedule.shoot_date,
        startTime: schedule.start_time?.substring(0, 5),
        endTime: schedule.end_time?.substring(0, 5),
        isRevoke: true,
      });

      await reloadMyRequests();
    } catch (e: any) {
      console.error("취소 철회 오류:", e);
      alert(`취소 철회 실패: ${e?.message || "알 수 없는 오류"}`);
    }
  };

  // -----------------------------
  // Edit (inline)
  // -----------------------------
  const cancelEditSchedule = () => {
    setEditingSchedule(null);
    setEditAvailableDates([]);
    setEditFormData({
      shoot_date: "",
      start_time: "",
      end_time: "",
      course_name: "",
      course_code: "",
      shooting_type: "",
      notes: "",
      break_time_enabled: false,
      break_start_time: undefined,
      break_end_time: undefined,
      break_duration_minutes: 0,
      schedule_group_id: undefined,
      is_split_schedule: false,
    });
  };

  const startEditSchedule = (schedule: any) => {
    const policy = getPolicyCached(schedule.shoot_date);

    // 분할변환 등 특별케이스는 연락 유도
    const nextPolicy = { ...policy };
    if (schedule.deletion_reason === "split_converted") {
      nextPolicy.needsContact = true;
      nextPolicy.canDirectEdit = false;
    }

    setEditingSchedule(schedule.id);
    setEditFormData({
      shoot_date: schedule.shoot_date,
      start_time: schedule.start_time?.substring(0, 5) || "",
      end_time: schedule.end_time?.substring(0, 5) || "",
      course_name: schedule.course_name || "",
      course_code: schedule.course_code || "",
      shooting_type: schedule.shooting_type || "",
      notes: schedule.notes || "",
      break_time_enabled: schedule.break_time_enabled || false,
      break_start_time: schedule.break_start_time?.substring(0, 5) || undefined,
      break_end_time: schedule.break_end_time?.substring(0, 5) || undefined,
      break_duration_minutes: schedule.break_duration_minutes || 0,
      schedule_group_id: schedule.schedule_group_id || undefined,
      is_split_schedule: schedule.is_split_schedule || false,
    });

    setEditAvailableDates(generateAllAvailableDates(schedule.shoot_date, testDate, isDevModeActive));
  };

  const handleEditTimeChange = (field: "start_time" | "end_time", value: string) => {
    const next = { ...editFormData, [field]: value } as StudioScheduleFormData;

    if (next.start_time && next.end_time) {
      const duration = timeToMinutes(next.end_time) - timeToMinutes(next.start_time);

      if (duration >= 240 && !editFormData.break_time_enabled) {
        const hours = Math.floor(duration / 60);
        const mins = duration % 60;
        const txt = mins > 0 ? `${hours}시간 ${mins}분` : `${hours}시간`;

        const useBreak = window.confirm(
          `촬영 시간이 ${txt}으로 4시간 이상입니다.\n\n장시간 촬영으로 휴식시간 설정을 권장합니다.\n\n휴식시간을 설정하시겠습니까?\n\n확인: 휴식시간 설정\n취소: 휴식시간 없이 진행`
        );

        if (useBreak) {
          setEditFormData((p) => ({
            ...p,
            [field]: value,
            break_time_enabled: true,
            break_start_time: "",
            break_end_time: "",
            break_duration_minutes: 0,
          }));
          alert("휴식시간 설정이 활성화되었습니다.\n아래에서 원하는 시간을 선택해주세요.");
          return;
        }
      }

      if (duration < 240 && editFormData.break_time_enabled) {
        const removeBreak = window.confirm(`촬영 시간이 4시간 미만으로 줄어들었습니다.\n\n휴식시간 설정을 해제하시겠습니까?`);
        if (removeBreak) {
          setEditFormData((p) => ({
            ...p,
            [field]: value,
            break_time_enabled: false,
            break_start_time: undefined,
            break_end_time: undefined,
            break_duration_minutes: 0,
          }));
          alert("휴식시간이 해제되었습니다.");
          return;
        }
      }
    }

    setEditFormData(next);
  };

  const saveEditedSchedule = async (originalSchedule: any) => {
    if (!editFormData.shoot_date || !editFormData.start_time || !editFormData.end_time || !editFormData.shooting_type) {
      alert("필수 항목을 모두 입력해주세요.");
      return;
    }
    if (editFormData.start_time >= editFormData.end_time) {
      alert("종료 시간은 시작 시간보다 늦어야 합니다.");
      return;
    }

    const conflict = await checkScheduleConflictAndRecommend(editFormData, originalSchedule.id, originalSchedule.schedule_group_id);
    if (conflict.hasConflict) {
      alert(conflict.conflictMessage);
      return;
    }

    try {
      // ✅ old snapshot (main + children)
      const oldMain = buildScheduleValue(originalSchedule);
      const oldChildren = (originalSchedule.grouped_schedules || []).map((x: any) => buildScheduleValue(x));

      const updateData: any = {
        shoot_date: editFormData.shoot_date,
        start_time: editFormData.start_time + ":00",
        end_time: editFormData.end_time + ":00",
        course_name: editFormData.course_name || "",
        course_code: editFormData.course_code || "",
        shooting_type: editFormData.shooting_type,
        notes: editFormData.notes || "",
        break_time_enabled: editFormData.break_time_enabled,
        break_start_time: editFormData.break_time_enabled ? (editFormData.break_start_time ? editFormData.break_start_time + ":00" : null) : null,
        break_end_time: editFormData.break_time_enabled ? (editFormData.break_end_time ? editFormData.break_end_time + ":00" : null) : null,
        break_duration_minutes: editFormData.break_duration_minutes || 0,
        approval_status: "pending",
        updated_at: new Date().toISOString(),
        updated_by: userInfo?.id ?? null,
      };

      const { error: mainError } = await supabase.from("schedules").update(updateData).eq("id", originalSchedule.id);
      if (mainError) throw mainError;

      // 그룹이면 자식도 업데이트(휴식시간 분할에 맞게)
      if (originalSchedule.grouped_schedules && originalSchedule.grouped_schedules.length > 1) {
        await Promise.all(
          originalSchedule.grouped_schedules.map((sub: any, idx: number) => {
            const subData = { ...updateData };
            if (editFormData.break_time_enabled && editFormData.break_start_time && editFormData.break_end_time) {
              if (idx === 0) subData.end_time = editFormData.break_start_time + ":00";
              if (idx === 1) subData.start_time = editFormData.break_end_time + ":00";
            }
            return supabase.from("schedules").update(subData).eq("id", sub.id);
          })
        );
      }

      // ✅ new snapshot을 DB에서 다시 읽어오는 게 가장 정확하지만(권장),
      // 여기서는 updateData 기반으로 구성 + id 등을 덧붙여 기록.
      const newMain = {
        ...oldMain,
        shoot_date: updateData.shoot_date,
        start_time: updateData.start_time,
        end_time: updateData.end_time,
        course_name: updateData.course_name,
        course_code: updateData.course_code,
        shooting_type: updateData.shooting_type,
        notes: updateData.notes,
        break_time_enabled: updateData.break_time_enabled,
        break_start_time: updateData.break_start_time,
        break_end_time: updateData.break_end_time,
        break_duration_minutes: updateData.break_duration_minutes,
        approval_status: "pending",
        updated_by: userInfo?.id ?? null,
      };

      const changedFields = diffFields(oldMain, newMain);
      const desc = changedFields.length ? `수정됨: ${changedFields.join(", ")}` : "수정됨";

      await insertHistory({
        schedule_id: originalSchedule.id,
        change_type: "updated",
        description: desc,
        old_value: oldMain,
        new_value: newMain,
      });

      // 자식도 히스토리 기록
      if (originalSchedule.grouped_schedules && originalSchedule.grouped_schedules.length > 1) {
        for (let i = 0; i < originalSchedule.grouped_schedules.length; i++) {
          const sub = originalSchedule.grouped_schedules[i];
          const oldSub = oldChildren[i] || buildScheduleValue(sub);

          const subNew: any = {
            ...oldSub,
            shoot_date: updateData.shoot_date,
            course_name: updateData.course_name,
            course_code: updateData.course_code,
            shooting_type: updateData.shooting_type,
            notes: updateData.notes,
            break_time_enabled: updateData.break_time_enabled,
            break_start_time: updateData.break_start_time,
            break_end_time: updateData.break_end_time,
            break_duration_minutes: updateData.break_duration_minutes,
            approval_status: "pending",
          };

          // 시간 분할 반영
          if (editFormData.break_time_enabled && editFormData.break_start_time && editFormData.break_end_time) {
            if (i === 0) {
              subNew.start_time = editFormData.start_time + ":00";
              subNew.end_time = editFormData.break_start_time + ":00";
            } else if (i === 1) {
              subNew.start_time = editFormData.break_end_time + ":00";
              subNew.end_time = editFormData.end_time + ":00";
            }
          } else {
            // 분할 없으면 자식도 동일 시간으로 맞춰버리면 꼬일 수 있으니,
            // 기존 분할 구조가 있던 케이스는 정책상 보통 contact로 막지만,
            // 여기서는 안전하게 main과 동일 시간으로 기록만 남김
            subNew.start_time = updateData.start_time;
            subNew.end_time = updateData.end_time;
          }

          const subChanged = diffFields(oldSub, subNew);
          await insertHistory({
            schedule_id: sub.id,
            change_type: "updated",
            description: subChanged.length ? `수정됨(그룹): ${subChanged.join(", ")}` : "수정됨(그룹)",
            old_value: oldSub,
            new_value: subNew,
          });
        }
      }

      await sendNaverWorksMessage("modify", {
        courseName: editFormData.course_name,
        date: editFormData.shoot_date,
        startTime: editFormData.start_time,
        endTime: editFormData.end_time,
        shootingType: editFormData.shooting_type,
        breakTime: editFormData.break_time_enabled
          ? `${editFormData.break_start_time || ""} ~ ${editFormData.break_end_time || ""} (${editFormData.break_duration_minutes}분)`
          : "",
        notes: editFormData.notes,
        isDirectEdit: true,
      });

      alert(
        `수정이 완료되었습니다!\n\n변경사항:\n• 날짜: ${editFormData.shoot_date}\n• 시간: ${editFormData.start_time}~${editFormData.end_time}\n• 강좌: ${editFormData.course_name}\n• 형식: ${editFormData.shooting_type}\n\n재승인 요청되었습니다.`
      );

      cancelEditSchedule();
      await reloadMyRequests();
    } catch (e: any) {
      console.error("수정 저장 오류:", e);
      alert(`수정 저장 실패: ${e?.message || "알 수 없는 오류"}`);
    }
  };

  // -----------------------------
  // Create
  // -----------------------------
  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.shoot_date) newErrors.shoot_date = "촬영 날짜를 선택해주세요";
    if (!formData.start_time) newErrors.start_time = "시작 시간을 선택해주세요";
    if (!formData.end_time) newErrors.end_time = "종료 시간을 선택해주세요";
    if (formData.start_time && formData.end_time && formData.start_time >= formData.end_time) newErrors.end_time = "종료 시간은 시작 시간보다 늦어야 합니다";
    if (!formData.shooting_type) newErrors.shooting_type = "촬영 형식을 반드시 선택해주세요";

    if (formData.break_time_enabled) {
      if (!formData.break_start_time) newErrors.break_start_time = "휴식 시작 시간을 설정해주세요";
      if (!formData.break_end_time) newErrors.break_end_time = "휴식 종료 시간을 설정해주세요";
      if (formData.break_start_time && formData.break_end_time && formData.break_start_time >= formData.break_end_time) {
        newErrors.break_end_time = "휴식 종료 시간은 시작 시간보다 늦어야 합니다";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const resetForm = () => {
    setFormData({
      shoot_date: "",
      start_time: "",
      end_time: "",
      course_name: "",
      course_code: "",
      shooting_type: "",
      notes: "",
      break_time_enabled: false,
      break_start_time: undefined,
      break_end_time: undefined,
      break_duration_minutes: 0,
      schedule_group_id: undefined,
      is_split_schedule: false,
    });
    setErrors({});
  };

  const handleFormTimeChange = (field: "start_time" | "end_time", value: string) => {
    const next = { ...formData, [field]: value } as StudioScheduleFormData;

    if (next.start_time && next.end_time) {
      const duration = timeToMinutes(next.end_time) - timeToMinutes(next.start_time);

      if (duration >= 240 && !formData.break_time_enabled) {
        const hours = Math.floor(duration / 60);
        const mins = duration % 60;
        const txt = mins > 0 ? `${hours}시간 ${mins}분` : `${hours}시간`;

        const useBreak = window.confirm(
          `촬영 시간이 ${txt}으로 4시간 이상입니다.\n\n휴식시간을 설정하시겠습니까?\n\n확인: 휴식시간 설정\n취소: 휴식시간 없이 진행`
        );

        if (useBreak) {
          const rec = checkBreakTimeRecommendation(next.start_time, next.end_time);
          const defaultStart = (rec as any)?.suggestedBreakTime?.startTime || "12:00";
          const defaultEnd = (rec as any)?.suggestedBreakTime?.endTime || "13:00";
          const defaultDur = timeToMinutes(defaultEnd) - timeToMinutes(defaultStart);

          setFormData((p) => ({
            ...p,
            [field]: value,
            break_time_enabled: true,
            break_start_time: defaultStart,
            break_end_time: defaultEnd,
            break_duration_minutes: Math.max(0, defaultDur),
          }));
          return;
        }
      }

      if (duration < 240 && formData.break_time_enabled) {
        const removeBreak = window.confirm(`촬영 시간이 4시간 미만으로 줄어들었습니다.\n\n휴식시간 설정을 해제하시겠습니까?`);
        if (removeBreak) {
          setFormData((p) => ({ ...p, [field]: value, break_time_enabled: false, break_start_time: undefined, break_end_time: undefined, break_duration_minutes: 0 }));
          return;
        }
      }
    }

    setFormData(next);
  };

  const createScheduleGroup = async (fd: StudioScheduleFormData) => {
    const groupId = `${(userInfo?.name || "user")}_${fd.shoot_date}_${Date.now()}`;

    const validStudioId = await findAvailableStudio(fd.shooting_type, fd.shoot_date, fd.start_time, fd.end_time);

    const schedules: any[] = [];
    if (fd.break_time_enabled && fd.break_start_time && fd.break_end_time) {
      schedules.push(
        {
          shoot_date: fd.shoot_date,
          start_time: fd.start_time,
          end_time: fd.break_start_time,
          professor_name: userInfo?.name,
          course_name: fd.course_name,
          course_code: fd.course_code,
          shooting_type: fd.shooting_type,
          notes: fd.notes || "",
          schedule_group_id: groupId,
          sequence_order: 1,
          is_split_schedule: true,
          break_time_enabled: true,
          break_start_time: fd.break_start_time,
          break_end_time: fd.break_end_time,
          break_duration_minutes: fd.break_duration_minutes,
          schedule_type: "studio",
          approval_status: "pending",
          team_id: 1,
          sub_location_id: validStudioId,
          is_active: true,
          created_by: userInfo?.id ?? null,
          updated_by: userInfo?.id ?? null,
        },
        {
          shoot_date: fd.shoot_date,
          start_time: fd.break_end_time,
          end_time: fd.end_time,
          professor_name: userInfo?.name,
          course_name: fd.course_name,
          course_code: fd.course_code,
          shooting_type: fd.shooting_type,
          notes: fd.notes || "",
          schedule_group_id: groupId,
          sequence_order: 2,
          is_split_schedule: true,
          break_time_enabled: true,
          break_start_time: fd.break_start_time,
          break_end_time: fd.break_end_time,
          break_duration_minutes: fd.break_duration_minutes,
          schedule_type: "studio",
          approval_status: "pending",
          team_id: 1,
          sub_location_id: validStudioId,
          is_active: true,
          created_by: userInfo?.id ?? null,
          updated_by: userInfo?.id ?? null,
        }
      );
    } else {
      schedules.push({
        shoot_date: fd.shoot_date,
        start_time: fd.start_time,
        end_time: fd.end_time,
        professor_name: userInfo?.name,
        course_name: fd.course_name,
        course_code: fd.course_code,
        shooting_type: fd.shooting_type,
        notes: fd.notes || "",
        schedule_group_id: groupId,
        sequence_order: 1,
        is_split_schedule: false,
        break_time_enabled: false,
        break_start_time: null,
        break_end_time: null,
        break_duration_minutes: 0,
        schedule_type: "studio",
        approval_status: "pending",
        team_id: 1,
        sub_location_id: validStudioId,
        is_active: true,
      });
    }

    const { data, error } = await supabase.from("schedules").insert(schedules).select();
    if (error) throw error;

    return { success: true, message: "스케줄이 등록되었습니다", schedules: data || [] };
  };

  const submitShootingRequest = async () => {
    if (!validateForm()) {
      alert("필수 항목을 입력해주세요");
      return;
    }

    try {
      const conflict = await checkScheduleConflictAndRecommend(formData);
      if (conflict.hasConflict) {
        alert(conflict.conflictMessage);
        return;
      }

      const result = await createScheduleGroup(formData);

      // ✅ created 히스토리(그대로 유지 + changed_by int)
      if (result.success && result.schedules?.length) {
        const createdByRole = localStorage.getItem("userRole") || "";
        const isAdminCreated = ["schedule_admin", "system_admin", "studio_admin"].includes(createdByRole);

        for (const schedule of result.schedules) {
          const newValueObj = buildScheduleValue(schedule);

          await insertHistory({
            schedule_id: schedule.id,
            change_type: "created",
            description: isAdminCreated ? "관리자 등록" : "교수 촬영 신청",
            old_value: null,
            new_value: newValueObj,
          });
        }
      }

      await sendNaverWorksMessage("register", {
        courseName: formData.course_name,
        date: formData.shoot_date,
        startTime: formData.start_time,
        endTime: formData.end_time,
        shootingType: formData.shooting_type,
        breakTime: formData.break_time_enabled ? `${formData.break_start_time}-${formData.break_end_time} (${formData.break_duration_minutes}분)` : "",
        notes: formData.notes,
      });

      alert(result.message);
      resetForm();

      if (showMyRequests) {
        await reloadMyRequests();
      }
    } catch (e: any) {
      console.error("촬영 신청 오류:", e);
      alert(e?.message || "촬영 신청 중 오류가 발생했습니다");
    }
  };

  // -----------------------------
  // Break settings renderer
  // -----------------------------
  const renderBreakTimeSettings = () => {
    if (!shouldShowBreakTimeSettings(formData.start_time, formData.end_time)) return null;
    const rec: any = checkBreakTimeRecommendation(formData.start_time, formData.end_time);

    return (
      <div style={{ marginTop: 16, padding: "clamp(12px, 3vw, 16px)", backgroundColor: "#f8f9fa", borderRadius: 8, border: "1px solid #dee2e6" }}>
        <h4 style={{ margin: "0 0 12px 0", color: "#374151", fontSize: "clamp(14px, 3.5vw, 16px)" }}>휴식시간 설정 (4시간 이상 촬영)</h4>

        <div style={{ marginBottom: 12, padding: 8, backgroundColor: "#e9ecef", borderRadius: 6, border: "1px solid #ced4da" }}>
          <div style={{ color: "#495057", fontWeight: 500, marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)" }}>장시간 촬영 감지</div>
          <div style={{ color: "#495057", fontSize: "clamp(12px, 3vw, 14px)" }}>{rec.reason}</div>
        </div>

        <div style={{ marginBottom: 16 }}>
          <label style={{ display: "flex", alignItems: "center", cursor: "pointer", fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 500 }}>
            <input
              type="checkbox"
              checked={formData.break_time_enabled}
              onChange={(e) => {
                const enabled = e.target.checked;
                if (enabled) {
                  const suggested = rec?.suggestedBreakTime;
                  setFormData((p) => ({
                    ...p,
                    break_time_enabled: true,
                    break_start_time: suggested?.startTime || "12:00",
                    break_end_time: suggested?.endTime || "13:00",
                    break_duration_minutes: suggested?.durationMinutes || 60,
                  }));
                } else {
                  setFormData((p) => ({ ...p, break_time_enabled: false, break_start_time: undefined, break_end_time: undefined, break_duration_minutes: 0 }));
                }
              }}
              style={{ marginRight: 8, transform: "scale(1.2)" }}
            />
            휴식시간 사용
          </label>
        </div>

        {formData.break_time_enabled && (
          <div style={{ padding: 12, backgroundColor: "#f0f9ff", borderRadius: 6, border: "1px solid #dbeafe" }}>
            <h5 style={{ margin: "0 0 12px 0", color: "#1565c0", fontSize: "clamp(14px, 3.5vw, 16px)" }}>휴식시간 설정</h5>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 8, alignItems: "end", marginBottom: 12 }}>
              <div>
                <label style={{ display: "block", marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)", fontWeight: 500 }}>시작</label>
                <select
                  value={formData.break_start_time || "12:00"}
                  onChange={(e) => {
                    const startTime = e.target.value;
                    const endTime = formData.break_end_time || "13:00";
                    const duration = Math.max(0, timeToMinutes(endTime) - timeToMinutes(startTime));
                    setFormData((p) => ({ ...p, break_start_time: startTime, break_duration_minutes: duration }));
                  }}
                  style={{
                    width: "100%",
                    padding: "clamp(8px, 2vw, 10px)",
                    border: `1px solid ${errors.break_start_time ? "#f44336" : "#d1d5db"}`,
                    borderRadius: 6,
                    fontSize: "clamp(12px, 3vw, 14px)",
                    textAlign: "center",
                  }}
                >
                  {generateBreakTimeOptionsInRange(formData.start_time, formData.end_time, breakTimeOptions).map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ display: "block", marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)", fontWeight: 500 }}>종료</label>
                <select
                  value={formData.break_end_time || "13:00"}
                  onChange={(e) => {
                    const endTime = e.target.value;
                    const startTime = formData.break_start_time || "12:00";
                    const duration = Math.max(0, timeToMinutes(endTime) - timeToMinutes(startTime));
                    setFormData((p) => ({ ...p, break_end_time: endTime, break_duration_minutes: duration }));
                  }}
                  style={{
                    width: "100%",
                    padding: "clamp(8px, 2vw, 10px)",
                    border: `1px solid ${errors.break_end_time ? "#f44336" : "#d1d5db"}`,
                    borderRadius: 6,
                    fontSize: "clamp(12px, 3vw, 14px)",
                    textAlign: "center",
                  }}
                >
                  {generateBreakTimeOptionsInRange(formData.start_time, formData.end_time, breakTimeOptions).map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div
                style={{
                  padding: "clamp(8px, 2vw, 10px)",
                  backgroundColor: "white",
                  borderRadius: 6,
                  border: "1px solid #d1d5db",
                  fontSize: "clamp(12px, 3vw, 14px)",
                  fontWeight: 500,
                  color: "#374151",
                  textAlign: "center",
                  whiteSpace: "nowrap",
                }}
              >
                {formData.break_duration_minutes}분
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // -----------------------------
  // Buttons renderer
  // -----------------------------
  const renderActionButtons = (schedule: any) => {
    const { approval_status, is_active } = schedule;
    const isPast = isPastSchedule(schedule.shoot_date);
    const isCancelled = isCancelledSchedule(schedule);

    if (editingSchedule === schedule.id) return null;
    if (!is_active || isPast || isCancelled) return null;

    const buttonStyle: React.CSSProperties = {
      padding: "clamp(8px, 2vw, 10px) clamp(12px, 3vw, 16px)",
      border: "none",
      borderRadius: 6,
      fontSize: "clamp(13px, 3vw, 14px)",
      cursor: "pointer",
      fontWeight: 500,
      textAlign: "center",
    };

    if (approval_status === "approved") {
      return (
        <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setContactScheduleInfo({
                date: schedule.shoot_date,
                daysLeft: 0,
                courseName: schedule.course_name || "미입력",
                startTime: schedule.start_time?.substring(0, 5) || "",
                endTime: schedule.end_time?.substring(0, 5) || "",
              });
              setShowContactModal(true);
            }}
            style={{ ...buttonStyle, backgroundColor: "#FF6F00", color: "white", width: "100%" }}
          >
            수정요청
          </button>
        </div>
      );
    }

    if (approval_status === "cancellation_requested") {
      return (
        <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              submitCancelRevoke(schedule);
            }}
            style={{ ...buttonStyle, backgroundColor: "#4CAF50", color: "white" }}
          >
            취소 철회
          </button>
        </div>
      );
    }

    if (["confirmed", "pending"].includes(approval_status)) {
      const policy = getPolicyCached(schedule.shoot_date);

      return (
        <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              if ((policy as any).needsContact) {
                setContactScheduleInfo({
                  date: schedule.shoot_date,
                  daysLeft: (policy as any).daysLeft || 0,
                  courseName: schedule.course_name || "강좌명 미입력",
                  startTime: schedule.start_time?.substring(0, 5) || "",
                  endTime: schedule.end_time?.substring(0, 5) || "",
                });
                setShowContactModal(true);
              } else {
                startEditSchedule(schedule);
              }
            }}
            style={{ ...buttonStyle, backgroundColor: (policy as any).needsContact ? "#FF6F00" : "#2196F3", color: "white" }}
          >
            {(policy as any).needsContact ? "수정요청" : "수정하기"}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              submitCancelRequest(schedule);
            }}
            style={{ ...buttonStyle, backgroundColor: "#F44336", color: "white" }}
          >
            취소요청
          </button>
        </div>
      );
    }

    if (approval_status === "modification_approved") {
      return (
        <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setContactScheduleInfo({
                date: schedule.shoot_date,
                daysLeft: 0,
                courseName: schedule.course_name || "강좌명 미입력",
                startTime: schedule.start_time?.substring(0, 5) || "",
                endTime: schedule.end_time?.substring(0, 5) || "",
              });
              setShowContactModal(true);
            }}
            style={{ ...buttonStyle, backgroundColor: "#2196F3", color: "white" }}
          >
            수정하기
          </button>
        </div>
      );
    }

    return null;
  };

  // -----------------------------
  // Guards
  // -----------------------------
  if (!isLoggedIn) {
    return (
      <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
        <div style={{ background: "white", borderRadius: 12, padding: "clamp(20px, 5vw, 40px)", textAlign: "center", boxShadow: "0 10px 25px -3px rgba(0, 0, 0, 0.1)", maxWidth: 400, width: "100%" }}>
          <h2 style={{ color: "#1f2937", marginBottom: 20, fontSize: "clamp(18px, 4.5vw, 24px)" }}>로그인이 필요합니다</h2>
          <p style={{ color: "#6b7280", marginBottom: 0, fontSize: "clamp(14px, 3.5vw, 16px)" }}>
            스튜디오 촬영 시스템에 접근하려면
            <br />
            먼저 로그인해주세요.
          </p>
        </div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
        <div style={{ background: "white", borderRadius: 12, padding: "clamp(20px, 5vw, 40px)", textAlign: "center", boxShadow: "0 10px 25px -3px rgba(0, 0, 0, 0.1)", maxWidth: 400, width: "100%" }}>
          <h2 style={{ color: "#1f2937", marginBottom: 20, fontSize: "clamp(18px, 4.5vw, 24px)" }}>교수님만 접근 가능합니다</h2>
          <p style={{ color: "#6b7280", marginBottom: 0, fontSize: "clamp(14px, 3.5vw, 16px)" }}>스튜디오 촬영 시스템은 교수님 전용입니다</p>
        </div>
      </div>
    );
  }

  // -----------------------------
  // Render
  // -----------------------------
  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%)", padding: "clamp(8px, 2vw, 10px)" }}>
      {showDevMode && <DevTestMode onClose={() => setShowDevMode(false)} onDateSelect={(d) => setTestDate(d)} testDate={testDate} />}

      <ContactModal open={showContactModal} onClose={() => setShowContactModal(false)} scheduleInfo={contactScheduleInfo} />

      <div style={{ maxWidth: 600, margin: "0 auto", padding: "0 clamp(8px, 2vw, 10px)" }}>
        {/* Header */}
        <div style={{ position: "relative", background: "white", borderRadius: 12, padding: "clamp(16px, 4vw, 24px)", marginBottom: 16, boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)", textAlign: "center" }}>
          <div style={{ position: "absolute", top: 16, right: 16, display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontSize: "clamp(12px, 3vw, 14px)", color: "#6b7280", fontWeight: 500 }}>{displayUserName} 교수님</div>
            <button
              onClick={async () => {
                if (window.confirm("로그아웃 하시겠습니까?")) {
                  try {
                    await signOut();
                  } catch (e) {
                    console.error("로그아웃 오류:", e);
                  }
                }
              }}
              style={{ padding: "6px 12px", backgroundColor: "#f87171", color: "white", border: "none", borderRadius: 6, fontSize: "clamp(11px, 2.5vw, 13px)", fontWeight: 500, cursor: "pointer" }}
            >
              로그아웃
            </button>
          </div>

          <div style={{ width: "clamp(100px, 25vw, 140px)", height: "clamp(30px, 8vw, 50px)", margin: "0 auto 12px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <img src="https://img.eduwill.net/Img2/Common/BI/type2/live/logo.svg" alt="에듀윌 로고" style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }} />
          </div>

          <h1 style={{ color: "#1f2937", fontSize: "clamp(18px, 4.5vw, 24px)", marginBottom: 6, fontWeight: 600, lineHeight: 1.2 }}>안녕하세요. {displayUserName} 교수님</h1>
          <p style={{ color: "#6b7280", fontSize: "clamp(14px, 3.5vw, 16px)", margin: "0 0 12px 0" }}>에듀윌 영상개발실입니다</p>
          <p style={{ color: "#9ca3af", fontSize: "clamp(12px, 3vw, 14px)", margin: 0 }}>촬영이 필요한 날짜와 시간을 선택해 주세요</p>

          {isDevModeActive && (
            <div style={{ marginTop: 8, padding: "6px 12px", backgroundColor: "#4caf50", color: "white", borderRadius: 20, fontSize: "clamp(10px, 2.5vw, 12px)", fontWeight: 500, display: "inline-block" }}>
              개발 테스트 모드 활성화
            </div>
          )}
        </div>

        {/* Form */}
        <div style={{ background: "white", borderRadius: 12, padding: "clamp(16px, 4vw, 24px)", marginBottom: 16, boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)" }}>
          <div style={{ display: "grid", gap: "clamp(12px, 3vw, 16px)" }}>
            {/* Date */}
            <div>
              <label style={{ display: "block", marginBottom: 6, fontWeight: 500, color: "#374151", fontSize: "clamp(14px, 3.5vw, 16px)" }}>촬영 날짜 *</label>

              {!isDevModeActive ? (
                <div style={{ backgroundColor: "#f0f9ff", border: "1px solid #dbeafe", borderRadius: 6, padding: "clamp(10px, 2.5vw, 12px)", marginBottom: 8, fontSize: "clamp(12px, 3vw, 14px)" }}>
                  <div style={{ color: "#1e40af", fontWeight: 500, marginBottom: 2 }}>이번 등록 대상: {registrationInfo.weekInfo} (2주간)</div>
                  <div style={{ color: "#1e3a8a" }}>매주 월요일에 차차주 2주간 스케줄 등록이 가능합니다.</div>
                </div>
              ) : (
                <div style={{ backgroundColor: "#ecfdf5", border: "1px solid #4caf50", borderRadius: 6, padding: "clamp(10px, 2.5vw, 12px)", marginBottom: 8, fontSize: "clamp(12px, 3vw, 14px)" }}>
                  <div style={{ color: "#2e7d32", fontWeight: 500, marginBottom: 2 }}>개발 테스트 모드: 모든 날짜 선택 가능</div>
                  <div style={{ color: "#1b5e20" }}>과거/미래 날짜, 주말 포함 모든 날짜로 테스트할 수 있습니다.</div>
                </div>
              )}

              <select
                value={formData.shoot_date}
                onChange={(e) => setFormData((p) => ({ ...p, shoot_date: e.target.value }))}
                style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: `1px solid ${errors.shoot_date ? "#f44336" : "#d1d5db"}`, borderRadius: 8, fontSize: "clamp(14px, 3.5vw, 16px)", outline: "none", boxSizing: "border-box" }}
              >
                <option value="">날짜 선택</option>
                {availableDates.map((d) => (
                  <option key={d.value} value={d.value}>
                    {d.label}
                  </option>
                ))}
              </select>
              {errors.shoot_date && <span style={{ color: "#f44336", fontSize: "clamp(11px, 2.5vw, 12px)", marginTop: 4, display: "block" }}>{errors.shoot_date}</span>}
            </div>

            {/* Time */}
            <div>
              <label style={{ display: "block", marginBottom: 6, fontWeight: 500, color: "#374151", fontSize: "clamp(14px, 3.5vw, 16px)" }}>촬영 시간 *</label>

              <div style={{ display: "flex", gap: 12, alignItems: "flex-end" }}>
                <div style={{ flex: 1 }}>
                  <label style={{ display: "block", marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)", fontWeight: 500, color: "#6b7280" }}>시작</label>
                  <select
                    value={formData.start_time}
                    onChange={(e) => handleFormTimeChange("start_time", e.target.value)}
                    style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: `1px solid ${errors.start_time ? "#f44336" : "#d1d5db"}`, borderRadius: 8, fontSize: "clamp(13px, 3vw, 15px)", background: "white", outline: "none", boxSizing: "border-box", textAlign: "center" }}
                  >
                    <option value="">시작 시간</option>
                    {timeOptions.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                <div style={{ padding: "clamp(10px, 2.5vw, 12px) 0", fontSize: "clamp(16px, 4vw, 20px)", color: "#6b7280", fontWeight: 500 }}>~</div>

                <div style={{ flex: 1 }}>
                  <label style={{ display: "block", marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)", fontWeight: 500, color: "#6b7280" }}>종료</label>
                  <select
                    value={formData.end_time}
                    onChange={(e) => handleFormTimeChange("end_time", e.target.value)}
                    style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: `1px solid ${errors.end_time ? "#f44336" : "#d1d5db"}`, borderRadius: 8, fontSize: "clamp(13px, 3vw, 15px)", background: "white", outline: "none", boxSizing: "border-box", textAlign: "center" }}
                  >
                    <option value="">종료 시간</option>
                    {timeOptions.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {(errors.start_time || errors.end_time) && (
                <div style={{ marginTop: 6 }}>
                  {errors.start_time && <span style={{ color: "#f44336", fontSize: "clamp(11px, 2.5vw, 12px)", display: "block" }}>{errors.start_time}</span>}
                  {errors.end_time && <span style={{ color: "#f44336", fontSize: "clamp(11px, 2.5vw, 12px)", display: "block" }}>{errors.end_time}</span>}
                </div>
              )}
            </div>

            {/* Shooting Type */}
            <div>
              <label style={{ display: "block", marginBottom: 6, fontWeight: 500, color: "#374151", fontSize: "clamp(14px, 3.5vw, 16px)" }}>촬영 형식 *</label>
              <select
                value={formData.shooting_type}
                onChange={(e) => setFormData((p) => ({ ...p, shooting_type: e.target.value }))}
                style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: `1px solid ${errors.shooting_type ? "#f44336" : "#d1d5db"}`, borderRadius: 8, fontSize: "clamp(14px, 3.5vw, 16px)", background: "white", outline: "none", boxSizing: "border-box" }}
              >
                <option value="">촬영 형식을 선택해주세요</option>
                {shootingTypes.map((t) => (
                  <option key={t.id} value={t.name}>
                    {t.name}
                  </option>
                ))}
              </select>
              {errors.shooting_type && <span style={{ color: "#f44336", fontSize: "clamp(11px, 2.5vw, 12px)", marginTop: 6, display: "block" }}>{errors.shooting_type}</span>}
            </div>

            {/* Break settings */}
            {formData.start_time && formData.end_time && renderBreakTimeSettings()}

            {/* Course */}
            <div>
              <label style={{ display: "block", marginBottom: 6, fontWeight: 500, color: "#374151", fontSize: "clamp(14px, 3.5vw, 16px)" }}>강좌명</label>
              <input
                type="text"
                value={formData.course_name}
                onChange={(e) => setFormData((p) => ({ ...p, course_name: e.target.value }))}
                placeholder="예: 데이터베이스 설계"
                style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: "1px solid #d1d5db", borderRadius: 8, fontSize: "clamp(14px, 3.5vw, 16px)", outline: "none", boxSizing: "border-box" }}
              />
            </div>

            {/* Notes */}
            <div>
              <label style={{ display: "block", marginBottom: 6, fontWeight: 500, color: "#374151", fontSize: "clamp(14px, 3.5vw, 16px)" }}>전달사항</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData((p) => ({ ...p, notes: e.target.value }))}
                placeholder="촬영 시 특별히 요청하실 사항이 있으시면 입력해주세요"
                style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: "1px solid #d1d5db", borderRadius: 8, minHeight: "clamp(60px, 15vw, 80px)", fontSize: "clamp(14px, 3.5vw, 16px)", resize: "vertical", outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
              />
            </div>

            <div style={{ marginTop: "clamp(8px, 2vw, 12px)" }}>
              <button
                onClick={submitShootingRequest}
                style={{
                  width: "100%",
                  padding: "clamp(12px, 3vw, 16px)",
                  background: "#3b82f6",
                  color: "white",
                  border: "none",
                  borderRadius: 8,
                  cursor: "pointer",
                  fontSize: "clamp(16px, 4vw, 18px)",
                  fontWeight: 500,
                }}
              >
                촬영 요청
              </button>
            </div>
          </div>
        </div>

        {/* Toggle list */}
        <div style={{ textAlign: "center", paddingBottom: 24, marginTop: 16 }}>
          <button
            onClick={() => {
              const next = !showMyRequests;
              setShowMyRequests(next);
              if (next) {
                setSearchFilters((p) => ({ ...p, offset: 0 }));
                fetchMyRequests({ useSearch: false, offset: 0, limit: searchFilters.limit });
              }
            }}
            style={{
              padding: "clamp(10px, 2.5vw, 12px) clamp(20px, 5vw, 28px)",
              background: showMyRequests ? "linear-gradient(135deg, #dc2626 0%, #b91c1c 100%)" : "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)",
              color: "white",
              border: "none",
              borderRadius: 12,
              cursor: "pointer",
              fontSize: "clamp(14px, 3.5vw, 16px)",
              fontWeight: 600,
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
            }}
          >
            {showMyRequests ? "내 요청 목록 숨기기" : "내 요청 목록 보기"}
          </button>
        </div>

        {/* List */}
        {showMyRequests && (
          <div style={{ background: "white", borderRadius: 12, padding: "clamp(16px, 4vw, 24px)", boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
              <h2 style={{ margin: 0, color: "#1f2937", fontSize: "clamp(18px, 4.5vw, 22px)", fontWeight: 600 }}>내 촬영 요청 목록</h2>
              <div style={{ fontSize: "clamp(12px, 3vw, 14px)", color: "#6b7280" }}>
                총 {totalRequestCount}건 중 {myRequests.length}건 표시
              </div>
            </div>

            {/* Search */}
            <div style={{ marginBottom: 16, padding: "clamp(12px, 3vw, 16px)", backgroundColor: "#f9fafb", borderRadius: 8, border: "1px solid #e5e7eb" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, alignItems: "end", marginBottom: 12 }}>
                <div>
                  <label style={{ display: "block", marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)", fontWeight: 500, color: "#374151" }}>시작날짜</label>
                  <input
                    type="date"
                    value={searchFilters.start_date}
                    onChange={(e) => setSearchFilters((p) => ({ ...p, start_date: e.target.value }))}
                    style={{ width: "100%", padding: "clamp(6px, 1.5vw, 8px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(12px, 3vw, 14px)", boxSizing: "border-box" }}
                  />
                </div>

                <div>
                  <label style={{ display: "block", marginBottom: 4, fontSize: "clamp(12px, 3vw, 14px)", fontWeight: 500, color: "#374151" }}>종료날짜</label>
                  <input
                    type="date"
                    value={searchFilters.end_date}
                    onChange={(e) => setSearchFilters((p) => ({ ...p, end_date: e.target.value }))}
                    style={{ width: "100%", padding: "clamp(6px, 1.5vw, 8px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(12px, 3vw, 14px)", boxSizing: "border-box" }}
                  />
                </div>
              </div>

              <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
                <button
                  onClick={handleSearch}
                  disabled={isSearching}
                  style={{
                    flex: 1,
                    padding: "clamp(8px, 2vw, 10px) clamp(12px, 3vw, 16px)",
                    backgroundColor: isSearching ? "#9ca3af" : "#3b82f6",
                    color: "white",
                    border: "none",
                    borderRadius: 6,
                    cursor: isSearching ? "not-allowed" : "pointer",
                    fontSize: "clamp(13px, 3vw, 15px)",
                    fontWeight: 500,
                    opacity: isSearching ? 0.6 : 1,
                  }}
                >
                  {isSearching ? "검색중..." : "검색"}
                </button>
                <button
                  onClick={handleResetSearch}
                  style={{
                    flex: 1,
                    padding: "clamp(8px, 2vw, 10px) clamp(12px, 3vw, 16px)",
                    backgroundColor: "#6b7280",
                    color: "white",
                    border: "none",
                    borderRadius: 6,
                    cursor: "pointer",
                    fontSize: "clamp(13px, 3vw, 15px)",
                    fontWeight: 500,
                  }}
                >
                  초기화
                </button>
              </div>
            </div>

            {/* Content */}
            {myRequests.length === 0 ? (
              <div style={{ textAlign: "center", padding: "clamp(30px, 8vw, 50px)", color: "#6b7280", fontSize: "clamp(14px, 3.5vw, 16px)" }}>
                {isSearching ? "검색 중..." : "아직 등록된 촬영 요청이 없습니다"}
              </div>
            ) : (
              <>
                <div style={{ display: "grid", gap: "clamp(12px, 3vw, 16px)" }}>
                  {myRequests.map((request: any) => {
                    const hasModificationRequest = request.notes && request.notes.includes("[수정요청ID:");
                    const statusInfo = getStatusInfo(request.approval_status, hasModificationRequest, request.is_active);
                    const isPast = isPastSchedule(request.shoot_date);
                    const isCancelled = isCancelledSchedule(request);

                    return (
                      <div key={request.id} style={{ padding: "clamp(12px, 3vw, 20px)", border: request.is_grouped ? "1px solid #6c757d" : "1px solid #e5e7eb", borderRadius: 8, background: isPast || isCancelled ? "#f8f9fa" : "#fafbfc", position: "relative", opacity: isPast || isCancelled ? 0.7 : 1 }}>
                        {/* left bar */}
                        <div style={{ position: "absolute", top: 0, left: 0, width: 3, height: "100%", background: statusInfo.color, borderRadius: "8px 0 0 8px" }} />

                        {/* watermark */}
                        {isCancelled && (
                          <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%) rotate(-15deg)", fontSize: "clamp(32px, 8vw, 48px)", fontWeight: "bold", color: "rgba(108, 117, 125, 0.3)", zIndex: 1, pointerEvents: "none", userSelect: "none", border: "3px solid rgba(108, 117, 125, 0.3)", borderRadius: 8, padding: "8px 16px" }}>
                            취소확정
                          </div>
                        )}
                        {isPast && !isCancelled && (
                          <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%) rotate(-15deg)", fontSize: "clamp(32px, 8vw, 48px)", fontWeight: "bold", color: "rgba(108, 117, 125, 0.2)", zIndex: 1, pointerEvents: "none", userSelect: "none", border: "3px solid rgba(108, 117, 125, 0.2)", borderRadius: 8, padding: "8px 16px" }}>
                            완료
                          </div>
                        )}

                        <div style={{ display: "flex", flexDirection: "column", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12, gap: 8, marginTop: request.is_grouped ? 20 : isPast || isCancelled ? 8 : 24, marginLeft: 6 }}>
                          <div style={{ flex: 1, width: "100%" }}>
                            <h3 style={{ margin: "0 0 6px 0", color: isPast || isCancelled ? "#6c757d" : "#1f2937", fontSize: "clamp(15px, 4vw, 18px)", fontWeight: 600 }}>{request.course_name || "강좌명 미입력"}</h3>
                            <div style={{ color: isPast || isCancelled ? "#868e96" : "#6b7280", fontSize: "clamp(13px, 3vw, 15px)", fontWeight: 500 }}>
                              {request.shoot_date} | {request.start_time?.substring(0, 5)}~{request.end_time?.substring(0, 5)}
                            </div>
                          </div>

                          <div style={{ padding: "clamp(4px, 1vw, 6px) clamp(8px, 2vw, 12px)", borderRadius: 12, fontSize: "clamp(11px, 2.5vw, 13px)", fontWeight: 500, background: statusInfo.bg, color: statusInfo.color, whiteSpace: "nowrap" }}>{statusInfo.text}</div>
                        </div>

                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12, marginLeft: 6 }}>
                          <div style={{ padding: "clamp(8px, 2vw, 12px)", background: "white", borderRadius: 6, border: "1px solid #e5e7eb" }}>
                            <strong style={{ color: "#374151", fontSize: "clamp(11px, 2.5vw, 13px)" }}>촬영형식</strong>
                            <br />
                            <span style={{ color: isPast || isCancelled ? "#6c757d" : "#1f2937", fontSize: "clamp(13px, 3vw, 15px)" }}>{request.shooting_type || "미지정"}</span>
                          </div>

                          <div style={{ padding: "clamp(8px, 2vw, 12px)", background: "white", borderRadius: 6, border: "1px solid #e5e7eb" }}>
                            <strong style={{ color: "#374151", fontSize: "clamp(11px, 2.5vw, 13px)" }}>배정스튜디오</strong>
                            <br />
                            <span style={{ color: isPast || isCancelled ? "#6c757d" : "#1f2937", fontSize: "clamp(13px, 3vw, 15px)" }}>
                              {(() => {
                                const st = request.approval_status;
                                if (st === "approved" || st === "confirmed") return request.sub_locations?.name || "스튜디오 배정 중";
                                if (st === "pending" || st === "approval_requested") return "미배정 (승인 후 배정 예정)";
                                if (st === "cancelled") return "취소됨";
                                return "미배정";
                              })()}
                            </span>
                          </div>
                        </div>

                        {/* Notes */}
                        {request.notes && (
                          <div style={{ padding: "clamp(8px, 2vw, 12px)", background: "white", borderRadius: 6, border: "1px solid #e5e7eb", marginBottom: 12, marginLeft: 6 }}>
                            <strong style={{ color: "#374151", fontSize: "clamp(11px, 2.5vw, 13px)" }}>전달사항</strong>
                            <br />
                            <span style={{ color: isPast || isCancelled ? "#6c757d" : "#1f2937", fontSize: "clamp(13px, 3vw, 15px)" }}>{request.notes}</span>
                          </div>
                        )}

                        {/* Inline edit */}
                        {editingSchedule === request.id && (
                          <div style={{ marginTop: 12, marginLeft: 6, padding: 16, backgroundColor: "#f8f9fa", borderRadius: 8, border: "2px solid #007bff" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                              <span style={{ fontSize: "clamp(16px, 4vw, 18px)", fontWeight: 600, color: "#007bff" }}>스케줄 수정하기</span>
                              <button onClick={cancelEditSchedule} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#6c757d" }}>
                                ×
                              </button>
                            </div>

                            <div style={{ display: "grid", gap: 12 }}>
                              {/* date */}
                              <div>
                                <label style={{ display: "block", marginBottom: 6, fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 500, color: "#374151" }}>촬영 날짜 *</label>
                                <select value={editFormData.shoot_date} onChange={(e) => setEditFormData((p) => ({ ...p, shoot_date: e.target.value }))} style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(14px, 3.5vw, 16px)" }}>
                                  {editAvailableDates.map((d) => (
                                    <option key={d.value} value={d.value}>
                                      {d.label}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              {/* time */}
                              <div>
                                <label style={{ display: "block", marginBottom: 6, fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 500, color: "#374151" }}>촬영 시간 *</label>
                                <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", gap: 8, alignItems: "center" }}>
                                  <select value={editFormData.start_time} onChange={(e) => handleEditTimeChange("start_time", e.target.value)} style={{ width: "100%", padding: "clamp(8px, 2vw, 10px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(13px, 3vw, 15px)", textAlign: "center" }}>
                                    {timeOptions.map((t) => (
                                      <option key={t} value={t}>
                                        {t}
                                      </option>
                                    ))}
                                  </select>

                                  <span style={{ fontSize: 16, color: "#6b7280", fontWeight: 500 }}>~</span>

                                  <select value={editFormData.end_time} onChange={(e) => handleEditTimeChange("end_time", e.target.value)} style={{ width: "100%", padding: "clamp(8px, 2vw, 10px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(13px, 3vw, 15px)", textAlign: "center" }}>
                                    {timeOptions.map((t) => (
                                      <option key={t} value={t}>
                                        {t}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              </div>

                              {/* type */}
                              <div>
                                <label style={{ display: "block", marginBottom: 6, fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 500, color: "#374151" }}>촬영 형식 *</label>
                                <select value={editFormData.shooting_type} onChange={(e) => setEditFormData((p) => ({ ...p, shooting_type: e.target.value }))} style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(14px, 3.5vw, 16px)" }}>
                                  {shootingTypes.map((t) => (
                                    <option key={t.id} value={t.name}>
                                      {t.name}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              {/* course */}
                              <div>
                                <label style={{ display: "block", marginBottom: 6, fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 500, color: "#374151" }}>강좌명</label>
                                <input value={editFormData.course_name} onChange={(e) => setEditFormData((p) => ({ ...p, course_name: e.target.value }))} style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(14px, 3.5vw, 16px)" }} />
                              </div>

                              {/* notes */}
                              <div>
                                <label style={{ display: "block", marginBottom: 6, fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 500, color: "#374151" }}>전달사항</label>
                                <textarea value={editFormData.notes} onChange={(e) => setEditFormData((p) => ({ ...p, notes: e.target.value }))} style={{ width: "100%", padding: "clamp(10px, 2.5vw, 12px)", border: "1px solid #d1d5db", borderRadius: 6, fontSize: "clamp(14px, 3.5vw, 16px)", minHeight: 60 }} />
                              </div>

                              {/* actions */}
                              <div style={{ display: "flex", gap: 12, justifyContent: "center", alignItems: "center", marginTop: 20, paddingTop: 16, borderTop: "1px solid #e5e7eb" }}>
                                <button onClick={cancelEditSchedule} style={{ padding: "clamp(12px, 3vw, 14px) clamp(20px, 5vw, 28px)", backgroundColor: "#6c757d", color: "white", border: "none", borderRadius: 8, cursor: "pointer", fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 600, minWidth: 80 }}>
                                  취소
                                </button>
                                <button onClick={() => saveEditedSchedule(request)} style={{ padding: "clamp(12px, 3vw, 14px) clamp(20px, 5vw, 28px)", backgroundColor: "#007bff", color: "white", border: "none", borderRadius: 8, cursor: "pointer", fontSize: "clamp(14px, 3.5vw, 16px)", fontWeight: 600, minWidth: 80 }}>
                                  수정 완료
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {renderActionButtons(request)}

                        <div style={{ fontSize: "clamp(9px, 2vw, 11px)", color: "#9ca3af", textAlign: "right", marginLeft: 6, marginTop: 8 }}>
                          요청일시: {new Date(request.created_at || Date.now()).toLocaleString("ko-KR")}
                          {request.schedule_group_id && <span style={{ marginLeft: 8 }}>그룹ID: {String(request.schedule_group_id).substring(0, 8)}...</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {hasMore && (
                  <div style={{ textAlign: "center", marginTop: 16 }}>
                    <button onClick={handleLoadMore} style={{ padding: "clamp(8px, 2vw, 10px) clamp(16px, 4vw, 20px)", backgroundColor: "#4caf50", color: "white", border: "none", borderRadius: 6, cursor: "pointer", fontSize: "clamp(13px, 3vw, 15px)", fontWeight: 500 }}>
                      더 보기
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
