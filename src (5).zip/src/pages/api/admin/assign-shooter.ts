export const config = { runtime: 'edge' };

// Shooter 배정 API 
export default function handler() {} 
